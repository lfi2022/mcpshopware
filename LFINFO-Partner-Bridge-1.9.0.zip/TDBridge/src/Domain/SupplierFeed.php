<?php declare(strict_types=1);

namespace TDBridge\Domain;

/** A local UTF-8 CSV feed, with explicit column mapping; no undocumented supplier API. */
final class SupplierFeed
{
    public static function parse(string $csv, array $mapping, string $delimiter = ';'): array
    {
        if (!in_array($delimiter, [';', ',', "\t"], true) || strlen($csv) > 2000000 || !mb_check_encoding($csv, 'UTF-8')) { throw new BridgeException('CSV UTF-8 de 2 Mo maximum attendu ; séparateur invalide.'); }
        foreach ($mapping as $key => $column) {
            if (!in_array($key,['partNumber','name','cost','currency','stock','manufacturer','manufacturerNumber','ean'],true) || !is_string($column) || strlen($column)>255) { throw new BridgeException('Mapping CSV invalide.'); }
        }
        $stream = fopen('php://temp', 'w+');
        try {
            fwrite($stream, preg_replace('/^\xEF\xBB\xBF/', '', $csv)); rewind($stream);
            $header = fgetcsv($stream, 0, $delimiter, '"', '');
            if (!$header || count(array_unique($header)) !== count($header)) { throw new BridgeException('En-têtes CSV absents ou dupliqués.'); }
            foreach (['partNumber', 'name', 'cost', 'currency', 'stock'] as $key) {
                if (!is_string($mapping[$key] ?? null) || !in_array($mapping[$key], $header, true)) { throw new BridgeException('Colonne requise non mappée : ' . $key); }
            }
            $items = []; $seen = []; $line = 1;
            while (($row = fgetcsv($stream, 0, $delimiter, '"', '')) !== false) {
                ++$line; if ($row === [null]) { continue; }
                if (count($row) !== count($header) || count($items) >= 5000) { throw new BridgeException("CSV invalide ligne $line ou limite de 5 000 articles dépassée."); }
                $data = array_combine($header, $row);
                $get = static fn (string $key): string => trim((string) ($data[$mapping[$key] ?? ''] ?? ''));
                $part = $get('partNumber'); $cost = str_replace(',', '.', $get('cost')); $stock = $get('stock');
                $currency = strtoupper($get('currency')); $ean = $get('ean');
                if ($part === '' || strlen($part) > 100 || preg_match('/[\x00-\x1f]/', $part) || isset($seen[mb_strtolower($part)]) || $get('name') === '' || mb_strlen($get('name')) > 255
                    || !preg_match('/^\d+(?:\.\d{1,6})?$/D', $cost) || (float) $cost <= 0 || (float) $cost > 100000000
                    || !preg_match('/^\d{1,9}$/D', $stock) || (int) $stock > 100000000 || !preg_match('/^[A-Z]{3}$/D', $currency)
                    || ($ean !== '' && !preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D', $ean))) {
                    throw new BridgeException("Valeurs invalides ou référence dupliquée ligne $line. Prix HT positif, stock entier et devise ISO requis.");
                }
                $seen[mb_strtolower($part)] = true;
                $items[] = ['partNumber' => $part, 'name' => $get('name'), 'cost' => (float) $cost, 'stock' => (int) $stock, 'currency' => $currency,
                    'ean' => $ean ?: null, 'manufacturer' => mb_substr($get('manufacturer'), 0, 255) ?: null,
                    'manufacturerNumber' => mb_substr($get('manufacturerNumber'), 0, 255) ?: null, 'description' => null];
            }
            if (!$items) { throw new BridgeException('Le CSV ne contient aucun article.'); }
            return $items;
        } finally { fclose($stream); }
    }
}
