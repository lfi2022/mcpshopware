<?php declare(strict_types=1);

namespace TDBridge\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use TDBridge\Domain\ImportDiagnostics;
use TDBridge\Service\ImportInspector;

#[AsCommand(name: 'tdbridge:diagnose', description: 'Diagnostic en lecture seule des imports, sans afficher les identifiants OAuth.')]
final class DiagnoseCommand extends Command
{
    public function __construct(private readonly ImportInspector $inspector) { parent::__construct(); }
    protected function configure(): void { $this->addOption('part', null, InputOption::VALUE_REQUIRED, 'Référence TD à relire dans le catalogue ; aucune écriture produit'); }
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $report = $this->inspector->inspect($input->getOption('part'));
            $output->writeln(json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), OutputInterface::OUTPUT_RAW);
            return Command::SUCCESS;
        } catch (\Throwable $e) {
            $output->writeln(json_encode(['error' => ImportDiagnostics::message($e)], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), OutputInterface::OUTPUT_RAW);
            return Command::FAILURE;
        }
    }
}
