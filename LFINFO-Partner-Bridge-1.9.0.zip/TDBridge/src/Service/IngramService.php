<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Defaults;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueSearch;
use TDBridge\Domain\IngramMapper;

final class IngramService
{
    public function __construct(private readonly Connection $db,private readonly IngramConfig $config,private readonly IngramClient $client) {}
    /** Direct supplier search. Never persists offers, links or native products. */
    public function search(array $input): array
    {
        $filters=CatalogueSearch::query(['minCost'=>$input['minCost']??'','maxCost'=>$input['maxCost']??'','minStock'=>$input['minStock']??'','onlyInStock'=>$input['onlyInStock']??false]);
        $result=$this->client->search($input);$rows=$result['catalog']??null;
        if(!is_array($rows)||!array_is_list($rows)||count($rows)>100||!is_numeric($result['recordsFound']??null)||!is_finite((float)$result['recordsFound'])||(float)$result['recordsFound']<0||floor((float)$result['recordsFound'])!==(float)$result['recordsFound']){throw new BridgeException('Structure catalogue Ingram non reconnue.');}
        $catalog=[];foreach($rows as $row){if(!is_array($row)||!is_string($row['ingramPartNumber']??null)||$row['ingramPartNumber']===''||strlen($row['ingramPartNumber'])>100||isset($catalog[$row['ingramPartNumber']])){throw new BridgeException('Référence catalogue Ingram absente, invalide ou dupliquée.');}$catalog[$row['ingramPartNumber']]=$row;}
        $pna=$catalog?$this->priceIndex(array_map('strval',array_keys($catalog))):[];$items=[];
        $linked=[];
        if($catalog){$linked=$this->db->fetchFirstColumn("SELECT part_number FROM lf_supplier_offer WHERE supplier='ingram' AND product_id IS NOT NULL AND part_number IN (".implode(',',array_fill(0,count($catalog),'?')).")",array_map('strval',array_keys($catalog)));}
        foreach($catalog as $part=>$metadata){
            $part=(string)$part;
            $item=IngramMapper::product($pna[$part]??['ingramPartNumber'=>$part],$metadata);
            if(($input['onlyInStock']??false)&&($item['stock']===null||$item['stock']<=0)){continue;}
            if(isset($input['minCost'])&&$input['minCost']!==''&&($item['cost']===null||$item['cost']<(float)$input['minCost'])){continue;}
            if(isset($input['maxCost'])&&$input['maxCost']!==''&&($item['cost']===null||$item['cost']>(float)$input['maxCost'])){continue;}
            if(isset($input['minStock'])&&$input['minStock']!==''&&($item['stock']===null||$item['stock']<(int)$input['minStock'])){continue;}
            $item['linked']=in_array($part,$linked,true);$items[]=$item;
        }
        $size=$result['pageSize']??($input['pageSize']??25);$page=$result['pageNumber']??($input['page']??1);
        if(!is_numeric($size)||(int)$size<1||!is_numeric($page)||(int)$page<1){throw new BridgeException('Pagination Ingram invalide.');}
        return ['items'=>$items,'recordsFound'=>(int)$result['recordsFound'],'page'=>(int)$page,'pageSize'=>(int)$size,'hasNext'=>(int)$page*(int)$size<(int)$result['recordsFound'],'pageFiltered'=>$filters['where']!=='','environment'=>$this->config->all()['environment']];
    }
    private function priceIndex(array $parts): array
    {
        $index=[];
        foreach(array_chunk($parts,50) as $chunk){foreach($this->client->prices($chunk) as $row){if(!is_array($row)||!is_string($row['ingramPartNumber']??null)||!in_array($row['ingramPartNumber'],$chunk,true)||isset($index[$row['ingramPartNumber']])){throw new BridgeException('Réponse prix Ingram incohérente ou dupliquée.');}$index[$row['ingramPartNumber']]=$row;}}
        return $index;
    }
    /** Refresh one batch from PNA; persisted supplier metadata does not write Shopware products. */
    public function products(array $parts,array $options,string $purpose): array
    {
        $this->config->ready(true);
        if(($options['_ingramScope']??$this->config->scope())!==$this->config->scope()){throw new BridgeException('Compte ou environnement Ingram changé depuis la création de cette tâche. Relancez-la depuis la nouvelle configuration.');}
        $eligible=[];$output=[];$links=[];
        foreach($parts as $part){
            $link=$this->db->fetchAssociative("SELECT *,LOWER(HEX(product_id)) AS product_uuid FROM lf_supplier_offer WHERE supplier='ingram' AND part_number=?",[$part]);
            if($link&&$link['product_uuid']){
                if($link['account_scope']!==$this->config->scope()){$output[]=['partNumber'=>$part,'_error'=>'Cette liaison Ingram appartient à un autre compte. Vérifiez-la dans Fournisseurs & liaisons.'];continue;}
                if(!$link['sync_enabled']||!$this->db->fetchOne("SELECT p.id FROM product p INNER JOIN lf_supplier_source s ON s.product_id=p.id WHERE p.id=UNHEX(?) AND p.version_id=UNHEX(?) AND s.supplier='ingram' AND s.part_number=?",[$link['product_uuid'],Defaults::LIVE_VERSION,$part])){continue;}
            }elseif($purpose!=='import'){continue;}
            $eligible[]=$part;$links[$part]=$link;
        }
        $rows=$eligible?$this->priceIndex($eligible):[];
        foreach($eligible as $part){
            try{
                if(!isset($rows[$part])){throw new BridgeException('Référence absente de la réponse Ingram ; produit Shopware conservé.');}
                $item=IngramMapper::product($rows[$part]);if(!$item['authorized']){throw new BridgeException('Produit Ingram non autorisé pour ce compte.');}
                $this->remember($item);$item['_productId']=$links[$part]['product_uuid']??null;$output[]=$item;
            }catch(BridgeException $e){$output[]=['partNumber'=>$part,'_error'=>$e->getMessage()];}
        }
        return $output;
    }
    public function link(string $part,?string $id,bool $enabled): void
    {
        $offers=new SupplierOffers($this->db);
        if($id===null){$offers->bind('ingram',$part,null,false);return;}
        $this->config->ready(true);$rows=$this->priceIndex([$part]);if(!isset($rows[$part])){throw new BridgeException('Référence Ingram introuvable.');}
        $item=IngramMapper::product($rows[$part]);if(!$item['authorized']){throw new BridgeException('Produit Ingram non autorisé.');}
        $this->db->transactional(function()use($part,$id,$enabled,$item,$offers):void{
            if(!$this->db->fetchOne('SELECT id FROM product WHERE id=UNHEX(?) AND version_id=UNHEX(?) FOR UPDATE',[$id,Defaults::LIVE_VERSION])){throw new BridgeException('Produit Shopware introuvable.');}
            $this->remember($item);$offers->bind('ingram',$part,$id,$enabled);
        });
    }
    private function remember(array $item): void
    {
        $this->db->executeStatement(<<<'SQL'
INSERT INTO lf_supplier_offer (supplier,part_number,name,description,manufacturer,manufacturer_number,ean,cost,currency,stock,observed_at,next_sync_at,product_class,supplier_status,source_kind,catalogue_available,account_scope)
VALUES ('ingram',?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3),?,?,'api',1,?)
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),manufacturer=VALUES(manufacturer),manufacturer_number=VALUES(manufacturer_number),ean=VALUES(ean),cost=VALUES(cost),currency=VALUES(currency),stock=VALUES(stock),observed_at=VALUES(observed_at),supplier_status=VALUES(supplier_status),catalogue_available=1,account_scope=VALUES(account_scope),last_error=NULL
SQL,[$item['partNumber'],$item['name'],$item['description'],$item['manufacturer'],$item['manufacturerNumber'],$item['ean'],$item['cost'],$item['currency'],$item['stock'],$item['class'],$item['status'],$this->config->scope()]);
    }
}
