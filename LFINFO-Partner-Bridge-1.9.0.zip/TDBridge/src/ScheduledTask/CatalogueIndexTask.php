<?php declare(strict_types=1);

namespace TDBridge\ScheduledTask;

use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTask;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;

final class CatalogueIndexTask extends ScheduledTask
{
    public static function getTaskName(): string { return 'td_bridge.catalogue_index'; }
    public static function getDefaultInterval(): int { return 60; }
    public static function shouldRescheduleOnFailure(): bool { return true; }
    public static function shouldRun(ParameterBagInterface $bag): bool { return true; }
}
