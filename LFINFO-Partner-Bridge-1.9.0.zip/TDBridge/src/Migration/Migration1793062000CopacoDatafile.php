<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793062000CopacoDatafile extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793062000; }
    public function update(Connection $db): void
    {
        $columns=array_column($db->fetchAllAssociative('SHOW COLUMNS FROM lf_supplier_offer'),'Field');
        foreach (['description'=>'LONGTEXT NULL','product_class'=>"VARCHAR(100) NOT NULL DEFAULT ''",'supplier_status'=>"VARCHAR(20) NOT NULL DEFAULT ''",'cost_inclusive'=>'DECIMAL(18,6) NULL','source_kind'=>"VARCHAR(20) NOT NULL DEFAULT 'manual'",'catalogue_available'=>'TINYINT(1) NOT NULL DEFAULT 1'] as $name=>$type) {
            if (!in_array($name,$columns,true)) { $db->executeStatement("ALTER TABLE lf_supplier_offer ADD COLUMN $name $type"); }
        }
        $db->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lf_copaco_refresh (
 id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
 status VARCHAR(32) NOT NULL DEFAULT 'idle',
 requested TINYINT(1) NOT NULL DEFAULT 0,
 next_attempt_at DATETIME(3) NULL,
 last_attempt_at DATETIME(3) NULL,
 last_success_at DATETIME(3) NULL,
 source_modified_at DATETIME(3) NULL,
 checksum VARCHAR(64) NULL,
 total INT NOT NULL DEFAULT 0,
 last_error VARCHAR(500) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $db->executeStatement('INSERT IGNORE INTO lf_copaco_refresh (id) VALUES (1)');
        $db->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lf_copaco_stage (
 batch VARCHAR(32) NOT NULL,
 part_number VARCHAR(100) NOT NULL,
 name VARCHAR(255) NOT NULL,
 description LONGTEXT NULL,
 manufacturer VARCHAR(255) NULL,
 manufacturer_number VARCHAR(255) NULL,
 ean VARCHAR(14) NULL,
 cost DECIMAL(18,6) NULL,
 currency VARCHAR(3) NOT NULL,
 stock INT NULL,
 product_class VARCHAR(100) NOT NULL,
 supplier_status VARCHAR(20) NOT NULL,
 cost_inclusive DECIMAL(18,6) NULL,
 PRIMARY KEY (batch,part_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    }
    public function updateDestructive(Connection $db): void {}
}
