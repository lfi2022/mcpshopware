<?php declare(strict_types=1);

namespace TDBridge\Supplier;

use TDBridge\Service\TdClient;
use TDBridge\Domain\ProductMapper;

final class TdSynnexConnector implements CatalogueConnector
{
    public function __construct(private readonly TdClient $client, private readonly ProductMapper $mapper) {}
    public function id(): string { return 'tdsynnex'; }
    public function products(array $parts, array $options, string $purpose): array
    {
        return $this->mapper->catalogue($this->client->catalogue(['tdsynnexPartNumber'=>$parts,'page'=>1,'pageSize'=>100,'includeStock'=>true,'includePrice'=>true]),$options['mapping'])['items'];
    }
}
