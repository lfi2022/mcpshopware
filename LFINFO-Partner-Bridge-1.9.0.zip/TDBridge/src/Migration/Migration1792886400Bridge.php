<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1792886400Bridge extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1792886400; }

    public function update(Connection $connection): void
    {
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS `td_bridge_product` (
    `part_number` VARCHAR(100) NOT NULL,
    `product_id` BINARY(16) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `sync_enabled` TINYINT(1) NOT NULL DEFAULT 1,
    `cost` DECIMAL(18,6) NULL,
    `currency` VARCHAR(3) NULL,
    `last_synced_at` DATETIME(3) NULL,
    `next_sync_at` DATETIME(3) NOT NULL,
    `last_error` VARCHAR(500) NULL,
    `created_at` DATETIME(3) NOT NULL,
    PRIMARY KEY (`part_number`),
    UNIQUE KEY `uniq.td_bridge.product` (`product_id`),
    KEY `idx.td_bridge.due` (`sync_enabled`, `next_sync_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS `td_bridge_job` (
    `id` VARCHAR(32) NOT NULL,
    `type` VARCHAR(20) NOT NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'queued',
    `parts` LONGTEXT NOT NULL,
    `options` LONGTEXT NOT NULL,
    `processed` INT NOT NULL DEFAULT 0,
    `total` INT NOT NULL,
    `succeeded` INT NOT NULL DEFAULT 0,
    `failed` INT NOT NULL DEFAULT 0,
    `attempts` INT NOT NULL DEFAULT 0,
    `last_error` VARCHAR(500) NULL,
    `available_at` DATETIME(3) NOT NULL,
    `created_at` DATETIME(3) NOT NULL,
    `updated_at` DATETIME(3) NOT NULL,
    PRIMARY KEY (`id`), KEY `idx.td_bridge.queue` (`status`, `available_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS `td_bridge_log` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
    `job_id` VARCHAR(32) NULL,
    `level` VARCHAR(10) NOT NULL,
    `part_number` VARCHAR(100) NULL,
    `message` VARCHAR(500) NOT NULL,
    `created_at` DATETIME(3) NOT NULL,
    PRIMARY KEY (`id`), KEY `idx.td_bridge.log_job` (`job_id`), KEY `idx.td_bridge.log_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    }

    public function updateDestructive(Connection $connection): void {}
}
