<?php declare(strict_types=1);

namespace TDBridge\ScheduledTask;

use Psr\Log\LoggerInterface;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;

#[AsMessageHandler(handles: CatalogueIndexTask::class)]
final class CatalogueIndexTaskHandler extends ScheduledTaskHandler
{
    public function __construct(EntityRepository $scheduledTaskRepository, LoggerInterface $logger, private readonly \TDBridge\Service\SupplierCache $cache, private readonly ?\TDBridge\Service\CopacoFeedSync $copaco = null)
    {
        parent::__construct($scheduledTaskRepository, $logger);
    }

    public function run(): void { $this->copaco?->refreshIfDue(); $this->cache->tick(); } // New opt-in scopes only; legacy index remains paused.
}
