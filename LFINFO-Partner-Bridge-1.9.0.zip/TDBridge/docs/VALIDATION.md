# Validation — 27 octobre 2026

Version livrée : **1.9.0**. Cible : **Shopware 6.7.15.1**.

Ajout 1.9.0 : 28 tests du composant et 17 parcours Chrome réussis, compilation Vite vérifiée. Navigation et séparation des connexions/règles communes vérifiées sur le composant réel avec des réponses fictives. Recherche globale contrôlée sur les trois sources, catégories indépendantes, absence de filtres cachés issus d'une ancienne recherche et poursuite malgré une erreur de fournisseur. Vue globale contrôlée à 390 px et filtres avancés dépliables vérifiés. Aucun import, index ou téléchargement FTP n'est déclenché par la recherche. Les suites métier et les validations des versions antérieures restent documentées ci-dessous ; aucune nouvelle connexion réelle n'est déclarée validée par cette refonte d'interface.

Ajout 1.8.0 : 35 contrôles Ingram réussis sur la recherche, les paramètres répétés, les références belges numériques, le PNA en lots, le token et son renouvellement, les droits, les 429, les données absentes, le sandbox, l'achat natif, les sources, comptes et suppressions. Campagnes communes sur trois fournisseurs et liaison atomique contrôlées avec MariaDB et doubles DAL. 26 tests du composant et 16 parcours Chrome ; régressions du pool PHP, de Copaco et 57 tests métier réussies. Aucun appel aux API réelles avec identifiants revendeur ; test HTTP simulé explicitement.

Ajout 1.7.0 : séparation des écrans Copaco et des paramètres FTP, renommage LFINFO Partner Bridge, déclenchement FTP à minuit Europe/Brussels. 43 contrôles Datafile Copaco réussis. Contrôles de la frontière UTC/jour belge, d'une seule réussite par jour, de l'heure d'hiver répétée, du prochain minuit, de la reprise après échec et de la conversion d'un succès historique UTC lors de la migration. Connexion FTP réelle toujours non testée faute d'accès ; récupération simulée dans la suite MariaDB.

Ajout 1.6.1 : validation intégrale du XML revendeur réel, 55 579 références uniques et 2 125 EAN non standard ignorés. Publication complète dans MariaDB isolée en environ 9,5 s sur le poste de développement, avec 10 Mo de mémoire maximale pour cette suite (mesure locale, sans engagement sur le serveur). Filtrage combiné et pagination vérifiés sur les données réelles ; aucun produit natif créé/modifié, aucun accès FTP effectué. 35 contrôles Datafile simulés et quatre assertions de publication réelle réussis. Les fichiers annexes ont été inventoriés ; ils ne sont pas encore intégrés au téléchargement/publication. Les fichiers privés ne sont ni suivis par Git ni distribués.

Ajout 1.6.0 : 31 contrôles Datafile Copaco (en plus des 28 multi-fournisseurs), schémas XML/CSV officiels, entités XML, flux invalide, stage multi-lots et publication atomique, encodage, description longue sans troncature SQL, fraîcheur MDTM, exclusion des articles disparus, récupération d'état orphelin, fenêtre nocturne et planification quotidienne. Les identifiants réels ne sont pas disponibles ; transport de téléchargement simulé, aucune connexion FTP/FTPS ni persistance Shopware réelle déclarée validée. 15 parcours Chrome et 25 tests du composant réussis.

Ajout 1.5.0 : 28 contrôles supplémentaires MariaDB sur les offres, la fusion de flux et son atomicité, les sources concurrentes, les références identiques entre fournisseurs, les snapshots périmés, l'achat natif avec forfait, les suppressions live/brouillon, la non-recréation depuis une tâche en attente, le rattrapage des anciens jobs et les campagnes globales multi fournisseurs. 25 tests du composant admin réussis. Nouveau parcours Chrome pour l'onglet Fournisseurs, l'aperçu sans écriture, la confirmation de l'import et la liaison explicite. Capture du composant réel en démonstration avec données fictives : assets/lfinfo-suppliers.png. Les suites de workers/pool et de régression Icecat/SQL restent valides. Aucune connexion API Copaco ou Ingram n'est déclarée validée.

Ajout 1.4.3 : reproduction MariaDB du schéma VARCHAR(20), refus Icecat HTTP 403 simulé réellement atteint, puis SQLSTATE 22001 sur status. Migration répétée vers VARCHAR(32) avec conservation de l’historique ; après correction, tâche terminée avec erreurs sans erreur SQL ni nouvelle tentative automatique. Cas mixte avec un succès et un refus : compteurs et progression conservés. Les messages Icecat n’exposent que le code numérique reconnu et un conseil local, avec contrôle des réponses HTML volumineuses et des secrets de test. Le motif réel du 403 du compte utilisateur n’a pas été lu : la version installée 1.4.1 le masquait.

Ajout 1.4.2 : arrêt demandé du pool pendant des enfants PHP réels, avec sorties 130 et 143 simulant une interruption pendant le démarrage, reprise sur la même instance, conservation d’une erreur réelle de code 1 et diagnostic stderr borné, libération des verrous et test du gestionnaire de signal enfant pendant une écriture. Les signaux TTY Linux réels ne sont pas reproduits sur cet hôte Windows ; les états de sortie et les gestionnaires Symfony sont vérifiés.

Ajout 1.4.1 : forfait d’achat de 50 € HT vérifié avec les TVA 21 % et 6 %, calcul de vente conservé, coût brut fournisseur conservé, absence de cumul après une seconde synchronisation. L’option CLI enregistre une limite de 4 et refuse 9 sans altérer la limite valide.

Ajout 1.4.0 : 17 contrôles MariaDB sur la détection des photos, les médias hérités et versions live, les verrous entre connexions, le plafond de workers, la récupération de tâche, les pauses communes et la reprise après échec d’écriture. Quatre contrôles supplémentaires utilisent Symfony Process réel pour lancer deux véritables enfants PHP dans une fixture locale, vérifier les limites et la fin des processus, ainsi que les contrats Symfony Console. Le test de pool ne démarre pas une instance Shopware ; les enfants exécutent un script de test. Les écritures produit restent vérifiées avec des doubles DAL.

Ajout 1.3.2 (historique) : 11 contrôles MariaDB sur la synchronisation globale réussis, notamment 1 001 produits en trois tâches, exclusion des produits en pause, options figées sans secrets, absence d’écriture produit à la mise en file, protection contre les doubles clics, options toutes désactivées et capacité insuffisante sans ajout partiel. Deux tests du composant et un parcours Chrome couvrent la confirmation et les erreurs. Aucune synchronisation de production n’a été déclenchée.

Ajout 1.3.1 : 10 contrôles du prix d’achat natif réussis avec MariaDB et doubles des repositories DAL, en utilisant la classe `Price` officielle Shopware. Nouvel import, synchronisation, coût sans majoration, TVA du produit existant, conservation des autres devises, désactivation de la synchronisation des prix et rejet des données manquantes/nulles ou d’une devise différente. Le champ `purchasePrices` et son accesseur ont été vérifiés dans les sources officielles Shopware 6.7.15.1. Les écritures DAL sur l’instance réelle restent à valider après installation.

| Contrôle | Résultat |
| --- | --- |
| Syntaxe PHP du plugin | PHP 8.3.36, tous les fichiers valides |
| Tests métier, SQL SQLite, OAuth et Icecat HTTP | 57 réussis |
| Tests du composant administration | 23 réussis |
| Parcours Chrome sur le véritable composant avec services simulés | 13 réussis |
| Recherche directe et cache fournisseur sur MariaDB 11.4.5 / Doctrine DBAL 4 | 31 contrôles réussis, dont 15 nouveaux sur le cache |
| Enrichissement Icecat avec MariaDB, HTTP simulé et doubles DAL/médias | 7 contrôles supplémentaires réussis |
| UUID contre les classes officielles du tag Shopware 6.7.15.1 | 7 contrôles réussis |
| Compilation Vite et enregistrement du module dans le paquet | Réussis |

Les tests MariaDB exécutent les migrations réelles et vérifient : absence de démarrage automatique, marques multiples, taille de page réduite par le fournisseur, pause/reprise, filtres SQL combinés, références non importées, comptes classes/sous-classes, chevauchements marque/catalogue complet, prix/stock absents et Retry-After. Des instantanés confirment que l’indexation ne modifie ni les liaisons des produits importés, ni les tâches d’import, ni l’ancien index retiré.

Les tests Icecat vérifient les jetons chiffrés et exclus des paramètres publics, les en-têtes HTTP, les identifiants fabricant/MPN et GTIN, les erreurs sans corps fournisseur et les téléchargements d’images locaux. Les tests d’enrichissement inspectent les écritures via des doubles DAL : conservation des textes, prix, stocks, catégories et couverture existants ; absence de doublon à la reprise ; remplacement explicite des textes ; refus sans liaison ; sauvegarde des textes malgré un échec d’image. Ce ne sont pas des écritures dans un vrai conteneur Shopware.

Les parcours Chrome vérifient la confirmation avant chargement, l’absence d’import lors d’une recherche, l’aperçu Icecat, l’import après sélection et confirmation, les catégories, la fermeture clavier et le rendu mobile. Les captures sont issues d’une démonstration avec données fictives et n’attestent pas d’une connexion fournisseur réelle.

## Limites de validation

Cette version n’a pas été déployée sur la boutique pendant ce développement. Aucun nouveau chargement fournisseur ni enrichissement réel n’y a été lancé. Les droits du compte Icecat, la résolution complète du conteneur Shopware, les écritures DAL réelles et la persistance des médias dans le stockage de l’instance restent à contrôler après installation.

Les lectures TD observées auparavant fonctionnent pour Lenovo et HP. Une requête minimale sans filtre a reçu HTTP 400 le 26 octobre : le catalogue complet reste dépendant des droits/paramètres acceptés par TD SYNNEX. La recherche directe reste disponible indépendamment du cache.

La [recette](RECETTE.md) et la [configuration Icecat](ICECAT.md) décrivent les vérifications avec une référence couverte, en brouillon.
