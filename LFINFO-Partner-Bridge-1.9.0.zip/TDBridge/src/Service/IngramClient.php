<?php declare(strict_types=1);

namespace TDBridge\Service;

use Psr\Cache\CacheItemPoolInterface;
use Symfony\Component\HttpClient\NoPrivateNetworkHttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueCriteria;
use TDBridge\Domain\CatalogueSearch;

final class IngramClient
{
    private readonly HttpClientInterface $http;
    public function __construct(HttpClientInterface $http,private readonly IngramConfig $config,private readonly CacheItemPoolInterface $cache){$this->http=new NoPrivateNetworkHttpClient($http);}
    public function test(): array { $this->config->ready();$this->token(true);return ['connected'=>true,'environment'=>$this->config->all()['environment'],'message'=>'Authentification Ingram réussie ; testez une recherche pour vérifier les droits catalogue.']; }
    public function search(array $input): array
    {
        $pairs=[['pageNumber',(string)CatalogueCriteria::integer($input['page']??1,1,100000)],['pageSize',(string)CatalogueCriteria::integer($input['pageSize']??25,1,100)]];
        foreach(['text'=>'keyword','brands'=>'vendor','vendorPartNumbers'=>'vendorPartNumber'] as $key=>$wire){foreach(CatalogueSearch::terms($input[$key]??'')as $value){$pairs[]=[$wire,$value];}}
        $category=$input['category']??'';if(!is_string($category)||mb_strlen($category)>200){throw new BridgeException('Catégorie Ingram invalide.');}if(trim($category)!==''){$pairs[]=['category',trim($category)];}
        $type=$input['type']??'IM::physical';if(!in_array($type,['IM::physical','IM::digital','IM::subscription','IM::any'],true)){throw new BridgeException('Type de produit Ingram invalide.');}$pairs[]=['type',$type];
        return $this->call('GET','/resellers/v6/catalog?'.implode('&',array_map(static fn($p)=>rawurlencode($p[0]).'='.rawurlencode($p[1]),$pairs)));
    }
    public function prices(array $parts): array
    {
        if(!$parts||count($parts)>50){throw new BridgeException('Le lot Ingram doit contenir entre 1 et 50 références.');}
        foreach($parts as $p){if(!is_string($p)||trim($p)===''||strlen($p)>100){throw new BridgeException('Référence Ingram invalide.');}}
        $result=$this->call('POST','/resellers/v6/catalog/priceandavailability?includeAvailability=true&includePricing=true&includeProductAttributes=true',['json'=>['products'=>array_map(static fn($p)=>['ingramPartNumber'=>$p,'quantityRequested'=>'1'],array_values(array_unique($parts)))]]);
        if(!array_is_list($result)){throw new BridgeException('Structure prix/disponibilités Ingram non reconnue.');}return $result;
    }
    private function token(bool $refresh=false): string
    {
        $v=$this->config->all();$secret=$this->config->secret();$key='lfinfo.ingram.token.'.hash('sha256',$v['clientId'].'|'.$v['oauthVersion'].'|'.$secret);$cached=$this->cache->getItem($key);
        if(!$refresh&&$cached->isHit()){return (string)$cached->get();}
        $data=$this->request('POST','https://api.ingrammicro.com/oauth/oauth'.$v['oauthVersion'].'/token',['headers'=>['Content-Type'=>'application/x-www-form-urlencoded'],'body'=>http_build_query(['grant_type'=>'client_credentials','client_id'=>$v['clientId'],'client_secret'=>$secret],'','&',PHP_QUERY_RFC3986)]);
        if(!is_string($data['access_token']??null)||strlen($data['access_token'])>20000||preg_match('/[\r\n]/',$data['access_token'])||$data['access_token']===''){throw new BridgeException('Jeton Ingram absent ou invalide.');}
        $seconds=$data['expires_in']??300;if(!is_numeric($seconds)||$seconds<=0){throw new BridgeException('Durée du jeton Ingram invalide.');}
        $cached->set($data['access_token']);$cached->expiresAfter(max(1,min(86400,(int)$seconds)-60));$this->cache->save($cached);return $data['access_token'];
    }
    private function call(string $method,string $path,array $options=[]): array
    {
        $this->config->ready();$v=$this->config->all();$base='https://api.ingrammicro.com'.($v['environment']==='sandbox'?'/sandbox':'');
        for($attempt=0;$attempt<2;++$attempt){
            $headers=['Authorization'=>'Bearer '.$this->token($attempt===1),'IM-CustomerNumber'=>$v['customerNumber'],'IM-CountryCode'=>'BE','IM-CorrelationID'=>bin2hex(random_bytes(16)),'Accept-Language'=>$v['language'],'Accept'=>'application/json'];if($v['senderId']!==''){$headers['IM-SenderID']=$v['senderId'];}
            try{return $this->request($method,$base.$path,$options+['headers'=>$headers]);}
            catch(BridgeException $e){if($e->httpStatus===401&&$attempt===0){continue;}throw $e;}
        }
        throw new BridgeException('Authentification Ingram refusée.');
    }
    private function request(string $method,string $url,array $options): array
    {
        try{
            $response=$this->http->request($method,$url,$options+['max_redirects'=>0,'timeout'=>30,'max_duration'=>60]);$status=$response->getStatusCode();
            if($status!==200){$retry=$response->getHeaders(false)['retry-after'][0]??'';$delay=ctype_digit((string)$retry)?min(86400,(int)$retry):max(0,(strtotime((string)$retry)?:0)-time());$response->cancel();
                $message=match(true){$status===401=>'Identifiants ou jeton Ingram refusés.',$status===403=>'Accès Ingram refusé : vérifiez le compte, le pays et les droits de l’application.',$status===429=>'Limite API Ingram atteinte. La reprise respecte Retry-After.',$status===404=>'Référence ou service Ingram introuvable.',$status>=500=>'Service Ingram temporairement indisponible.',default=>'Requête Ingram refusée (HTTP '.$status.').'};
                throw new BridgeException($message,$status===401?401:($status===429?429:($status>=500?502:422)),max($status===429?60:0,$delay));
            }
            $body='';foreach($this->http->stream($response)as $chunk){$body.=$chunk->getContent();if(strlen($body)>6000000){$response->cancel();throw new BridgeException('Réponse Ingram trop volumineuse. Réduisez la taille de page.');}}
            $data=json_decode($body,true,64,JSON_THROW_ON_ERROR);if(!is_array($data)||isset($data['errors'])){throw new BridgeException('Réponse Ingram inexploitable. Aucun produit modifié.');}return $data;
        }catch(BridgeException $e){throw $e;}catch(\JsonException){throw new BridgeException('Réponse JSON Ingram invalide.');}catch(\Throwable){throw new BridgeException('Connexion Ingram impossible ou interrompue.',502,60);}
    }
}
