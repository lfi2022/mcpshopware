<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793065000Ingram extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793065000; }
    public function update(Connection $db): void
    {
        $columns=array_column($db->fetchAllAssociative('SHOW COLUMNS FROM lf_supplier_offer'),'Field');
        if(!in_array('account_scope',$columns,true)){$db->executeStatement('ALTER TABLE lf_supplier_offer ADD COLUMN account_scope VARCHAR(64) NULL');}
    }
    public function updateDestructive(Connection $db): void {}
}
