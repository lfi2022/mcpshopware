<?php declare(strict_types=1);

namespace TDBridge\Supplier;

/** Connectors return ProductMapper's normalized product structure; no Shopware writes. */
interface CatalogueConnector
{
    public function id(): string;
    public function products(array $parts, array $options, string $purpose): array;
}
