# Recette avant mise en production

## Ajouts 1.3 — cache et Icecat

1. Mettre à jour le plugin avec `plugin:update TDBridge`, installer les assets, vider le cache, enregistrer les tâches planifiées et redémarrer les workers via leur superviseur. Les nouvelles tables doivent être vides et aucun chargement ne doit partir seul.
2. Dans le seul onglet Bridge, saisir `Lenovo;HP`, préparer puis confirmer le chargement. Vérifier progression, pause/reprise, comptes et dates. Aucun produit boutique ne doit être créé par le cache. Le catalogue complet reste optionnel et peut être refusé par l’API.
3. Attendre la fin du périmètre puis choisir **Recherche dans le catalogue chargé** : Lenovo + portables + ThinkBook + prix maximum + stock. Vérifier plusieurs pages, références jamais importées, sous-catégories et limites de couverture visibles.
4. Actualiser une seule marque et vérifier que les autres restent présentes. Simuler une interruption ou un HTTP 429 : le curseur ne doit pas avancer sur une page échouée.
5. Configurer le compte Channel Partner et les jetons selon [ICECAT.md](ICECAT.md). Tester l’aperçu d’une référence couverte : aucun produit ni média ne doit être créé par l’aperçu.
6. Activer Icecat, importer une référence en brouillon, puis contrôler description, caractéristiques et médias locaux. Vérifier que les erreurs Icecat sont signalées sans annuler l’import TD réussi.
7. Relancer **Mes produits → Enrichir Icecat** : pas de doublon média, pas de changement prix/stock/catégorie, couverture existante conservée. Les textes éditoriaux ne doivent être remplacés que si l’option est activée.
8. Relancer une synchronisation TD et vérifier la conservation des textes Icecat quand Icecat est activé. Aucun thème client, composant admin global ou navigation native supplémentaire ne doit être ajouté.

## Contrôles des fonctions TD existantes

Effectuer ces vérifications sur une copie de la boutique Shopware 6.7.15.1 avec un compte TD SYNNEX de test. Aucun identifiant ne doit être ajouté au dépôt ou au ZIP.

## Installation et droits

1. Installer le ZIP, activer le plugin, installer les assets et vider les caches. Vérifier les trois tables `td_bridge_*`, le menu et la tâche `td_bridge.process`.
2. Ouvrir les paramètres avec un administrateur. Vérifier qu’un utilisateur sans `td_bridge:read` reçoit un refus d’accès sur les actions de consultation.
3. Créer un rôle lecteur (`td_bridge.viewer`) et vérifier qu’il peut consulter/rechercher mais pas importer, configurer ou lire les commandes/factures.
4. Accorder `td_bridge.editor`, puis les droits supplémentaires de configuration/documents séparément et vérifier les actions correspondantes. Les liens vers les fiches produit nécessitent également les droits natifs Shopware sur les produits.

## API et mapping

1. Confirmer l’URL OAuth complète, l’encodage et les habilitations pays auprès du fournisseur. Enregistrer Client ID/secret et tester.
2. Utiliser « Voir un produit JSON ». Relever le conteneur de liste, la référence TD, le nom, le stock disponible vendable, le prix d’achat net et son code devise.
3. Adapter le mapping et lancer une recherche avec une référence exacte connue. Comparer prix et stock au portail TD SYNNEX. Vérifier s’il faut agréger plusieurs entrepôts : le mapping actuel lit une valeur simple et ne fait pas de somme.
4. Tester fabricant, EAN, stock uniquement, statut et dates. Confirmer que la pagination de votre compte commence à 1 ; la documentation fournie n’en indique pas la base.
5. Tester les commandes et factures : structure des listes, statut répété, lignes détaillées et pagination. Les structures non reconnues restent consultables via la réponse JSON complète.

## Import et mises à jour

1. Choisir la TVA et la devise principale Shopware, conserver le mode brouillon et importer deux références. Traiter la tâche depuis l’onglet Imports.
2. Vérifier dans Shopware nom, fabricant, EAN, description, SKU, stock après réserve, catégorie, visibilité, prix HT et TTC. Vérifier que le produit reste inactif.
3. Réimporter les mêmes références : vérifier qu’aucun produit/fabricant n’est dupliqué.
4. Créer un SKU en collision : vérifier le refus d’import et la conservation du produit existant.
5. Vérifier qu’un prix absent, nul ou en autre devise ne crée jamais un produit gratuit et qu’un stock absent ne met jamais implicitement le produit à zéro.
6. Modifier les options de synchronisation, créer une nouvelle tâche et vérifier séparément stocks/prix/contenu. Les tâches déjà créées conservent leurs options.
7. Suspendre une référence et vérifier qu’une synchronisation la laisse inchangée. Un réimport explicite reste possible selon les règles d’import.

## Recherche fournisseur avant import (1.2.0)

1. Rechercher Lenovo avec la catégorie Ordinateurs portables sans construire d’index.
2. Combiner plusieurs marques séparées par ; avec texte, prix, stock et statut.
3. Vérifier la progression, les résultats partiels et la continuation.
4. Vérifier qu’une recherche ne crée aucun produit, catégorie, tâche d’import ou entrée de cache catalogue et ne lance aucun travail en arrière-plan.
5. Sélectionner un produit, ouvrir la revue d’import, annuler : aucune création.
6. Confirmer explicitement un import en brouillon et vérifier que seules les références choisies sont traitées.
7. Vérifier que les actions historiques d’indexation sont désactivées après mise à jour.

## File, exploitation et cycle de vie

1. Activer les workers et la synchronisation automatique ; vérifier le déclenchement après échéance.
2. Lancer deux workers simultanément et vérifier qu’un seul obtient le verrou du bridge.
3. Simuler 429/5xx et vérifier le report sans boucle rapide. Simuler un refus OAuth et vérifier l’état d’échec et le journal sans secret.
4. Interrompre le processus après écriture d’un lot puis le relancer ; vérifier la reprise sans doublon après le délai de récupération.
5. Annuler une tâche en attente, puis la relancer. Vérifier progression et liens vers le journal. Une tâche en cours ne peut pas être annulée au milieu d’une écriture produit.
6. Contrôler les rétentions et exports. Les exports CSV portent sur la page courante et neutralisent les cellules commençant par les caractères usuels des formules.
7. Désactiver/réactiver et désinstaller/réinstaller en préproduction : vérifier la conservation des produits et l’arrêt des traitements lorsque le plugin est désactivé.

Critère de livraison opérationnelle : recette validée avec le format de réponse et les habilitations réels du compte, et workers supervisés sur le serveur cible.

## Prix d?achat natif (1.3.1)

1. Importer un produit avec un co?t de 100 EUR HT, une TVA de 21 % et une majoration de 15 % : v?rifier dans la fiche Shopware un achat ? 100 HT / 121 TTC et une vente ? 115 HT / 139,15 TTC.
2. Sur un produit d?j? li? dont le prix d?achat est vide, lancer une nouvelle synchronisation avec ? Prix de vente et d?achat ? activ? : le champ doit ?tre renseign?. Modifier la TVA du produit et v?rifier que la synchronisation utilise cette TVA existante.
3. R?importer la r?f?rence : v?rifier la mise ? jour du prix d?achat sans doublon produit et la conservation des prix explicites des autres devises.
4. D?sactiver la synchronisation des prix : les prix de vente et d?achat existants doivent rester inchang?s. Un prix fournisseur absent, nul ou en autre devise doit refuser la mise ? jour des prix sans effacer les valeurs existantes.
