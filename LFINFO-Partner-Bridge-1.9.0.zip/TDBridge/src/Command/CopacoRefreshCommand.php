<?php declare(strict_types=1);

namespace TDBridge\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use TDBridge\Service\CopacoFeedSync;
use TDBridge\Domain\BridgeException;

#[AsCommand(name:'tdbridge:copaco:refresh',description:'Charge le Datafile Copaco configuré sans créer ni modifier de produit Shopware.')]
final class CopacoRefreshCommand extends Command
{
    public function __construct(private readonly CopacoFeedSync $sync) { parent::__construct(); }
    protected function execute(InputInterface $input,OutputInterface $output): int
    {
        try { $this->sync->request();$result=$this->sync->refreshIfDue();$output->writeln(json_encode($result,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));return $result['state']==='failed'?Command::FAILURE:Command::SUCCESS; }
        catch(BridgeException $e){$output->writeln('<error>'.htmlspecialchars($e->getMessage()).'</error>');return Command::FAILURE;}
    }
}
