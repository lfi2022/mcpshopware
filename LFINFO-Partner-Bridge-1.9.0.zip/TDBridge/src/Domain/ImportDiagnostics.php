<?php declare(strict_types=1);

namespace TDBridge\Domain;

use Shopware\Core\Framework\DataAbstractionLayer\Write\WriteException;
use Shopware\Core\Framework\Validation\WriteConstraintViolationException;
use Doctrine\DBAL\Exception\DriverException;

final class ImportDiagnostics
{
    public static function message(\Throwable $error): string
    {
        if ($error instanceof BridgeException) { return $error->getMessage(); }
        if ($error instanceof DriverException) {
            $state = preg_replace('/[^A-Z0-9]/', '', (string) $error->getSQLState());
            $hint = '';
            if ($state === '42S22' && preg_match('/Unknown column [\x27`]([a-zA-Z0-9_.]+)[\x27`]/', $error->getMessage(), $match)) {
                $hint = ' Colonne ' . $match[1] . ' absente : vérifiez la mise à jour et les migrations du plugin.';
            }
            if ($state === '22001' && preg_match('/Data too long for column [\x27`]([a-zA-Z0-9_]+)[\x27`]/i', $error->getMessage(), $match)) {
                $hint = ' Colonne ' . mb_substr($match[1], 0, 100) . ' trop courte : vérifiez les migrations du plugin.';
            }
            return 'Erreur de base de données (SQLSTATE ' . ($state ?: 'inconnu') . ').' . $hint;
        }
        if ($error instanceof WriteException || $error instanceof WriteConstraintViolationException) {
            $details = self::validationErrors($error->getErrors(false));
            if ($details !== '') { return 'Validation Shopware : ' . $details; }
        }
        if ($error instanceof \Error && preg_match('/Call to undefined method ([A-Za-z0-9_\\\\]+)::([A-Za-z0-9_]+)\(\)/', $error->getMessage(), $match)) {
            return 'Erreur de compatibilité PHP : méthode ' . $match[1] . '::' . $match[2] . ' introuvable. Mettez le plugin à jour.';
        }
        $class = substr(strrchr('\\' . $error::class, '\\'), 1);
        return 'Écriture Shopware refusée (' . $class . '). Vérifiez la TVA, la devise, la catégorie, le canal et les journaux du serveur.';
    }

    public static function validationErrors(iterable $errors): string
    {
        $messages = [];
        foreach ($errors as $error) {
            if (!is_array($error)) { continue; }
            $pointer = preg_replace('/[^a-zA-Z0-9_\/.\-]/', '', (string) ($error['source']['pointer'] ?? '/'));
            $code = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) ($error['code'] ?? 'validation'));
            $detail = strip_tags((string) ($error['detail'] ?? 'Valeur refusée.'));
            $detail = preg_replace('/https?:\/\/[^\s]+/i', '[URL masquée]', $detail);
            $detail = preg_replace('/Bearer\s+[a-zA-Z0-9._~+\/=\-]+/i', 'Bearer [masqué]', $detail);
            $detail = preg_replace('/(client_secret|access_token|refresh_token|password)\s*[:=]\s*[^\s,;]+/i', '$1=[masqué]', $detail);
            $messages[] = mb_substr($pointer, 0, 100) . ' [' . mb_substr($code, 0, 60) . '] ' . mb_substr($detail, 0, 200);
            if (count($messages) >= 3) { break; }
        }
        return mb_substr(implode(' ; ', $messages), 0, 470);
    }
}
