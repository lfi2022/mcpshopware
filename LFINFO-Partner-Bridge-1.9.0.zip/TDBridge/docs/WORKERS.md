# Traitement rapide et pool adaptatif — 1.4.0

## Arrêt et exécution détachée — 1.4.2

`Ctrl+C` demande l’arrêt du coordinateur. Depuis 1.4.2, les commandes enfants finissent le lot commencé et ne prennent pas le suivant. Si l’interruption atteint un enfant avant son initialisation complète et qu’il sort avec 130/143, le coordinateur reconnaît l’arrêt demandé. Les autres échecs restent des erreurs avec un diagnostic serveur. Le champ `launched` est le nombre cumulé de processus lancés pendant la session, pas le nombre simultané.

Les lignes d’état ne sont imprimées que lorsqu’elles changent : rester sur `workers:2, maximum:8, demand:2` ne signifie pas que le pool est bloqué.

Dans l’installation Docker identifiée pendant la recette utilisateur, après mise à jour du plugin et arrêt de l’ancien coordinateur, cette commande lance une seule session d’une heure sans dépendre du terminal SSH :

```bash
docker exec -d -w /var/www/html sw-shop-70e6ac-web-1 sh -c 'exec php bin/console tdbridge:worker --max-workers=8 --seconds=3600 >> var/log/tdbridge-worker.log 2>&1'
```

Lire son journal :

```bash
docker exec sw-shop-70e6ac-web-1 tail -n 50 /var/www/html/var/log/tdbridge-worker.log
```

Le nom du conteneur doit être adapté s’il change. Cette session s’arrête après son budget d’une heure et la fin des lots en cours ; Supervisor reste la solution de maintien permanent décrite plus bas. Aucun de ces processus n’a été lancé sur le serveur depuis l’environnement de développement.

Depuis 1.4.1, l’option `--max-workers` permet de régler la limite depuis le serveur. Elle **enregistre le réglage global du plugin**, également visible dans l’administration. Elle accepte de 1 à 8. Sans cette option, la commande conserve le réglage enregistré.

## Augmenter la vitesse depuis le serveur

1. Mettre à jour le plugin et arrêter l’ancien coordinateur avec son superviseur avant de lancer sa nouvelle instance.
2. Dans le conteneur/environnement PHP de Shopware, depuis sa racine, démarrer avec une limite de 4 :

```bash
php bin/console tdbridge:worker --max-workers=4 --seconds=3600
```

3. Si CPU, mémoire, base et API le permettent, remplacer `4` par `8` puis redémarrer le coordinateur. Huit est le plafond de cette version. Le pool peut alors démarrer jusqu’à huit enfants selon le nombre de tâches prêtes ; ce n’est pas une promesse de huit fois plus de débit.
4. Pour un fonctionnement permanent, adapter la ligne `command=` du programme Supervisor ci-dessous avec `--max-workers=4` ou `--max-workers=8`. Garder **`numprocs=1`** : Supervisor maintient un coordinateur, et TD Bridge crée ses enfants. Après modification de configuration, utiliser `supervisorctl reread`, `supervisorctl update`, puis vérifier `supervisorctl status`. Si seul le réglage de l’administration a changé, redémarrer le coordinateur pour recharger sa configuration.

Exemple de ligne pour huit enfants maximum, à adapter aux chemins réels :

```ini
command=/usr/local/bin/php /var/www/html/bin/console tdbridge:worker --max-workers=8 --seconds=3600
numprocs=1
```

Vérifier les ressources de l’hôte et, si Docker est utilisé, les limites CPU/mémoire du conteneur PHP. Ces commandes servent au diagnostic ; elles ne changent pas les limites :

```bash
nproc
free -h
php --ini
php -r 'echo "PHP=",PHP_BINARY,PHP_EOL,"memory_limit=",ini_get("memory_limit"),PHP_EOL,"proc_open=",function_exists("proc_open")?"oui":"non",PHP_EOL;'
```

Le pool utilise PHP **CLI**, donc augmenter le nombre de processus PHP-FPM n’augmente pas son plafond. La limite mémoire PHP s’applique par processus ; tenir compte également du coordinateur, des workers Shopware habituels et du reste de la boutique. Les enfants relisent la configuration PHP CLI : une option `php -d memory_limit=...` appliquée au seul coordinateur n’est pas transmise automatiquement aux commandes enfants. La limite du conteneur peut être inférieure à la RAM affichée par l’hôte.

Le parallélisme nécessite plusieurs tâches prêtes, ce que produisent les deux actions groupées. Un HTTP 429 impose une pause partagée même avec huit workers. Si les pauses API se multiplient, augmenter encore le nombre de processus ne résout pas ce goulot d’étranglement. Examiner l’état dans Mes produits et les journaux plutôt que de multiplier les coordinateurs.

Références : [Supervisor, paramètres de programme](https://www.supervisord.org/configuration.html#program-x-section-settings), [PHP, limite mémoire](https://www.php.net/manual/en/ini.core.php#ini.memory-limit).

Les deux actions groupées sont dans **TD Bridge → Mes produits**, au-dessus du filtre : **Tout synchroniser maintenant** et **Enrichir Icecat — produits sans photo**. Elles couvrent toutes les pages des produits liés dont le suivi est actif, avec confirmation. Elles ne chargent pas le catalogue complet et n’importent pas de nouvelles références.

## Mise à jour et activation

Arrêter les anciens workers avant de remplacer le code, puis effectuer la mise à jour dans l’environnement PHP de Shopware. Cela évite qu’un ancien worker interprète les nouveaux types de tâches avec l’ancien code.

```bash
bin/console plugin:refresh
bin/console plugin:update TDBridge
bin/console assets:install
bin/console cache:clear
bin/console scheduled-task:register
```

Recharger complètement l’administration. Redémarrer les workers Shopware habituels avec leur superviseur.

La tâche propre au plugin passe de son ancien intervalle par défaut de 60 secondes à 15 secondes et traite plusieurs lots par passage, avec un budget de 20 secondes entre les lots. Si elle s’exécute en CLI et que PHP autorise `proc_open`, elle utilise automatiquement le pool borné. En mode worker web de l’administration, elle traite plusieurs lots en série, sans créer de processus système depuis une requête HTTP.

Pour un traitement continu plus réactif, lancer **une seule instance** du coordinateur dans le même conteneur/environnement et avec le même utilisateur que Shopware :

```bash
php bin/console tdbridge:worker --seconds=3600
```

Le coordinateur crée lui-même les processus PHP utiles selon le nombre de tâches prêtes. Il ne faut pas lancer manuellement huit copies. La limite initiale est **2**, modifiable dans **TD Bridge → Paramètres → Maximum de workers simultanés**, entre 1 et 8. En l’absence de travail, aucun enfant n’est maintenu inutilement. Quand la charge diminue, les requêtes en cours finissent avant l’arrêt des enfants. La durée du coordinateur est un budget de lancement ; une requête déjà commencée peut se terminer après ce délai.

## Maintien automatique avec Supervisor

Exemple à adapter au chemin PHP, au répertoire et à l’utilisateur effectifs du conteneur. Le fichier n’est pas installé automatiquement par le plugin et aucun service système n’a été modifié sur la boutique pendant le développement.

```ini
[program:tdbridge-worker]
directory=/var/www/html
command=/usr/local/bin/php /var/www/html/bin/console tdbridge:worker --seconds=3600
user=www-data
numprocs=1
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stopwaitsecs=960
stdout_logfile=/var/www/html/var/log/tdbridge-worker.log
stderr_logfile=/var/www/html/var/log/tdbridge-worker-error.log
```

Après configuration de Supervisor, faire son `reread`, `update` et démarrer le programme. Un gestionnaire de services équivalent peut relancer la même commande. Aucun accès SSH n’était disponible dans cet environnement pour installer ce service à votre place.

Le bouton **Traiter un lot** reste disponible pour un passage manuel. La commande ponctuelle reste utilisable :

```bash
php bin/console tdbridge:process --batches=100 --seconds=20
```

## Fonctionnement et limites

- Les synchronisations groupées sont découpées en tâches de 50 références. Les appels TD contiennent jusqu’à 50 références, au lieu de 10 auparavant. Les tâches historiques plus grandes continuent à être traitées par tranches de 50.
- Icecat traite une référence par passage d’un enfant, afin de borner les téléchargements et de pouvoir partager le travail entre les enfants. Les campagnes sans photo sont découpées par 25 références. Les images sont activées pour cette campagne ; les autres contenus suivent les réglages Icecat enregistrés.
- Une photo est reconnue via les associations média de la version live, avec un fichier d’un type MIME image. Les photos héritées d’un parent sont prises en compte ; un PDF ou une image présente seulement dans une version de travail ne suffit pas. L’absence de photo est contrôlée à la sélection, avant l’appel fournisseur, puis dans l’enrichissement avant modification de la fiche produit.
- Le verrou global ne couvre plus les appels réseau. Les verrous de connexion par tâche, par référence et par emplacement de worker permettent le parallélisme sans traiter la même tâche deux fois. Une connexion qui disparaît libère ses verrous ; le prochain worker reprend au dernier produit enregistré.
- Chaque produit a son propre point de reprise dans la tâche. Une erreur temporaire sur le produit suivant conserve les compteurs des produits réussis. Les limites TD/Icecat HTTP 429 et `Retry-After` créent une pause commune aux workers. Augmenter le nombre de processus ne contourne pas les quotas fournisseur.
- La file accepte au plus 1 000 tâches actives. Une action groupée qui ne tient pas dans la capacité restante est refusée entièrement. Les produits en pause sont exclus et un suivi suspendu après la mise en file est également respecté pour les enrichissements groupés.
- Le maximum de processus est une limite à adapter aux ressources PHP/mémoire du serveur. L’ajustement automatique utilise la charge de la file ; ce n’est pas une mesure de la mémoire disponible de l’hôte. Les opérations déjà commencées peuvent finir après un changement de limite.

L’état des workers et la dernière pause API sont visibles dans **Mes produits**. Les résultats et erreurs restent dans **Imports** et **Journal**. Le pool n’enrichit jamais de références non sélectionnées ou de produits déjà illustrés via l’action groupée sans photo.
