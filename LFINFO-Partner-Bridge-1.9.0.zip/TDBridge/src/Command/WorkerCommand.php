<?php declare(strict_types=1);

namespace TDBridge\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Command\SignalableCommandInterface;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use TDBridge\Domain\CatalogueCriteria;
use TDBridge\Domain\BridgeException;
use Symfony\Component\Console\Formatter\OutputFormatter;
use TDBridge\Service\WorkerPool;
use TDBridge\Service\Settings;
use Psr\Log\LoggerInterface;

#[AsCommand(name: 'tdbridge:worker', description: 'Adapte automatiquement le nombre de workers PHP à la file LFINFO Partner Bridge.')]
final class WorkerCommand extends Command implements SignalableCommandInterface
{
    public function __construct(private readonly WorkerPool $pool, private readonly Settings $settings, private readonly ?LoggerInterface $logger = null) { parent::__construct(); }
    protected function configure(): void {
        $this->addOption('seconds', null, InputOption::VALUE_REQUIRED, 'Durée du coordinateur, hors fin des requêtes en cours', '3600');
        $this->addOption('max-workers', null, InputOption::VALUE_REQUIRED, 'Enregistre la limite globale LFINFO Partner Bridge (1 à 8) avant le démarrage');
    }
    public function getSubscribedSignals(): array { return defined('SIGTERM') ? [SIGTERM, SIGINT] : []; }
    public function handleSignal(int $signal, int|false $previousExitCode = 0): int|false { $this->pool->stop(); return false; }
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $seconds = CatalogueCriteria::integer($input->getOption('seconds'), 1, 86400);
            if ($input->getOption('max-workers') !== null) {
                $this->settings->save(['workerMax' => CatalogueCriteria::integer($input->getOption('max-workers'), 1, 8)]);
            }
            $last = '';
            $result = $this->pool->run($seconds, static function (array $state) use ($output, &$last): void {
                $line = json_encode($state, JSON_THROW_ON_ERROR);
                if ($line !== $last) { $output->writeln($line); $last = $line; }
            });
            $output->writeln(json_encode($result, JSON_THROW_ON_ERROR)); return Command::SUCCESS;
        } catch (BridgeException $e) { $output->writeln('<error>' . OutputFormatter::escape($e->getMessage()) . '</error>'); return Command::FAILURE; }
        catch (\Throwable $e) { $this->logger?->error('LFINFO Partner Bridge worker pool failed.', ['exception' => $e]); $output->writeln('<error>Échec du pool LFINFO Partner Bridge. Vérifiez les journaux serveur et les droits PHP CLI.</error>'); return Command::FAILURE; }
    }
}
