<?php declare(strict_types=1);

namespace TDBridge\Service;

use TDBridge\Domain\BridgeException;

final class CopacoFtpDownload implements CopacoDownload
{
    public function download(array $config,string $password): array
    {
        if (!function_exists('curl_init')) { throw new BridgeException('Extension PHP cURL requise pour le Datafile Copaco.'); }
        $addresses=[];
        foreach (dns_get_record($config['host'],DNS_A|DNS_AAAA)?:[] as $record) {
            $ip=$record['ip']??$record['ipv6']??null;
            if (!$ip) { continue; }
            if (!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) { throw new BridgeException('Le serveur Datafile doit résoudre exclusivement vers des adresses publiques.'); }
            $addresses[]=$ip;
        }
        if (!$addresses) { throw new BridgeException('Serveur Datafile introuvable. Vérifiez son nom auprès de Copaco.'); }
        $path=tempnam(sys_get_temp_dir(),'lf-copaco-');
        if (!$path) { throw new BridgeException('Dossier temporaire serveur indisponible.'); }
        $stream=fopen($path,'wb');if(!$stream){@unlink($path);throw new BridgeException('Fichier temporaire Datafile non inscriptible.');}$curl=curl_init();$size=0;$overflow=false;$success=false;
        try {
            $encoded=implode('/',array_map('rawurlencode',explode('/',$config['path'])));
            $ip=$addresses[0];$resolved=str_contains($ip,':')?'['.$ip.']':$ip;
             $options=[CURLOPT_URL=>'ftp://'.$config['host'].':'.$config['port'].$encoded,CURLOPT_USERNAME=>$config['username'],CURLOPT_PASSWORD=>$password,
                CURLOPT_PROXY=>'',CURLOPT_RESOLVE=>[$config['host'].':'.$config['port'].':'.$resolved],CURLOPT_FOLLOWLOCATION=>false,
                CURLOPT_USE_SSL=>$config['protocol']==='ftps'?CURLUSESSL_ALL:CURLUSESSL_NONE,CURLOPT_FTPSSLAUTH=>CURLFTPAUTH_TLS,
                CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FTP_SKIP_PASV_IP=>true,CURLOPT_FTP_USE_EPSV=>true,
                CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>180,CURLOPT_LOW_SPEED_LIMIT=>512,CURLOPT_LOW_SPEED_TIME=>30,CURLOPT_FILETIME=>true,
                CURLOPT_WRITEFUNCTION=>static function($handle,string $chunk)use($stream,&$size,&$overflow):int{
                    $size+=strlen($chunk);if($size>200000000){$overflow=true;return 0;}$written=fwrite($stream,$chunk);return $written===false?0:$written;
                }];
            $options[defined('CURLOPT_PROTOCOLS_STR')?constant('CURLOPT_PROTOCOLS_STR'):constant('CURLOPT_PROTOCOLS')]=defined('CURLOPT_PROTOCOLS_STR')?'ftp':CURLPROTO_FTP;
            curl_setopt_array($curl,$options);
            if (curl_exec($curl)===false) { throw new BridgeException($overflow?'Datafile supérieur à 200 Mo.':'Téléchargement Copaco refusé ou impossible (code transport '.curl_errno($curl).'). Vérifiez protocole, compte, chemin et certificat.'); }
            $modified=(int)curl_getinfo($curl,CURLINFO_FILETIME);
            if (!$size || $modified<=0) { throw new BridgeException('Datafile vide ou date distante indisponible (MDTM requis). Aucun catalogue publié.'); }
            $success=true;return ['path'=>$path,'modified'=>$modified];
        } finally {
            $curl=null;fclose($stream);if(!$success){@unlink($path);}
        }
    }
}
