import './page';

Shopware.Service('privileges').addPrivilegeMappingEntry({
    category: 'permissions', parent: null, key: 'td_bridge',
    roles: {
        viewer: { privileges: ['td_bridge:read', 'product:read', 'product_translation:read'], dependencies: [] },
        editor: { privileges: ['td_bridge:import'], dependencies: ['td_bridge.viewer'] },
    },
});
Shopware.Service('privileges').addPrivilegeMappingEntry({
    category: 'additional_permissions', parent: null, key: 'td_bridge',
    roles: {
        configure: { privileges: ['td_bridge:configure', 'tax:read', 'currency:read', 'category:read', 'category_translation:read', 'sales_channel:read', 'sales_channel_translation:read'], dependencies: ['td_bridge.viewer'] },
        documents: { privileges: ['td_bridge:documents'], dependencies: ['td_bridge.viewer'] },
    },
});

const snippets = {
    'td-bridge': { title: 'LFINFO Partner Bridge', description: 'Catalogue, imports et synchronisation fournisseur' },
    'sw-privileges': {
        permissions: { td_bridge: { label: 'LFINFO Partner Bridge' } },
        additional_permissions: { td_bridge: { label: 'LFINFO Partner Bridge', configure: 'Configurer la connexion et les imports', documents: 'Consulter les commandes et factures fournisseur' } },
    },
};

Shopware.Module.register('td-bridge', {
    type: 'plugin', name: 'TDBridge', title: 'td-bridge.title', description: 'td-bridge.description',
    color: '#087f8c', icon: 'regular-products',
    snippets: { 'fr-FR': snippets, 'en-GB': snippets, 'de-DE': snippets },
    routes: { index: { component: 'td-bridge-page', path: 'index', meta: { privilege: 'td_bridge.viewer' } } },
    navigation: [{ id: 'td-bridge', label: 'td-bridge.title', color: '#087f8c', path: 'td.bridge.index', icon: 'regular-products', parent: 'sw-catalogue', position: 95, privilege: 'td_bridge.viewer' }],
});
