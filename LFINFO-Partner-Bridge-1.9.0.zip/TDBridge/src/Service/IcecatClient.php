<?php declare(strict_types=1);

namespace TDBridge\Service;

use Symfony\Component\HttpClient\NoPrivateNetworkHttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\IcecatContent;
use TDBridge\Domain\IcecatErrors;

final class IcecatClient
{
    private readonly HttpClientInterface $http;
    public function __construct(HttpClientInterface $http, private readonly Settings $settings) { $this->http = new NoPrivateNetworkHttpClient($http); }

    public function product(array $item, ?string $language = null): array
    {
        $settings = $this->settings->all();
        $apiToken = $this->settings->icecatToken('ApiToken');
        if ($apiToken === '' && $settings['icecatUsername'] === '') { throw new BridgeException('Renseignez votre nom utilisateur ou jeton API Open Icecat dans les paramètres.'); }
        $query = ['lang' => $language ?? $settings['icecatLanguage'], 'content' => 'generalinfo,image,gallery,featuregroups'];
        if ($apiToken === '') { $query['shopname'] = $settings['icecatUsername']; }
        if (!empty($item['manufacturer']) && !empty($item['manufacturerNumber'])) { $query += ['Brand' => $item['manufacturer'], 'ProductCode' => $item['manufacturerNumber']]; }
        if (!empty($item['ean']) && preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D', $item['ean'])) { $query['GTIN'] = $item['ean']; }
        if (!isset($query['Brand'], $query['ProductCode']) && !isset($query['GTIN'])) { throw new BridgeException('Icecat nécessite un EAN ou le fabricant et sa référence produit.'); }
        try {
            $response = $this->http->request('GET', 'https://live.icecat.biz/api', ['query' => $query, 'headers' => array_filter(['api-token' => $apiToken, 'content-token' => $this->settings->icecatToken('ContentToken')]), 'timeout' => 15, 'max_duration' => 30, 'max_redirects' => 0]);
            $status = $response->getStatusCode();
            if ($status !== 200) {
                $retry = $response->getHeaders(false)['retry-after'][0] ?? '60';
                $delay = ctype_digit($retry) ? (int) $retry : max(60, (strtotime($retry) ?: time()) - time());
                $errorBody = '';
                foreach ($this->http->stream($response) as $chunk) {
                    $errorBody .= $chunk->getContent();
                    if (strlen($errorBody) > 65536) { $response->cancel(); $errorBody = ''; break; }
                }
                $errorData = json_decode($errorBody, true);
                $code = is_array($errorData) ? IcecatErrors::code($errorData) : null;
                throw new BridgeException(IcecatErrors::message($status, $code), $status === 429 ? 429 : ($status >= 500 ? 502 : 422), $delay);
            }
            $body = '';
            foreach ($this->http->stream($response) as $chunk) {
                $body .= $chunk->getContent();
                if (strlen($body) > 5000000) { $response->cancel(); throw new BridgeException('Fiche Icecat trop volumineuse.', 422); }
            }
            $data = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
            if (($data['msg'] ?? '') !== 'OK' || empty($data['data']['GeneralInfo']['IcecatId'])) { throw new BridgeException(IcecatErrors::message($status, IcecatErrors::code($data)), 422); }
            return IcecatContent::map($data['data']);
        } catch (BridgeException $e) { throw $e; }
        catch (\Throwable) { throw new BridgeException('Impossible de lire la fiche Icecat. Réessayez ultérieurement.', 502); }
    }

    /** Download files server-side. Signed URLs/tokens never reach admin or storefront. */
    public function image(string $url): array
    {
        $parts = parse_url($url);
        $host = strtolower($parts['host'] ?? '');
        if (($parts['scheme'] ?? '') !== 'https' || !($host === 'icecat.biz' || str_ends_with($host, '.icecat.biz')) || isset($parts['user']) || isset($parts['pass']) || (isset($parts['port']) && $parts['port'] !== 443)) { throw new BridgeException('Hôte image Icecat non autorisé.', 422); }
        $file = tempnam(sys_get_temp_dir(), 'td-icecat-');
        if ($file === false) { throw new BridgeException('Stockage temporaire indisponible.', 500); }
        try {
            $response = $this->http->request('GET', $url, ['timeout' => 15, 'max_duration' => 30, 'max_redirects' => 0, 'buffer' => false]);
            if ($response->getStatusCode() !== 200) {
                $status = $response->getStatusCode();
                $retry = $response->getHeaders(false)['retry-after'][0] ?? '60';
                throw new BridgeException('Téléchargement image Icecat refusé.', $status === 429 ? 429 : ($status >= 500 ? 502 : 422), ctype_digit($retry) ? (int) $retry : max(60, (strtotime($retry) ?: time()) - time()));
            }
            $stream = fopen($file, 'wb');
            if (!$stream) { throw new BridgeException('Stockage temporaire indisponible.', 500); }
            $size = 0;
            try {
                foreach ($this->http->stream($response) as $chunk) {
                    $bytes = $chunk->getContent(); $size += strlen($bytes);
                    if ($size > 12000000) { $response->cancel(); throw new BridgeException('Image Icecat supérieure à 12 Mo.', 422); }
                    if (fwrite($stream, $bytes) !== strlen($bytes)) { throw new BridgeException('Écriture image impossible.', 500); }
                }
            } finally { fclose($stream); }
            $info = @getimagesize($file);
            $mime = $info['mime'] ?? '';
            $extension = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
            if (!$extension || $info[0] * $info[1] > 40000000) { throw new BridgeException('Format ou dimensions image Icecat refusés.', 422); }
            return ['path' => $file, 'mime' => $mime, 'extension' => $extension, 'size' => $size];
        } catch (\Throwable $e) {
            @unlink($file);
            if ($e instanceof BridgeException) { throw $e; }
            throw new BridgeException('Téléchargement image Icecat impossible.', 502);
        }
    }
}
