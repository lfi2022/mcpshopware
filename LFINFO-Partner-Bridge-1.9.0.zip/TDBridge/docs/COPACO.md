# Copaco Datafile — connexion 1.7.0

## Fichiers réellement reçus — 27 octobre 2026

Le catalogue XML de 58 485 177 octets contient 55 579 références uniques. Le format réel emploie item, vendor, price, stock, status et l'attribut currency en minuscules ; la version 1.6.1 accepte aussi le format à casse mixte du manuel. Prix et stocks sont numériques, en EUR, sans valeur négative dans le fichier examiné. Les statuts comprennent aussi 15 et 16, conservés comme codes fournisseur.

2 125 EAN non vides ont une longueur ou un contenu non standard ; 20 894 articles n'en fournissent pas. Le lecteur ne déduit pas de zéros manquants et ne fabrique pas de code : l'EAN est omis, la référence fournisseur et le MPN sont conservés. Le compteur est visible après publication et n'empêche pas l'import des autres données.

Les fichiers annexes fournis contiennent 56 319 références d'assortiment général, 56 272 lignes de stock ATP et 2 347 entrées de hiérarchie réparties sur quatre niveaux. Ils sont distincts du catalogue personnalisé. La version 1.6.1 charge toujours le Datafile principal ; ces fichiers annexes ne sont pas encore raccordés au téléchargement ou à la publication. Le prix SBP de l'assortiment général ne remplace pas le prix revendeur personnalisé. Le CSV de stock ATP est un fichier de support, distinct de l'API ATP interactive.

## Service utilisé

Le connecteur récupère le **Datafile revendeur**, catalogue XML ou CSV contenant les prix et stocks propres au compte. Le manuel XML fourni renvoie au [manuel Datafile et fichiers de support](https://assets.ctfassets.net/y1yt2yxndv6c/ielYAkFRucdJpjlmzhqiG/d75a65916e936672f5648e4b6a8640b8/manual-datafile-and-support-files-10.pdf). L'activation Belgique se demande sur [Copaco Datafile Belgique](https://www.copaco.com/datafilerequest_be).

Le service ATP interactif et son Sender ID ne servent pas aux synchronisations automatiques du plugin : le [manuel XML 6.4.2, chapitre 7](https://assets.ctfassets.net/y1yt2yxndv6c/2gaLm1YDtKfdEk5jAwr9OA/974650f41b0d7b7ad6813a09b98e87fe/manual-for-xml-communication-6-4-2.pdf) limite ce contrôle ponctuel et exclut son usage pour actualiser une base complète. Aucune commande d'achat fournisseur n'est envoyée par ce connecteur.

## Configuration à réception de l'accès

Le Datafile reste désactivé par défaut. Dans **Paramètres → Copaco — paramètres FTP**, saisir :

- Le nom de serveur et le compte communiqués par Copaco, sans inscrire les identifiants dans une URL.
- Le mot de passe, chiffré avec `APP_SECRET`, absent des réponses publiques et des options de tâches. Un champ vide conserve le mot de passe enregistré.
- Le protocole confirmé par Copaco : **FTPS explicite TLS** (port 21 par défaut) ou **FTP**. FTP transmet les identifiants en clair ; sélectionner FTPS si le compte le permet. Aucun repli automatique de TLS vers FTP. SFTP et FTPS implicite ne sont pas implémentés dans cette version.
- Le chemin distant exact, commençant par `/`, et le format XML ou CSV officiel. Le fichier doit être non compressé ; les ZIP ne sont pas extraits. Aucune adresse serveur ni aucun nom de fichier client n'est supposé par le plugin.
- Pour le CSV, choisir l'encodage du fichier reçu. XML suit sa déclaration d'encodage. Le lecteur CSV attend les en-têtes néerlandais documentés et détecte point-virgule, tabulation ou virgule.

Enregistrer, puis ouvrir l’onglet **Copaco** et demander **Charger le catalogue Copaco maintenant**. Le bouton met une demande dans la file dédiée ; un worker traite le téléchargement. Pour une actualisation quotidienne, cocher séparément l'activation automatique. Le chargement du catalogue n'active pas à lui seul la synchronisation des fiches Shopware.

## Exécution et fraîcheur

Depuis 1.7.0, l'actualisation automatique est déclenchée à **00:00 Europe/Brussels**, au premier passage du worker à partir de cette heure. Une réussite clôt l'actualisation pour la journée locale, même si la date UTC est encore celle de la veille ; les changements d'heure ne produisent pas de double chargement. Une demande manuelle peut toujours être lancée dans l'onglet Copaco. Les workers doivent être entretenus par le serveur (voir WORKERS.md) pour fonctionner lorsque l'administration est fermée.

Un échec garde le catalogue précédent et programme une reprise après une heure. Une interruption du serveur peut être rattrapée au prochain passage du worker. Le nouveau jour local reste prioritaire sur un ancien délai de reprise. Une activation sans chargement réussi aujourd'hui permet également ce rattrapage.

Copaco peut générer son nouveau Datafile entre minuit et 03 h. Le téléchargement demandé à minuit utilise le fichier disponible à cet instant, qui peut encore être celui de la veille. La date distante reste affichée et le fichier est validé entièrement avant publication. Aucun horaire plus tardif n'est imposé par le plugin.

Le pool CLI existant et la tâche planifiée du catalogue appellent ce traitement. Pour le lancer explicitement depuis l'hôte Docker :

```bash
docker exec -it -w /var/www/html sw-shop-70e6ac-web-1 php bin/console tdbridge:copaco:refresh
```

Cette commande demande un chargement immédiat et ne modifie aucun produit Shopware. Pour ensuite mettre à jour les produits déjà liés, utiliser **Tout synchroniser maintenant**, ou activer la synchronisation automatique des produits dans les paramètres généraux et laisser le worker fonctionner.

La date de modification distante du fichier est requise (MDTM FTP). Un Datafile de plus de 36 h ou daté dans le futur est refusé ; sa date n'est pas remplacée par celle du téléchargement. Le CSV manuel à mapping libre conserve sa limite de 24 h. Les horodatages du dernier essai, de la dernière publication et du fichier distant sont visibles dans l'onglet. Un ancien état « running » sans verrou actif peut être relancé manuellement.

## Validation et publication

Le téléchargement est plafonné à 200 Mo et 180 secondes. Le lecteur traite jusqu'à un million d'articles en flux et stocke les données de préparation par lots bornés. Seule la publication finale est atomique : un XML mal formé, une identité en double, un prix incohérent ou un fichier vide garde le catalogue précédent. Les déclarations d'entités internes XML sont rejetées ; aucun DTD distant n'est chargé.

Les références sont rapprochées par fournisseur/référence. Les associations Shopware et leur choix de source sont conservés. Une référence absente du nouveau Datafile passe « absente du catalogue » ; sa fiche boutique reste conservée, sans suppression ni stock forcé à zéro. Elle est exclue des prochaines campagnes automatiques tant qu'elle reste absente. Le journal existant et le CSV manuel restent disponibles.

Le coût de base correspond au prix fournisseur **hors taxes environnementales**. Le montant fourni avec ces taxes est affiché séparément. La règle demandée reste : achat natif = coût de base + **50 € HT** ; la base de calcul du prix de vente ne change pas. Les descriptions longues sont conservées, le nom affiché est limité à 255 caractères. Codes de catégorie et statut sont conservés ; le filtre de catégories attend les codes du Datafile, sans création automatique de catégories Shopware.

## Mise à jour et limites de validation

Installer le ZIP 1.7.0 dans le dossier technique `TDBridge`, arrêter les workers pendant la mise à jour, puis exécuter les commandes du [guide de migration](SUPPLIERS.md). La nouvelle migration ajoute les métadonnées d'offres et les tables de préparation/état Copaco sans supprimer les liaisons. PHP nécessite cURL, XMLReader, SimpleXML et mbstring. Recharger l'administration avec Ctrl+Maj+R et relancer les workers.

Des fichiers revendeur réels ont été fournis et contrôlés localement. Les essais de téléchargement restent simulés ; le véritable serveur et ses accès ne sont pas configurés dans cet environnement. Aucun serveur privé Copaco n'a été contacté. Un premier test avec le véritable serveur, son certificat, le chemin exact et un fichier réel reste nécessaire après réception des accès ; les mises à jour de produits doivent ensuite être contrôlées sur une boutique de recette.
