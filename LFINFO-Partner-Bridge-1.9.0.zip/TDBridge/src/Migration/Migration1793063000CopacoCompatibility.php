<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793063000CopacoCompatibility extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793063000; }
    public function update(Connection $db): void
    {
        $columns=array_column($db->fetchAllAssociative('SHOW COLUMNS FROM lf_copaco_refresh'),'Field');
        if(!in_array('invalid_eans',$columns,true)){
            $db->executeStatement('ALTER TABLE lf_copaco_refresh ADD COLUMN invalid_eans INT NOT NULL DEFAULT 0');
        }
    }
    public function updateDestructive(Connection $db): void {}
}
