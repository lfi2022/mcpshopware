# Changelog

## 1.9.0 — 2026-10-27

- Navigation unifiée : Fournisseurs pour les connexions, Catalogue pour TD SYNNEX, Copaco, Ingram ou une vue globale ; Paramètres pour les règles communes et Icecat.
- Recherche globale en lecture seule : texte, marques multiples, coûts, stock et catégories distinctes par source. Appels indépendants, erreurs isolées, résultats et pagination conservés par fournisseur.
- Filtres avancés dépliables, sélections et confirmations d'import conservées. Le parcours TD reste borné et peut être continué ; les limites des résultats API Ingram sont affichées.
- Connexions et mapping TD déplacés sans changer les clés de configuration, les routes, les tables ni l'identité technique TDBridge.

## 1.8.0 — 2026-10-27

- Intégration Ingram Micro revendeur v6 Belgique : paramètres chiffrés, OAuth configurable 20/30, recherche API avec filtres combinés et PNA par lots de 50 références.
- Onglet Ingram, sélection et confirmation d'import, liaison atomique aux fiches existantes, synchronisation et Icecat avec les règles communes de prix/stock.
- Sandbox en lecture uniquement, protection des comptes et environnements par empreinte, données absentes conservées comme inconnues, erreurs fournisseur expurgées et Retry-After respecté.
- Campagnes et contrôle des sources adaptés à TD SYNNEX, Copaco et Ingram ; reprises, suppression de produit et prix d'achat (+50 € HT) conservés.
- Tests locaux avec HTTP simulé et MariaDB ; aucune connexion revendeur réelle déclarée validée.

## 1.7.0 — 2026-10-27

- Nom affiché LFINFO Partner Bridge dans le module, les permissions et l'extension ; identité technique conservée.
- Onglet Copaco dédié au catalogue et au suivi des chargements, séparé des liaisons générales. Connexion FTP et activation quotidienne déplacées dans les paramètres du plugin.
- Déclenchement automatique à minuit Europe/Brussels au lieu de 04 h. Une réussite par jour local, reprise horaire en cas d'échec et rattrapage après interruption du worker.
- Migration du jour de réussite local à partir de l'horodatage UTC existant ; contrôles des changements d'heure et de la frontière entre date UTC et date belge.

## 1.6.1 — 2026-10-27

- Compatibilité avec le XML réel : item/vendor/price/stock/status et attribut currency en minuscules, en plus des noms documentés. Doublons de champs entre variantes refusés.
- Les EAN non standard deviennent absents pour le mapping produit et Icecat ; les articles restent importables via leur référence fournisseur et fabricant. Compteur visible dans le statut du Datafile.
- Contrôle intégral du fichier revendeur fourni : 55 579 articles, 2 125 EAN non standard ; aucun prix ni stock invalide, aucune référence dupliquée. Aucun fichier client distribué.

## 1.6.0 — 2026-10-27

- Connexion Datafile Copaco FTP/FTPS explicite, mot de passe chiffré, requête de chargement et rafraîchissement quotidien optionnel après 04 h Europe/Brussels. Aucun appel ATP automatique ni commande fournisseur envoyée.
- Lecteur XML/CSV officiel en flux, stockage de préparation borné puis publication atomique ; fichier distant périmé, doublons et XML invalide refusés sans remplacer le catalogue.
- Métadonnées de catégorie/statut, prix avec taxes fournisseur séparé du coût de base, descriptions longues préservées et noms limités à 255 caractères.
- Une offre disparue reste liée et visible comme absente, exclue des campagnes ; son produit Shopware est conservé.
- Accès Copaco en attente d'activation : tests documentaires et MariaDB avec transport simulé, connexion réelle à valider après réception des identifiants.

## 1.5.0 — 2026-10-27

- Nouveau nom affiché LFINFO Supplier Bridge, identité technique TDBridge conservée pour la mise à jour.
- Offres Copaco par flux CSV UTF-8 avec mapping, aperçu sans écriture, fusion atomique, recherche texte/marques/prix/stock, import sélectionné et liaison explicite aux produits existants.
- Une source prix/stock par produit ; pause des offres concurrentes et contrôle au moment de l'écriture. Catalogue et écritures Shopware séparés par des connecteurs normalisés.
- Liste Mes produits, synchronisation globale, tâches, statistiques et enrichissement Icecat adaptés aux deux fournisseurs. Snapshot CSV de plus de 24 h refusé.
- Suppression d'un produit live : retrait/déliaison des associations, nettoyage de rattrapage et protection des tâches en attente, y compris héritées des versions précédentes.
- Registre de connecteurs extensible ; Ingram Micro annoncé comme prévu uniquement. API Copaco en attente de documentation revendeur, aucun endpoint supposé.

## 1.4.3 — 2026-10-27

- Migration du statut des tâches vers VARCHAR(32) : correction de SQLSTATE 22001 lors de l’enregistrement de completed_with_errors. Historique conservé.
- Diagnostic SQL avec nom de colonne sûr pour les troncatures et contrôle de compatibilité du statut dans tdbridge:diagnose.
- Erreurs Icecat distinguées par StatusCode stable : couverture Full, droits de catégorie/marque, IP, jeton API ou compte. Aucun corps fournisseur ni secret dans les messages.

## 1.4.2 — 2026-10-26

- Arrêt gracieux des enfants CLI sur SIGINT/SIGTERM : le lot en cours se termine et aucun nouveau lot ne démarre.
- Le pool distingue un arrêt demandé avec sortie 130/143 d’un échec réel, y compris pendant le démarrage d’un enfant.
- Réinitialisation de l’état d’arrêt entre exécutions, libération des verrous et compteurs ; diagnostics enfants bornés dans les journaux serveur pour les vraies erreurs.

## 1.4.1 — 2026-10-26

- Forfait de 50 € HT ajouté au prix d’achat natif, sans cumul à la resynchronisation, sans modifier le prix de vente ni le coût brut fournisseur. TVA appliquée au total ; devise EUR nécessaire.
- Option CLI `tdbridge:worker --max-workers=1..8` pour enregistrer la limite globale puis lancer le pool, avec refus d’une valeur hors limites.
- Formule du prix d’achat explicitée dans les paramètres et documentation du dimensionnement serveur.

## 1.4.0 — 2026-10-26

- Deux actions groupées dans Mes produits, avec confirmation : synchroniser tous les produits liés actifs et enrichir avec Icecat uniquement ceux sans photo. Recontrôle de la version live et des photos héritées avant traitement.
- Jusqu’à 50 références par requête TD, tâches plus petites pour distribuer la charge et progression enregistrée après chaque produit.
- Verrous par tâche et référence, capacité bornée, reprise après arrêt et pause API partagée sur HTTP 429/Retry-After.
- Pool PHP CLI adaptatif, limite configurable de 1 à 8 (2 par défaut), commandes tdbridge:worker et tdbridge:process avec budget temps. Aucun processus créé depuis une requête HTTP.
- Correction de l’affichage transitoire de lignes produit dans la liste des tâches après une action groupée.

## 1.3.2 — 2026-10-26

- Bouton « Tout synchroniser maintenant » dans Mes produits et Imports : confirmation avec nombre total, produits en pause exclus et réglages enregistrés affichés.
- Mise en file de toutes les références liées actives, indépendamment de la page et du filtre, par groupes de 500 références. Le worker conserve ses lots de traitement de 10 références.
- Protection contre les synchronisations simultanées, absence de mise en file partielle si la capacité est insuffisante, aucune importation de nouveaux produits du catalogue.

## 1.3.1 — 2026-10-26

- Prix d’achat fournisseur écrit dans le champ natif Shopware à l’import et lors des mises à jour des prix : HT sans majoration, TTC selon la TVA du produit et conservation des autres devises.
- L’option de synchronisation précise désormais « Prix de vente et d’achat ». Une nouvelle synchronisation des prix renseigne aussi les produits déjà liés.

## 1.3.0 — 2026-10-26

- Catalogue fournisseur persistant par marque, confirmation de chargement, pause/reprise, suivi des erreurs et Retry-After ; nouveau stockage indépendant de l’ancien index.
- Recherche avancée avec pagination SQL et structure classes/sous-classes, références non importées incluses.
- Open Icecat interne : configuration et jetons chiffrés, aperçu, descriptions, caractéristiques et images locales, enrichissement sélectif et préservation prix/stock.
- Les recherches directes et le parcours explicite d’import restent disponibles dans le seul module Bridge.

## 1.2.0

Recherche fournisseur recentrée dans l’onglet TD SYNNEX Bridge, sans index préalable ni modification des produits ou catégories Shopware pendant une recherche. Parcours API paginé des marques choisies, filtres texte/catégorie/prix/stock/statut, résultats conservés dans l’écran et bouton pour poursuivre une recherche partielle. Maximum quatre lectures fournisseur par action et 1 000 correspondances conservées dans la session. Les doublons de références sont regroupés.

Ancienne indexation désactivée : suppression de la commande de construction, routes d’action retirées du fonctionnement, tâches déjà en file consommées sans opération et aucun redémarrage automatique. L’ancien cache est conservé sans alimentation ni suppression. Configuration uniquement dans le module Bridge, sans raccourci ajouté aux paramètres généraux. L’import reste une action séparée après sélection et confirmation explicite.

## 1.1.2

Menu de catégories lisibles (ordinateurs portables, PC de bureau, écrans, etc.), raccourcis de catégories, suggestions de marques présentes dans l’index et compteurs par catégorie selon les marques saisies. Les codes TD multiples restent disponibles dans les filtres avancés. Message explicite quand l’index n’a pas encore été construit. Endpoint de facettes en lecture seule, sans nouvelle table ni modification des produits Shopware.

## 1.1.1

Commande `tdbridge:diagnose --part=...` et action administrateur GET `diagnose-import` en lecture seule : versions source/installée, schéma de file, références de configuration, journal ciblé et vérification des données catalogue, sans identifiants OAuth. Les erreurs générales d’une tâche utilisent aussi le diagnostic détaillé ; les erreurs SQL indiquent leur SQLSTATE et la colonne manquante quand disponible, sans afficher la requête ni la connexion. Ajout de tests MariaDB sur le diagnostic et l’absence d’écriture produit.

## 1.1.0

Recherche texte dans un index local persistant du catalogue. Marques, expressions, classes et sous-classes multiples séparées par `;`, filtres combinés par prix, stock et statut, raccourcis « en stock », « avec prix », « actifs » et « non importés ». Indexation par pages et par marque, progression, périmètre affiché, pause/reprise, gestion des quotas, tâche planifiée et commande `tdbridge:index`. Mode API directe conservé. Deux nouvelles tables ; mise à jour du plugin et enregistrement des tâches nécessaires.

Correction bloquante de l’import : utilisation de `Uuid::fromStringToHex()` pour les produits et fabricants, conformément à l’API réelle de Shopware 6.7.15.1. Détails des validations DAL désormais visibles dans le journal, sans métadonnées ni traces. Migration du mapping provisoire des anciennes tâches à leur reprise. Tests d’intégration MariaDB de l’index et contrôle des appels UUID contre les classes officielles. Documentation de la coexistence avec le connecteur commercial Icecat existant ; aucun enrichissement Icecat interne n’est ajouté.

## 1.0.2

Ajout de l’image fournie comme visuel du plugin dans la gestion des extensions Shopware. Fichier PNG original conservé dans `src/Resources/config/plugin.png`, déclaré dans les métadonnées et inclus dans le ZIP.

## 1.0.1

Mapping catalogue corrigé sur la réponse européenne réellement obtenue : liste `data`, total `totalResults`, libellé `productDescription`, prix `price.customerPrice`, devise `price.currencyCode`, stock `stock.quantityAvailableTotal`. Migration du mapping provisoire sauvegardé sans écraser les mappings personnalisés. Conservation des valeurs absentes pour les articles discontinués. Requêtes par défaut limitées aux options actives ; filtre « en stock uniquement » désactivé initialement pour retrouver la requête simplifiée testée avec succès. La cause exacte du premier HTTP 400 n’est pas établie. Ajout de tests sur la structure réelle et reconstruction des assets.

## 1.0.0

Première version ciblant Shopware 6.7.15.1 : authentification OAuth TD SYNNEX, catalogue V2, imports sélectifs, règles de prix et stock, liaison des produits, file persistante, synchronisation périodique, consultation des commandes/factures, interface d’administration française, permissions, journaux et exports. Mapping configurable en l’absence de schéma de réponse dans la documentation d’origine.
