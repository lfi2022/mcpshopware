# Actions administrateur

Toutes les routes commencent par `/api/_action/td-bridge/`, exigent une authentification Shopware et sont contrôlées côté serveur par `_acl`. Elles ne servent pas de proxy libre : seuls les chemins TD SYNNEX documentés sont appelés.

| Méthode | Chemin | Droit | Fonction |
| --- | --- | --- | --- |
| GET / POST | `settings` | `td_bridge:configure` | Lire/enregistrer les paramètres ; secret jamais retourné |
| POST | `test` | `td_bridge:configure` | Nouveau jeton OAuth pour tester les identifiants enregistrés |
| POST | `diagnose` | `td_bridge:configure` | Réponse catalogue brute, une référence/page maximum |
| GET | `diagnose-import?part=10201179` | `td_bridge:configure` | Rapport ciblé sans identifiants ni écriture produit, identique à la commande CLI |
| POST | `catalogue` | `td_bridge:read` | Recherche et normalisation avec mapping |
| POST | `catalogue` avec `mode: "browse"` | `td_bridge:read` | Lecture fournisseur et filtres combinés, sans écriture catalogue |
| POST | `catalogue-facets` | `td_bridge:read` | Libellés statiques en mode direct ; structure et comptes réels du cache en `mode:cache` |
| GET | `catalogue-index` | `td_bridge:read` | Lecture de l’ancien état, pour compatibilité uniquement |
| POST | `catalogue-index/{action}` | `td_bridge:import` | Désactivé : répond 409, aucune construction ou reprise d’index |
| GET | `stats` | `td_bridge:read` | Compteurs et état de la tâche Shopware |
| GET | `list/links`, `list/jobs`, `list/logs` | `td_bridge:read` | Listes paginées, `page` et `term`, 25 éléments/page |
| POST | `import` | `td_bridge:import` | `{ "parts": ["123"], "type": "import" }`, ou type `sync` |
| POST | `process` | `td_bridge:import` | Traiter un lot de dix références au maximum |
| POST | `jobs/{id}/cancel` | `td_bridge:import` | Annuler une tâche en attente |
| POST | `jobs/{id}/retry` | `td_bridge:import` | Recommencer une tâche échouée, annulée ou terminée avec erreurs |
| POST | `links` | `td_bridge:import` | `{ "partNumber": "123", "enabled": false }` |
| POST | `documents/orders`, `documents/invoices` | `td_bridge:documents` | Consultation avec les paramètres documentés |

Le corps catalogue reprend les noms et types de la documentation fournie. Les critères non documentés ne sont pas transmis. Un seul critère de recherche non nul est accepté ; les drapeaux, dates et statut peuvent le compléter.

En mode fournisseur, exemple : `{"mode":"browse","text":"thinkbook;thinkpad","brands":"Lenovo;HP","classes":"COMPORT","onlyInStock":true,"hasPrice":true,"notImported":false,"minCost":"","maxCost":"900","minStock":"2","page":1,"pageSize":25}`. Les filtres `subclasses` et `productStatusCode` sont également disponibles. La réponse contient `items`, `scanned`, `hasMore` et `scanCursor`. Renvoyer ce curseur avec les mêmes filtres pour lire la page fournisseur suivante ; une requête lit une page d’une marque, en alternance entre les marques choisies. La réponse n’annonce pas de total des correspondances avant parcours complet.

Le navigateur regroupe les références et pagine les correspondances de la session. La recherche ne réalise que des lectures SQL éventuelles pour reconnaître les références déjà liées. Elle n’enregistre ni résultats catalogue, ni produits, ni catégories, ni tâche d’import. Le paramètre historique `mode: "index"` est traité comme le mode fournisseur et ne construit aucun index.

Les erreurs métier ont la forme `{"errors":[{"code":"TD_BRIDGE_ERROR","detail":"…"}]}`. Les erreurs d’authentification du fournisseur sont remontées comme erreur de passerelle pour éviter de confondre l’expiration OAuth TD SYNNEX avec celle de la session Shopware. Les corps d’erreur fournisseur ne sont jamais repris dans le message.

Les identifiants sont chiffrés avec Sodium secretbox et une clé dérivée d’`APP_SECRET`. Les connexions sortantes interdisent les réseaux privés avec `NoPrivateNetworkHttpClient`, les redirections sont désactivées et les requêtes ont des délais bornés. Les secrets et jetons ne sont pas inclus dans les tâches ou journaux du bridge. Le cache applicatif serveur contient les jetons OAuth jusqu’à leur expiration anticipée ; le protéger comme les autres données d’authentification Shopware.

## Catalogue persistant et Icecat — 1.3

Depuis 1.3.2 : `GET /api/_action/td-bridge/sync-all` (permission lecture) retourne `eligible`, `paused` et les réglages `syncPrice`, `syncStock`, `syncContent`. `POST` sur la même route (permission import) met tous les produits liés actifs en tâches `sync` de 500 références maximum et retourne `{products, jobs}`. Aucun filtre ni numéro de page n’est accepté pour réduire ce périmètre global. Le worker traite ensuite les tâches normalement. Le verrou du worker empêche les lancements concurrents ; une synchronisation déjà en attente/en cours renvoie 409. Les créations sont transactionnelles et respectent la limite de 100 tâches actives, sans mise en file partielle.

- `GET supplier-cache` : état et compte par périmètre, permission `td_bridge:read`.
- `POST supplier-cache/start` : `{brands:"Lenovo;HP"}` ou `{fullCatalogue:true}`, permission `td_bridge:import`. Remplace le cache des seuls périmètres demandés.
- `POST supplier-cache/pause` / `resume` : `{id:"<64 hex>"}`.
- `POST supplier-cache/tick` : une page éligible, même verrou que le worker.
- `POST catalogue` avec `mode:"cache"` : filtres identiques au mode browse, pagination serveur, `source:"supplier-cache"`, `total`, `coverage`.
- `POST catalogue-facets` avec `mode:"cache", brands:"Lenovo;HP"` : marques, classes et sous-classes avec comptes et libellés fournisseur. Aucun appel TD.
- `POST icecat/preview` : `{partNumber:"..."}`, permission lecture. Relit la référence TD puis Icecat ; retourne les textes, caractéristiques et nombre d’images sans URL signée ni jeton. Aucune écriture produit.
- `POST import` avec `type:"icecat"` : enrichissement explicite de références déjà liées. Aucun changement de prix/stock. Les paramètres Icecat publics sont figés dans la tâche, les jetons restent dans la configuration chiffrée.

Toutes les routes ci-dessus sont sous `/api/_action/td-bridge/`. Les anciennes actions `catalogue-index/{action}` restent refusées pour empêcher des clients anciens de reprendre un travail retiré. Les nouvelles tables sont vides à l’installation.

## Actions et workers 1.4

- `GET icecat-missing` : `{eligible,paused,enabled}` en lecture seule, comptage des produits liés actifs sans photo live ou héritée.
- `POST icecat-missing` : permission import, file de tâches `icecat_missing` avec images activées et recontrôle de photo. `{products,jobs}`.
- `GET workers` : maximum configuré, slots actifs, demande, dernière pause API et état du coordinateur. Aucune donnée d’authentification.
- `sync-all` utilise désormais des tâches de 50 références et une capacité de 1 000 tâches actives. Les anciennes limites documentées pour 1.3.2 sont historiques.

Préfixe de toutes ces routes : `/api/_action/td-bridge/`. Les actions mutables requièrent `td_bridge:import`, les lectures `td_bridge:read`. La concurrence est bornée même si des workers CLI et le worker Shopware fonctionnent simultanément. Voir [WORKERS.md](WORKERS.md).
