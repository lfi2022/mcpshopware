# Ingram Micro Belgique — LFINFO Partner Bridge 1.8.0

## Périmètre

L'onglet **Ingram Micro** recherche directement dans le catalogue revendeur v6 Belgique. Il lit ensuite les prix propres au compte et la disponibilité totale par lots de 50 références maximum. Les résultats peuvent être sélectionnés pour import, ou reliés explicitement à une fiche Shopware existante dans **Fournisseurs & liaisons**.

La recherche ne crée pas de produit, de liaison, d'offre persistante ou de tâche. Elle ne parcourt pas tout le catalogue en arrière-plan. Les imports et les synchronisations relisent les prix et stocks via l'API avant écriture. Les produits Ingram participent à **Mes produits**, à la synchronisation globale et à Icecat sans photo, comme les autres fournisseurs.

Aucune commande d'achat Ingram n'est passée, aucune facture fournisseur importée et aucun webhook activé par cette version. L'API Product Details n'est pas nécessaire au parcours : sa description dans le document Belgique ne cite pas la Belgique parmi les pays disponibles. Les données utiles viennent de Search et PriceAndAvailability, avec Icecat pour les contenus complémentaires.

## Paramètres du plugin

Dans **Paramètres → Ingram Micro — paramètres API Belgique**, renseigner :

- **Environnement** : sandbox pour vérifier la lecture ou production pour importer et synchroniser.
- **Numéro client** : numéro revendeur Ingram Belgique, dix caractères au maximum, avec le tiret lorsqu'il fait partie du numéro fourni.
- **Client ID / Client secret** : ceux de l'application revendeur API v6, autorisée sur le compte concerné.
- **Sender ID** : facultatif, 32 caractères maximum ; la valeur initiale identifie le plugin.
- **Langue** : français, néerlandais ou anglais. Le pays d'appel est toujours `BE`.
- **Version OAuth** : le guide revendeur actuel utilise `oauth20`, alors que le fichier OpenAPI Belgique fourni annonce `oauth30`. Choisir le service applicable à l'application. Aucun changement automatique vers l'autre service n'est tenté après un refus.

Activer la connexion, enregistrer, puis utiliser **Tester Ingram Micro**. Ce test vérifie OAuth ; une recherche doit ensuite confirmer les droits catalogue et prix du numéro client. Le secret est chiffré avec `APP_SECRET`, jamais renvoyé dans les paramètres publics ni enregistré dans les options de tâches. Un champ secret vide conserve le secret existant.

Le sandbox est **en lecture uniquement** : ses résultats ne peuvent pas créer ou modifier une fiche Shopware, même en appelant directement la route de mise en file. Les identifiants sandbox et production peuvent être distincts. La connexion reste désactivée par défaut.

## Recherche et import

Texte, références fabricant, marques et catégorie sont envoyés à l'API. Les valeurs multiples de texte, marque et MPN sont séparées par `;` dans l'interface et transmises comme paramètres répétés conformément au schéma OpenAPI. Une seule catégorie peut être envoyée par recherche.

Les filtres coût minimum/maximum et stock sont appliqués **sur la page reçue**, après lecture des prix et disponibilités. Le total annoncé par l'API n'est pas recalculé artificiellement : l'interface affiche ce total et le nombre retenu sur la page. La pagination continue d'utiliser la page catalogue suivante du même service ; aucune URL de lien retournée par un fournisseur n'est suivie automatiquement.

En production, sélectionner jusqu'à 500 références, préparer l'import puis confirmer. Le worker relit PriceAndAvailability par lots, avec des checkpoints par article. Le nouveau SKU est `INGRAM-<référence>`. TVA, catégorie de destination, canal, état actif, marge et réserve de stock suivent les paramètres généraux. Le coût de référence est **pricing.customerPrice**, jamais le prix public retailPrice.

La règle existante est conservée : **achat HT natif = coût fournisseur + 50 € HT**. Le supplément n'est pas intégré à la base de calcul du prix de vente. Un prix ou stock absent reste inconnu et n'est pas remplacé par zéro ; un import nécessitant cette donnée est refusé sans écraser une valeur native valide. Les articles explicitement non autorisés pour le compte sont refusés individuellement.

Pour réutiliser une fiche existante, choisir **Relier à un produit existant**, sélectionner le produit dans le formulaire de liaison et confirmer. La référence est vérifiée par l'API ; la mise à jour des métadonnées et la liaison sont atomiques. Activer cette source met les autres sources de ce produit en pause. Le nom ou l'EAN ne déclenche jamais de fusion automatique.

## Synchronisation et changements de compte

Les sources Ingram actives en production suivent la synchronisation automatique générale du plugin, au même intervalle que les autres produits liés. Le worker doit fonctionner sur le serveur. Le mode production doit rester activé ; un simple passage en sandbox ne doit pas remplacer des produits par des données de démonstration.

Les tâches et liaisons mémorisent l'identité du compte et de l'environnement sous forme d'empreinte. Changer de numéro client ou d'environnement bloque les anciennes tâches et exclut les anciennes associations des campagnes du nouveau compte. Vérifier les liaisons explicitement avant de reprendre avec un autre compte. Une rotation du secret pour le même compte ne modifie pas cette identité.

Une limite HTTP 429 déclenche la reprise selon `Retry-After` et la pause commune des workers ; une première erreur de jeton 401 tente un seul renouvellement. Les erreurs fournisseur ne publient ni corps brut ni valeurs d'identifiants. Les checkpoints préservent les articles déjà traités. Supprimer le produit Shopware retire sa liaison et empêche une tâche en attente de le recréer.

## Installation et état de validation

Mettre à jour le dossier technique **TDBridge**, sans désinstaller ni créer une seconde extension. Arrêter les workers pendant la migration puis exécuter :

```bash
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console plugin:refresh
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console plugin:update TDBridge
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console cache:clear
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console assets:install
```

Recharger l'administration avec Ctrl+Maj+R, puis relancer le pool ou son service serveur. La migration ajoute l'empreinte de compte aux offres ; les données TD SYNNEX et Copaco et le chargement Copaco à minuit sont conservés.

Les essais utilisent MariaDB et le client HTTP Symfony avec des réponses simulées selon le document fourni. Ils vérifient les paramètres répétés, les références numériques belges, les lots, les secrets, les reprises, l'import natif via doubles DAL, le changement de source et les campagnes multi fournisseurs. Aucun compte Ingram réel n'a été connecté ; un test sandbox puis une recette production restent nécessaires avec les identifiants de l'application. Le code ne prétend pas valider les autorisations de l'application à leur place.

## Sources

- Fichier OpenAPI Belgique v6.0 fourni par l'utilisateur (13 juillet 2023), conservé uniquement dans l'espace de travail de contrôle et non distribué dans le plugin.
- [Documentation API Belgique](https://developer.ingrammicro.com/reseller/api-documentation/Belgium).
- [Authentification du portail revendeur](https://developer.ingrammicro.com/reseller/getting-started/authentication).
- [Environnement sandbox Belgique](https://developer.ingrammicro.com/reseller/getting-started/using-sandbox).
