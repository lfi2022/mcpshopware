<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Uuid\Uuid;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\ImportDiagnostics;
use TDBridge\Domain\ProductMapper;

final class ImportInspector
{
    public function __construct(private readonly Connection $db, private readonly Settings $settings, private readonly TdClient $client, private readonly ProductMapper $mapper) {}

    /** Read-only report. No credentials, tokens, raw responses or database connection strings. */
    public function inspect(?string $part = null): array
    {
        if ($part !== null && (trim($part) === '' || strlen($part) > 100)) { throw new BridgeException('Référence invalide.'); }
        $settings = $this->settings->all();
        $metadata = json_decode((string) file_get_contents(__DIR__ . '/../../composer.json'), true, 512, JSON_THROW_ON_ERROR);
        $report = [
            'sourceVersion' => $metadata['version'],
            'installedPlugin' => $this->section(fn () => $this->db->fetchAssociative('SELECT version, active FROM plugin WHERE name = ?', ['TDBridge'])),
            'uuidApiSupported' => is_callable([Uuid::class, 'fromStringToHex']),
            'credentialsConfigured' => $settings['clientId'] !== '' && $settings['encryptedSecret'] !== '',
            'mapping' => $settings['mapping'],
            'jobSchema' => $this->section(function (): array {
                $columns = $this->db->fetchAllAssociative('SHOW COLUMNS FROM td_bridge_job');
                $names = array_column($columns, 'Field');
                $status = array_values(array_filter($columns, static fn (array $column): bool => $column['Field'] === 'status'))[0] ?? [];
                $type = (string) ($status['Type'] ?? '');
                $length = preg_match('/varchar\((\d+)\)/i', $type, $match) ? (int) $match[1] : null;
                return ['columns' => $names, 'processedColumnPresent' => in_array('processed', $names, true), 'statusType' => $type, 'terminalStatusFits' => $length !== null ? $length >= strlen('completed_with_errors') : null];
            }),
        ];
        foreach (['taxId' => 'tax', 'currencyId' => 'currency', 'categoryId' => 'category', 'salesChannelId' => 'sales_channel'] as $key => $table) {
            $id = $settings[$key];
            $report['references'][$key] = $id === '' ? 'not_selected' : (Uuid::isValid($id) ? $this->section(fn () => (int) $this->db->fetchOne("SELECT COUNT(*) FROM $table WHERE id = UNHEX(?)", [$id]) > 0 ? 'exists' : 'missing') : 'invalid_uuid');
        }
        $report['recentJobs'] = $this->section(fn () => $this->db->fetchAllAssociative('SELECT id, type, status, total, succeeded, failed, last_error, created_at FROM td_bridge_job ORDER BY created_at DESC LIMIT 5'));
        $report['recentLogs'] = $this->section(fn () => $part === null
            ? $this->db->fetchAllAssociative('SELECT job_id, level, part_number, message, created_at FROM td_bridge_log ORDER BY id DESC LIMIT 10')
            : $this->db->fetchAllAssociative('SELECT job_id, level, part_number, message, created_at FROM td_bridge_log WHERE part_number = ? OR part_number IS NULL ORDER BY id DESC LIMIT 10', [$part]));
        if ($part !== null) {
            $report['productProbe'] = $this->section(function () use ($part, $settings): array {
                $result = $this->mapper->catalogue($this->client->catalogue(['tdsynnexPartNumber' => [$part], 'page' => 1, 'pageSize' => 100, 'includeStock' => true, 'includePrice' => true]), $settings['mapping']);
                $matches = array_values(array_filter($result['items'], static fn (array $item) => $item['partNumber'] === $part));
                if (count($matches) !== 1) { return ['exactMatches' => count($matches), 'error' => 'Une référence exacte et unique est requise.']; }
                $item = $matches[0];
                return ['exactMatches' => 1, 'partNumber' => $item['partNumber'], 'namePresent' => !empty($item['name']), 'manufacturerPresent' => !empty($item['manufacturer']), 'manufacturerNumberPresent' => !empty($item['manufacturerNumber']), 'eanFormatValid' => (bool) preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D', $item['ean'] ?? ''), 'stockPresent' => $item['stock'] !== null, 'pricePositive' => $item['cost'] !== null && $item['cost'] > 0, 'currencyMatches' => strtoupper($item['currency'] ?? '') === $settings['currencyCode'], 'status' => $item['status'] ?? null];
            });
        }
        return $report;
    }

    private function section(callable $read): mixed
    {
        try { return $read(); } catch (\Throwable $e) { return ['error' => ImportDiagnostics::message($e)]; }
    }
}
