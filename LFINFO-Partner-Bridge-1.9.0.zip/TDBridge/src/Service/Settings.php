<?php declare(strict_types=1);

namespace TDBridge\Service;

use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Core\Framework\Uuid\Uuid;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\ProductMapper;

final class Settings
{
    private const KEY = 'TDBridge.config.settings';

    public function __construct(private readonly SystemConfigService $config, private readonly string $appSecret) {}

    public function all(): array
    {
        $stored = $this->config->get(self::KEY) ?? [];
        // Replace only the exact provisional mapping shipped before the first real API sample.
        if (isset($stored['mapping']) && $stored['mapping'] == ProductMapper::LEGACY_MAP) {
            $stored['mapping'] = ProductMapper::DEFAULT_MAP;
        }
        return array_replace([
            'baseUrl' => 'https://api.tdsynnex.com/eu', 'tokenUrl' => 'https://api.tdsynnex.com/eu/auth/token',
            'tokenEncoding' => 'form', 'clientId' => '', 'encryptedSecret' => '', 'language' => 'fr-BE',
            'taxId' => '', 'currencyId' => '', 'currencyCode' => 'EUR', 'salesChannelId' => '', 'categoryId' => '',
            'markup' => 15.0, 'fixedMarkup' => 0.0, 'stockReserve' => 0, 'prefix' => 'TD-',
            'activateProducts' => false, 'syncEnabled' => false, 'syncMinutes' => 60,
            'syncStock' => true, 'syncPrice' => true, 'syncContent' => false,
            'mapping' => ProductMapper::DEFAULT_MAP, 'retentionDays' => 30,
            'icecatEnabled' => false, 'icecatUsername' => '', 'icecatLanguage' => 'FR_BE',
            'encryptedIcecatApiToken' => '', 'encryptedIcecatContentToken' => '',
            'icecatDescription' => true, 'icecatSpecs' => true, 'icecatImages' => true,
            'icecatTitle' => false, 'icecatReplace' => false,
            'workerMax' => 2,
        ], $stored);
    }

    public function publicSettings(): array
    {
        $settings = $this->all();
        $settings['hasSecret'] = $settings['encryptedSecret'] !== '';
        unset($settings['encryptedSecret']);
        foreach (['ApiToken', 'ContentToken'] as $name) {
            $settings['hasIcecat' . $name] = $settings['encryptedIcecat' . $name] !== '';
            unset($settings['encryptedIcecat' . $name]);
        }
        return $settings;
    }

    public function secret(): string
    {
        $value = $this->all()['encryptedSecret'];
        if ($value === '') { throw new BridgeException('Renseignez les identifiants TD SYNNEX.'); }
        $decoded = base64_decode($value, true);
        if ($decoded === false || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) { throw new BridgeException('Secret chiffré invalide. Enregistrez à nouveau les identifiants.'); }
        $secret = sodium_crypto_secretbox_open(substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $this->key());
        if ($secret === false) { throw new BridgeException('Impossible de déchiffrer le secret (APP_SECRET modifié ?).'); }
        return $secret;
    }

    public function save(array $input): void
    {
        $settings = $this->all();
        if (isset($input['workerMax'])) { $settings['workerMax'] = \TDBridge\Domain\CatalogueCriteria::integer($input['workerMax'], 1, 8); }
        foreach (['icecatUsername', 'icecatLanguage'] as $field) {
            if (isset($input[$field])) {
                if (!is_string($input[$field]) || strlen($input[$field]) > 200) { throw new BridgeException('Configuration Icecat invalide.'); }
                $settings[$field] = trim($input[$field]);
            }
        }
        if (!preg_match('/^[A-Za-z]{2,3}(?:_[A-Za-z]{2})?$/D', $settings['icecatLanguage'])) { throw new BridgeException('Langue Icecat invalide (ex. FR_BE).'); }
        foreach (['ApiToken', 'ContentToken'] as $name) {
            if (($input['clearIcecat' . $name] ?? false) === true) { $settings['encryptedIcecat' . $name] = ''; }
            $token = $input['icecat' . $name] ?? '';
            if (!is_string($token) || strlen($token) > 4096 || preg_match('/[\r\n]/', $token)) { throw new BridgeException('Jeton Icecat invalide.'); }
            if ($token !== '') {
                $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $settings['encryptedIcecat' . $name] = base64_encode($nonce . sodium_crypto_secretbox($token, $nonce, $this->key()));
            }
        }
        foreach (['baseUrl', 'tokenUrl'] as $key) {
            $url = rtrim(trim((string) ($input[$key] ?? $settings[$key])), '/');
            $parts = parse_url($url);
            if (!$parts || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']) || (isset($parts['port']) && $parts['port'] !== 443)) { throw new BridgeException('URL HTTPS publique attendue, sans identifiants ni paramètres.'); }
            $settings[$key] = $url;
        }
        foreach (['clientId', 'language', 'currencyCode', 'prefix', 'tokenEncoding'] as $key) {
            if (isset($input[$key])) {
                if (!is_string($input[$key]) || strlen($input[$key]) > 200) { throw new BridgeException('Configuration texte invalide.'); }
                $settings[$key] = trim($input[$key]);
            }
        }
        if (!preg_match('/^[A-Z]{3}$/D', $settings['currencyCode']) || !preg_match('/^[A-Za-z0-9_-]{1,30}$/D', $settings['prefix']) || !preg_match('/^[a-z]{2}-[A-Z]{2}$/D', $settings['language']) || !in_array($settings['tokenEncoding'], ['form', 'json'], true)) { throw new BridgeException('Devise, préfixe, langue ou encodage OAuth invalide.'); }
        foreach (['taxId', 'currencyId', 'salesChannelId', 'categoryId'] as $key) {
            if (isset($input[$key])) {
                if ($input[$key] !== '' && (!is_string($input[$key]) || !Uuid::isValid($input[$key]))) { throw new BridgeException("Identifiant Shopware invalide : $key."); }
                $settings[$key] = $input[$key];
            }
        }
        foreach (['markup' => [0, 10000], 'fixedMarkup' => [0, 100000], 'stockReserve' => [0, 1000000], 'syncMinutes' => [15, 10080], 'retentionDays' => [7, 365]] as $key => [$min, $max]) {
            $value = $input[$key] ?? $settings[$key];
            if (!is_numeric($value) || !is_finite((float) $value) || $value < $min || $value > $max || (in_array($key, ['stockReserve', 'syncMinutes', 'retentionDays'], true) && floor((float) $value) !== (float) $value)) { throw new BridgeException("$key doit être compris entre $min et $max."); }
            $settings[$key] = (float) $value;
        }
        foreach (['activateProducts', 'syncEnabled', 'syncStock', 'syncPrice', 'syncContent', 'icecatEnabled', 'icecatDescription', 'icecatSpecs', 'icecatImages', 'icecatTitle', 'icecatReplace'] as $key) {
            if (isset($input[$key])) {
                if (!is_bool($input[$key])) { throw new BridgeException("$key doit être booléen."); }
                $settings[$key] = $input[$key];
            }
        }
        if (isset($input['mapping'])) {
            if (!is_array($input['mapping'])) { throw new BridgeException('Mapping invalide.'); }
            foreach (ProductMapper::DEFAULT_MAP as $key => $default) {
                $value = $input['mapping'][$key] ?? $default;
                if (!is_string($value) || strlen($value) > 200 || ($value !== '' && !preg_match('/^[a-zA-Z0-9_.-]+$/D', $value))) { throw new BridgeException("Chemin de mapping invalide : $key."); }
                $settings['mapping'][$key] = $value;
            }
        }
        if (!empty($input['clearSecret'])) { $settings['encryptedSecret'] = ''; }
        if (isset($input['clientSecret']) && $input['clientSecret'] !== '') {
            if (!is_string($input['clientSecret']) || strlen($input['clientSecret']) > 4096) { throw new BridgeException('Secret invalide.'); }
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $settings['encryptedSecret'] = base64_encode($nonce . sodium_crypto_secretbox($input['clientSecret'], $nonce, $this->key()));
        }
        $this->config->set(self::KEY, $settings);
    }

    private function key(): string
    {
        if ($this->appSecret === '') { throw new BridgeException('APP_SECRET doit être défini.'); }
        return hash('sha256', 'tdbridge:' . $this->appSecret, true);
    }

    public function icecatToken(string $name): string
    {
        if (!in_array($name, ['ApiToken', 'ContentToken'], true)) { throw new BridgeException('Jeton inconnu.'); }
        $value = $this->all()['encryptedIcecat' . $name];
        if ($value === '') { return ''; }
        $decoded = base64_decode($value, true);
        if ($decoded === false || strlen($decoded) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) { throw new BridgeException('Jeton Icecat chiffré invalide.'); }
        $plain = sodium_crypto_secretbox_open(substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $this->key());
        if ($plain === false) { throw new BridgeException('Impossible de déchiffrer le jeton Icecat. Enregistrez-le à nouveau.'); }
        return $plain;
    }
}
