<?php declare(strict_types=1);

namespace TDBridge\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use TDBridge\Domain\BridgeException;
use TDBridge\Service\SupplierOffers;
use TDBridge\Service\ProductLifecycle;
use TDBridge\Service\JobManager;

#[Route(defaults: ['_routeScope' => ['api']])]
final class SupplierController
{
    public function __construct(private readonly SupplierOffers $offers, private readonly ProductLifecycle $lifecycle, private readonly JobManager $jobs, private readonly \TDBridge\Service\CopacoConfig $copacoConfig, private readonly \TDBridge\Service\CopacoFeedSync $copacoSync) {}
    #[Route(path: '/api/_action/td-bridge/suppliers', name: 'api.action.lf_supplier.providers', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function providers(): JsonResponse { return $this->respond(fn () => ['items'=>$this->offers->providers()]); }
    #[Route(path: '/api/_action/td-bridge/supplier-offers', name: 'api.action.lf_supplier.offers', methods: ['POST'], defaults: ['_acl' => ['td_bridge:read']])]
    public function listing(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) { $b=$this->body($request); return $this->offers->listing((string)($b['supplier']??'copaco'),(string)($b['term']??''),(int)($b['page']??1),$b); });
    }
    #[Route(path: '/api/_action/td-bridge/supplier-feed/{action}', name: 'api.action.lf_supplier.feed', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function feed(string $action, Request $request): JsonResponse
    {
        return $this->respond(function () use ($action,$request) {
            if (!in_array($action,['preview','commit'],true)) { throw new BridgeException('Action inconnue.'); }
            return $this->offers->feed($this->body($request),$action==='commit');
        });
    }
    #[Route(path: '/api/_action/td-bridge/supplier-bind', name: 'api.action.lf_supplier.bind', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function bind(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $b=$this->body($request);
            if (!is_bool($b['enabled']??null) || !is_string($b['supplier']??null) || !is_string($b['partNumber']??null) || (isset($b['productId']) && !is_string($b['productId']))) { throw new BridgeException('État de synchronisation requis.'); }
            $this->offers->bind((string)($b['supplier']??''),(string)($b['partNumber']??''),$b['productId']??null,$b['enabled']);
            return ['saved'=>true];
        });
    }
    #[Route(path: '/api/_action/td-bridge/supplier-sync', name: 'api.action.lf_supplier.sync', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function sync(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $b=$this->body($request);
            if (!is_array($b['parts']??null)) { throw new BridgeException('Références requises.'); }
            return ['id'=>$this->jobs->enqueue($b['parts'],$b['type']??'sync',$b['supplier']??'copaco')];
        });
    }
    #[Route(path: '/api/_action/td-bridge/reconcile-products', name: 'api.action.lf_supplier.reconcile', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function reconcile(): JsonResponse { return $this->respond(fn () => $this->lifecycle->reconcile()); }
    #[Route(path: '/api/_action/td-bridge/copaco/settings', name: 'api.action.lf_supplier.copaco_settings', methods: ['GET'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function copacoSettings(): JsonResponse { return $this->respond(fn()=> $this->copacoConfig->publicSettings()); }
    #[Route(path: '/api/_action/td-bridge/copaco/settings', name: 'api.action.lf_supplier.copaco_settings_save', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function copacoSave(Request $request): JsonResponse { return $this->respond(function()use($request){$this->copacoConfig->save($this->body($request));return ['saved'=>true];}); }
    #[Route(path: '/api/_action/td-bridge/copaco/status', name: 'api.action.lf_supplier.copaco_status', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function copacoStatus(): JsonResponse { return $this->respond(fn()=> $this->copacoSync->status()); }
    #[Route(path: '/api/_action/td-bridge/copaco/refresh', name: 'api.action.lf_supplier.copaco_refresh', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function copacoRefresh(): JsonResponse { return $this->respond(fn()=> $this->copacoSync->request()); }
    private function body(Request $request): array
    {
        if (strlen($request->getContent())>3000000) { throw new BridgeException('Requête limitée à 3 Mo.',413); }
        try { $b=json_decode($request->getContent(),true,32,JSON_THROW_ON_ERROR); }
        catch (\JsonException) { throw new BridgeException('Objet JSON invalide.'); }
        if (!is_array($b) || ($b!==[] && array_is_list($b))) { throw new BridgeException('Objet JSON attendu.'); }
        return $b;
    }
    private function respond(callable $fn): JsonResponse
    {
        try { $response=new JsonResponse($fn()); }
        catch (BridgeException $e) { $response=new JsonResponse(['errors'=>[['code'=>'LF_SUPPLIER_ERROR','detail'=>$e->getMessage()]]],in_array($e->httpStatus,[400,409,413,422,429],true)?$e->httpStatus:502); }
        $response->headers->set('Cache-Control','no-store, private');
        return $response;
    }
}
