<?php declare(strict_types=1);

namespace TDBridge\Supplier;

use TDBridge\Domain\BridgeException;

final class ConnectorRegistry
{
    private array $connectors=[];
    /** @param iterable<CatalogueConnector> $connectors */
    public function __construct(iterable $connectors)
    {
        foreach ($connectors as $connector) {
            if (isset($this->connectors[$connector->id()])) { throw new \LogicException('Duplicate supplier connector.'); }
            $this->connectors[$connector->id()]=$connector;
        }
    }
    public function get(string $id): CatalogueConnector
    {
        return $this->connectors[$id] ?? throw new BridgeException('Connecteur fournisseur non disponible.');
    }
}
