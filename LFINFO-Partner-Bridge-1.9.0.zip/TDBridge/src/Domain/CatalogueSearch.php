<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class CatalogueSearch
{
    public static function terms(mixed $value, int $limit = 20): array
    {
        if (!is_string($value) || strlen($value) > 4000) { throw new BridgeException('Liste de filtres invalide. Utilisez le séparateur ;.'); }
        $parts = [];
        foreach (preg_split('/[;\r\n]+/', $value) ?: [] as $part) {
            $part = trim($part);
            if ($part === '') { continue; }
            if (mb_strlen($part) > 200) { throw new BridgeException('Chaque filtre est limité à 200 caractères.'); }
            $parts[mb_strtolower($part)] ??= $part;
        }
        if (count($parts) > $limit) { throw new BridgeException("Maximum $limit valeurs par filtre."); }
        return array_values($parts);
    }

    /** All SQL fragments are fixed; every user value is a bound parameter. */
    public static function query(array $input): array
    {
        $page = CatalogueCriteria::integer($input['page'] ?? 1, 1, 100000);
        $size = CatalogueCriteria::integer($input['pageSize'] ?? 25, 1, 100);
        $where = []; $params = [];
        foreach (['text' => 'c.search_text', 'brands' => 'c.manufacturer', 'classes' => 'c.product_class', 'subclasses' => 'c.product_subclass'] as $key => $column) {
            $terms = self::terms($input[$key] ?? '');
            if (!$terms) { continue; }
            $clauses = [];
            foreach ($terms as $term) {
                if ($key === 'text') {
                    // Explicit escape char: %, _ and ! are searched literally.
                    $clauses[] = "$column LIKE ? ESCAPE '!'";
                    $params[] = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $term) . '%';
                } else { $clauses[] = "$column = ?"; $params[] = $term; }
            }
            $where[] = '(' . implode(' OR ', $clauses) . ')';
        }
        foreach (['onlyInStock', 'hasPrice', 'notImported'] as $key) {
            if (isset($input[$key]) && !is_bool($input[$key])) { throw new BridgeException("$key doit être booléen."); }
        }
        if ($input['onlyInStock'] ?? false) { $where[] = 'c.stock > 0'; }
        if ($input['hasPrice'] ?? false) { $where[] = 'c.cost > 0'; }
        if ($input['notImported'] ?? false) { $where[] = 'p.part_number IS NULL'; }
        foreach (['minCost' => 'c.cost >= ?', 'maxCost' => 'c.cost <= ?', 'minStock' => 'c.stock >= ?'] as $key => $sql) {
            $value = $input[$key] ?? '';
            if ($value === '' || $value === null) { continue; }
            if (!is_numeric($value) || !is_finite((float) $value) || (float) $value < 0 || (float) $value > 100000000 || ($key === 'minStock' && floor((float) $value) !== (float) $value)) { throw new BridgeException("Filtre numérique invalide : $key."); }
            $where[] = $sql; $params[] = $key === 'minStock' ? (int) $value : (float) $value;
        }
        if (isset($input['minCost'], $input['maxCost']) && $input['minCost'] !== '' && $input['maxCost'] !== '' && $input['minCost'] !== null && $input['maxCost'] !== null && (float) $input['minCost'] > (float) $input['maxCost']) { throw new BridgeException('Le prix minimum dépasse le prix maximum.'); }
        if (!empty($input['productStatusCode'])) {
            if (!in_array($input['productStatusCode'], ['Active', 'Allocated', 'Discontinued', 'PhasedOut'], true)) { throw new BridgeException('Statut invalide.'); }
            $where[] = 'c.product_status = ?'; $params[] = $input['productStatusCode'];
        }
        return ['where' => $where ? ' WHERE ' . implode(' AND ', $where) : '', 'params' => $params, 'page' => $page, 'pageSize' => $size];
    }
}
