<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueSearch;
use TDBridge\Domain\ProductMapper;

/** Supplier data only. Never creates a Shopware product or category. */
final class SupplierCache
{
    private const LATEST = " NOT EXISTS (SELECT 1 FROM td_bridge_supplier newer WHERE newer.part_number = c.part_number AND (newer.indexed_at > c.indexed_at OR (newer.indexed_at = c.indexed_at AND newer.scope_id > c.scope_id)))";
    public function __construct(private readonly Connection $db, private readonly TdClient $client, private readonly Settings $settings, private readonly ProductMapper $mapper, private readonly ?\Psr\Log\LoggerInterface $logger = null) {}

    public function status(): array
    {
        return ['scopes' => $this->db->fetchAllAssociative('SELECT s.*, (SELECT COUNT(*) FROM td_bridge_supplier c WHERE c.scope_id = s.id) AS indexed FROM td_bridge_scope s ORDER BY brand'),
            'indexed' => (int) $this->db->fetchOne('SELECT COUNT(DISTINCT part_number) FROM td_bridge_supplier')];
    }

    public function action(string $action, array $input): array
    {
        return $this->locked(function () use ($action, $input): array {
            if ($action === 'start') {
                $brands = CatalogueSearch::terms($input['brands'] ?? '');
                if (!$brands && ($input['fullCatalogue'] ?? false) !== true) { throw new BridgeException('Indiquez au moins une marque ou confirmez le catalogue complet.'); }
                $this->db->transactional(function () use ($brands): void {
                    foreach ($brands ?: [''] as $brand) {
                        $id = hash('sha256', mb_strtolower($brand));
                        // Refresh intentionally replaces only this scope; other brands are retained.
                        $this->db->delete('td_bridge_supplier', ['scope_id' => $id]);
                        $this->db->delete('td_bridge_scope', ['id' => $id]);
                        $now = gmdate('Y-m-d H:i:s');
                        $this->db->insert('td_bridge_scope', ['id' => $id, 'brand' => $brand, 'status' => 'running', 'available_at' => $now, 'started_at' => $now, 'updated_at' => $now]);
                    }
                });
            } elseif (in_array($action, ['pause', 'resume'], true)) {
                $id = $input['id'] ?? '';
                if (!is_string($id) || !preg_match('/^[a-f0-9]{64}$/D', $id)) { throw new BridgeException('Index invalide.'); }
                $sql = $action === 'pause'
                    ? "UPDATE td_bridge_scope SET status = 'paused', updated_at = UTC_TIMESTAMP(3) WHERE id = ? AND status = 'running'"
                    : "UPDATE td_bridge_scope SET status = 'running', attempts = 0, last_error = NULL, available_at = UTC_TIMESTAMP(3), updated_at = UTC_TIMESTAMP(3) WHERE id = ? AND status IN ('paused', 'failed')";
                if (!$this->db->executeStatement($sql, [$id])) { throw new BridgeException('Cet index a changé d’état. Actualisez la liste.', 409); }
            } else { throw new BridgeException('Action inconnue.'); }
            return $this->status();
        });
    }

    /** One API page per tick; the cursor and page are committed together. */
    public function tick(): array
    {
        return $this->locked(function (): array {
            $scope = $this->db->fetchAssociative("SELECT * FROM td_bridge_scope WHERE status = 'running' AND available_at <= UTC_TIMESTAMP(3) ORDER BY updated_at, id LIMIT 1");
            if (!$scope) { return ['state' => 'idle']; }
            try {
                $page = (int) $scope['next_page'];
                $criteria = ['page' => $page, 'pageSize' => 100, 'includeStock' => true, 'includePrice' => true];
                if ($scope['brand'] !== '') { $criteria['manufacturer'] = $scope['brand']; }
                $response = $this->client->catalogue($criteria);
                $mapped = $this->mapper->catalogue($response, $this->settings->all()['mapping']);
                $size = filter_var($response['pageSize'] ?? 100, FILTER_VALIDATE_INT);
                if (!$size || $size < 1 || $size > 100) { throw new BridgeException('Pagination fournisseur invalide.', 422); }
                $total = $mapped['total'];
                if (!$mapped['items'] && $total !== null && ($page - 1) * $size < $total) { throw new BridgeException('Page fournisseur vide avant la fin annoncée.', 422); }
                $complete = $total !== null ? $page * $size >= $total : count($mapped['items']) < $size;
                $rawRows = ProductMapper::path($response, array_replace(ProductMapper::DEFAULT_MAP, $this->settings->all()['mapping'])['items']);
                $this->db->transactional(function () use ($scope, $page, $mapped, $rawRows, $total, $complete): void {
                    foreach ($mapped['items'] as $i => $item) {
                        $raw = $rawRows[$i] ?? [];
                        $this->db->executeStatement('INSERT INTO td_bridge_supplier (scope_id, part_number, manufacturer, product_class, product_subclass, product_status, class_label, subclass_label, search_text, stock, cost, payload, indexed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE manufacturer=VALUES(manufacturer), product_class=VALUES(product_class), product_subclass=VALUES(product_subclass), product_status=VALUES(product_status), class_label=VALUES(class_label), subclass_label=VALUES(subclass_label), search_text=VALUES(search_text), stock=VALUES(stock), cost=VALUES(cost), payload=VALUES(payload), indexed_at=VALUES(indexed_at)',
                            [$scope['id'], $item['partNumber'], mb_substr($item['manufacturer'] ?? '', 0, 200), mb_substr($item['class'] ?? '', 0, 200), mb_substr($item['subclass'] ?? '', 0, 200), mb_substr($item['status'] ?? '', 0, 30), mb_substr((string) ($raw['classDesc'] ?? ''), 0, 255), mb_substr((string) ($raw['subclassDesc'] ?? ''), 0, 255), implode(' ', array_filter(array_merge(array_intersect_key($item, array_flip(['partNumber', 'name', 'description', 'manufacturer', 'manufacturerNumber', 'ean'])), [(string) ($raw['familyDesc'] ?? ''), (string) ($raw['classDesc'] ?? ''), (string) ($raw['subclassDesc'] ?? '')]))), $item['stock'], $item['cost'], json_encode($item, JSON_THROW_ON_ERROR)]);
                    }
                    $now = gmdate('Y-m-d H:i:s');
                    $this->db->update('td_bridge_scope', ['next_page' => $page + 1, 'scanned' => (int) $scope['scanned'] + count($mapped['items']), 'total' => $total, 'status' => $complete ? 'ready' : 'running', 'attempts' => 0, 'last_error' => null, 'available_at' => gmdate('Y-m-d H:i:s', time() + 2), 'completed_at' => $complete ? $now : null, 'updated_at' => $now], ['id' => $scope['id']]);
                });
                return ['state' => $complete ? 'ready' : 'running', 'id' => $scope['id']];
            } catch (\Throwable $e) {
                if (!$e instanceof BridgeException) { $this->logger?->error('LFINFO Partner Bridge supplier cache failed.', ['exception' => $e, 'scope' => $scope['id']]); }
                $attempts = (int) $scope['attempts'] + 1;
                $retry = $e instanceof BridgeException && ($e->httpStatus === 429 || $e->httpStatus >= 500) && $attempts < 5;
                $delay = max($e instanceof BridgeException ? $e->retryAfter : 0, min(3600, 30 * 2 ** $attempts));
                $message = $e instanceof BridgeException ? $e->getMessage() : 'Échec interne du chargement. Consultez le journal serveur.';
                $this->db->update('td_bridge_scope', ['status' => $retry ? 'running' : 'failed', 'attempts' => $attempts, 'last_error' => mb_substr($message, 0, 500), 'available_at' => gmdate('Y-m-d H:i:s', time() + $delay), 'updated_at' => gmdate('Y-m-d H:i:s')], ['id' => $scope['id']]);
                return ['state' => $retry ? 'retry' : 'failed'];
            }
        });
    }

    public function search(array $input): array
    {
        $query = CatalogueSearch::query($input);
        $where = $query['where'] . ($query['where'] ? ' AND ' : ' WHERE ') . self::LATEST;
        $from = ' FROM td_bridge_supplier c LEFT JOIN td_bridge_product p ON p.part_number = c.part_number';
        $total = (int) $this->db->fetchOne('SELECT COUNT(*)' . $from . $where, $query['params']);
        $rows = $this->db->fetchAllAssociative('SELECT c.payload, c.indexed_at' . $from . $where . ' ORDER BY c.manufacturer, c.part_number LIMIT ' . $query['pageSize'] . ' OFFSET ' . (($query['page'] - 1) * $query['pageSize']), $query['params']);
        return ['items' => array_map(static fn (array $row): array => json_decode($row['payload'], true, 512, JSON_THROW_ON_ERROR) + ['indexedAt' => $row['indexed_at']], $rows), 'total' => $total, 'source' => 'supplier-cache', 'coverage' => $this->status()];
    }

    public function facets(array $input): array
    {
        // Filter taxonomy by selected brands, while keeping other facets discoverable.
        $query = CatalogueSearch::query(['brands' => $input['brands'] ?? '']);
        $where = $query['where'] . ($query['where'] ? ' AND ' : ' WHERE ') . self::LATEST;
        return ['brands' => $this->db->fetchAllAssociative('SELECT c.manufacturer AS value, COUNT(*) AS count FROM td_bridge_supplier c WHERE ' . self::LATEST . ' GROUP BY c.manufacturer ORDER BY c.manufacturer'),
            'classes' => $this->db->fetchAllAssociative('SELECT c.product_class AS value, MAX(c.class_label) AS label, COUNT(*) AS count FROM td_bridge_supplier c' . $where . ' GROUP BY c.product_class ORDER BY c.product_class', $query['params']),
            'subclasses' => $this->db->fetchAllAssociative('SELECT c.product_class AS parent, c.product_subclass AS value, MAX(c.subclass_label) AS label, COUNT(*) AS count FROM td_bridge_supplier c' . $where . ' GROUP BY c.product_class, c.product_subclass ORDER BY c.product_class, c.product_subclass', $query['params']), 'countsAvailable' => true];
    }

    private function locked(callable $fn): array
    {
        if ((int) $this->db->fetchOne("SELECT GET_LOCK('tdbridge.supplier-cache', 0)") !== 1) { throw new BridgeException('Chargement déjà en cours. Réessayez dans un instant.', 409); }
        try { return $fn(); } finally { $this->db->fetchOne("SELECT RELEASE_LOCK('tdbridge.supplier-cache')"); }
    }
}
