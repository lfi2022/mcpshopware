<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class BridgeException extends \RuntimeException
{
    public function __construct(string $message, public readonly int $httpStatus = 400, public readonly int $retryAfter = 0)
    {
        parent::__construct($message);
    }
}
