<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Pricing\Price;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\ProductMapper;

final class ProductImporter
{
    public function __construct(
        private readonly Connection $db,
        private readonly EntityRepository $products,
        private readonly EntityRepository $taxes,
        private readonly EntityRepository $currencies,
        private readonly EntityRepository $manufacturers,
    ) {}

    public function import(array $item, array $options, bool $sync): string
    {
        $context = Context::createDefaultContext();
        $part = $item['partNumber'];
        $supplier = $options['supplier'] ?? 'tdsynnex';
        $external = $supplier !== 'tdsynnex';
        $link = $external ? $this->db->fetchAssociative('SELECT *,LOWER(HEX(product_id)) AS product_uuid FROM lf_supplier_offer WHERE supplier=? AND part_number=? AND product_id IS NOT NULL', [$supplier,$part]) : $this->db->fetchAssociative('SELECT *, LOWER(HEX(product_id)) AS product_uuid FROM td_bridge_product WHERE part_number = ?', [$part]);
        $expected = $options['_linkedProducts'][$part] ?? ($options['_targetProductId'] ?? null);
        if ($expected !== null && (!$link || $link['product_uuid'] !== $expected)) { return 'ignored_deleted'; }
        if ($sync && (!$link || !(bool) $link['sync_enabled'])) { return 'ignored'; }
        $id = $link ? $link['product_uuid'] : Uuid::fromStringToHex($external ? 'lfinfo.product.' . $supplier . '.' . $part : 'tdbridge.product.' . $part);
        $existing = $this->products->search(new Criteria([$id]), $context)->first();
        if ($link && !$existing) { return 'ignored_deleted'; }
        if (!$link && $existing) { throw new BridgeException('Identifiant produit déjà utilisé sans liaison fournisseur. Import refusé.'); }
        $new = !$existing;
        $taxId = $new ? $options['taxId'] : $existing->getTaxId();
        if (!$taxId || !$options['currencyId']) { throw new BridgeException('Choisissez la TVA et la devise dans les paramètres avant import.'); }
        $tax = $this->taxes->search(new Criteria([$taxId]), $context)->first();
        $currency = $this->currencies->search(new Criteria([$options['currencyId']]), $context)->first();
        if (!$tax || !$currency || $currency->getIsoCode() !== $options['currencyCode']) { throw new BridgeException('TVA ou devise Shopware absente ou incohérente avec le code ISO.'); }
        if ($options['currencyId'] !== \Shopware\Core\Defaults::CURRENCY) { throw new BridgeException('Choisissez la devise principale Shopware. Aucune conversion automatique des devises.'); }
        $write = ['id' => $id];
        if ($new) {
            $sku = ($external ? strtoupper($supplier) . '-' : $options['prefix']) . $part;
            if (strlen($sku) > 64) { throw new BridgeException('SKU trop long : réduisez le préfixe.'); }
            $collision = $this->products->searchIds((new Criteria())->addFilter(new EqualsFilter('productNumber', $sku)), $context)->firstId();
            if ($collision) { throw new BridgeException('Ce SKU existe déjà dans Shopware ; aucune prise de contrôle automatique.'); }
            $write += ['productNumber' => $sku, 'taxId' => $taxId, 'active' => (bool) $options['activateProducts']];
            if ($options['categoryId']) { $write['categories'] = [['id' => $options['categoryId']]]; }
            if ($options['salesChannelId']) { $write['visibilities'] = [['salesChannelId' => $options['salesChannelId'], 'visibility' => 30]]; }
        }
        if ($new || $options['syncStock']) {
            if ($item['stock'] === null) { throw new BridgeException('Stock absent du mapping : mise à jour refusée.'); }
            $write['stock'] = max(0, $item['stock'] - (int) $options['stockReserve']);
        }
        if ($new || $options['syncPrice']) {
            if ($item['cost'] === null || $item['cost'] <= 0 || strtoupper($item['currency'] ?? '') !== $options['currencyCode']) { throw new BridgeException('Prix net absent, nul ou devise fournisseur différente.'); }
            $purchasePrice = ProductMapper::purchasePrice($item['cost'], $tax->getTaxRate(), $options['currencyCode']);
            $price = ProductMapper::sellingPrice($item['cost'], (float) $options['markup'], (float) $options['fixedMarkup'], $tax->getTaxRate());
            // Preserve explicit prices in other currencies.
            $prices = [];
            if ($existing && $existing->getPrice()) {
                foreach ($existing->getPrice() as $current) {
                    if ($current->getCurrencyId() !== $options['currencyId']) { $prices[] = self::priceData($current); }
                }
            }
            $prices[] = ['currencyId' => $options['currencyId'], 'linked' => true] + $price;
            $write['price'] = $prices;
            // Native purchase prices feed the margin calculation in the product form.
            $purchasePrices = [];
            if ($existing && $existing->getPurchasePrices()) {
                foreach ($existing->getPurchasePrices() as $current) {
                    if ($current->getCurrencyId() !== $options['currencyId']) { $purchasePrices[] = self::priceData($current); }
                }
            }
            // Recompute from supplier cost, never from the previously stored purchase price.
            $purchasePrices[] = ['currencyId' => $options['currencyId'], 'linked' => true] + $purchasePrice;
            $write['purchasePrices'] = $purchasePrices;
        }
        if ($new || ($options['syncContent'] && !($options['icecatEnabled'] ?? false))) {
            $write['name'] = mb_substr(strip_tags($item['name'] ?: $part), 0, 255);
            if ($item['description'] !== null) { $write['description'] = strip_tags($item['description']); }
            if ($item['manufacturerNumber']) { $write['manufacturerNumber'] = mb_substr($item['manufacturerNumber'], 0, 255); }
            if ($item['ean'] && preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D', $item['ean'])) { $write['ean'] = $item['ean']; }
            if ($item['manufacturer']) {
                $manufacturerId = $this->manufacturers->searchIds((new Criteria())->addFilter(new EqualsFilter('name', $item['manufacturer'])), $context)->firstId();
                $write['manufacturer'] = ['id' => $manufacturerId ?: Uuid::fromStringToHex('tdbridge.manufacturer.' . mb_strtolower($item['manufacturer'])), 'name' => mb_substr(strip_tags($item['manufacturer']), 0, 255)];
            }
        }
        $this->db->transactional(function () use ($write, $context, $id, $item, $options, $part, $new, $external): void {
            if (!$new) {
                if (!$this->db->fetchOne('SELECT id FROM product WHERE id=UNHEX(?) AND version_id=UNHEX(?) FOR UPDATE', [$id, \Shopware\Core\Defaults::LIVE_VERSION])) { throw new BridgeException('Produit supprimé : mise à jour annulée.'); }
                $source = $this->db->fetchAssociative('SELECT supplier,part_number FROM lf_supplier_source WHERE product_id=UNHEX(?) FOR UPDATE', [$id]);
                if (($external && !$source) || ($source && ($source['supplier'] !== ($options['supplier'] ?? 'tdsynnex') || $source['part_number'] !== $part))) { throw new BridgeException('La source de synchronisation a changé : mise à jour annulée.'); }
            }
            if (!$new) {
                $enabled = $external
                    ? $this->db->fetchOne('SELECT sync_enabled FROM lf_supplier_offer WHERE supplier=? AND part_number=? AND product_id=UNHEX(?) FOR UPDATE', [$options['supplier'],$part,$id])
                    : $this->db->fetchOne('SELECT sync_enabled FROM td_bridge_product WHERE part_number=? AND product_id=UNHEX(?) FOR UPDATE', [$part,$id]);
                if (!$enabled) { throw new BridgeException('Suivi suspendu ou liaison retirée : mise à jour annulée.'); }
            }
            if ($new) { $this->products->upsert([$write], $context); }
            else { $this->products->update([$write], $context); }
            if ($external) {
                $this->db->executeStatement('UPDATE lf_supplier_offer SET product_id=UNHEX(?),sync_enabled=1,last_synced_at=UTC_TIMESTAMP(3),next_sync_at=?,last_error=NULL WHERE supplier=? AND part_number=?', [$id,gmdate('Y-m-d H:i:s',time()+(int)$options['syncMinutes']*60),$options['supplier'],$part]);
                if ($new) { $this->db->executeStatement('INSERT INTO lf_supplier_source (product_id,supplier,part_number,updated_at) VALUES (UNHEX(?),?,?,UTC_TIMESTAMP(3))',[$id,$options['supplier'],$part]); }
                return;
            }
            $this->db->executeStatement(
                'INSERT INTO td_bridge_product (part_number, product_id, name, cost, currency, last_synced_at, next_sync_at, created_at) VALUES (?, UNHEX(?), ?, ?, ?, UTC_TIMESTAMP(3), ?, UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE name = VALUES(name), cost = VALUES(cost), currency = VALUES(currency), last_synced_at = VALUES(last_synced_at), next_sync_at = VALUES(next_sync_at), last_error = NULL',
                [$part, $id, mb_substr(strip_tags($item['name'] ?: $part), 0, 255), $item['cost'], $item['currency'], gmdate('Y-m-d H:i:s', time() + (int) $options['syncMinutes'] * 60)]
            );
        });
        return $new ? 'created' : 'updated';
    }

    private static function priceData(Price $price): array
    {
        $data = ['currencyId' => $price->getCurrencyId(), 'net' => $price->getNet(), 'gross' => $price->getGross(), 'linked' => $price->getLinked()];
        foreach (['listPrice' => $price->getListPrice(), 'regulationPrice' => $price->getRegulationPrice()] as $key => $nested) {
            if ($nested) { $data[$key] = ['net' => $nested->getNet(), 'gross' => $nested->getGross(), 'linked' => $nested->getLinked()]; }
        }
        return $data;
    }
}
