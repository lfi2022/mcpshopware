<?php declare(strict_types=1);

namespace TDBridge\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use TDBridge\Domain\BridgeException;
use TDBridge\Service\IngramConfig;
use TDBridge\Service\IngramClient;
use TDBridge\Service\IngramService;

#[Route(defaults:['_routeScope'=>['api']])]
final class IngramController
{
    public function __construct(private readonly IngramConfig $config,private readonly IngramClient $client,private readonly IngramService $service) {}
    #[Route(path:'/api/_action/td-bridge/ingram/settings',name:'api.action.lf_ingram.settings',methods:['GET'],defaults:['_acl'=>['td_bridge:configure']])]
    public function settings(): JsonResponse { return $this->respond(fn()=> $this->config->publicSettings()); }
    #[Route(path:'/api/_action/td-bridge/ingram/settings',name:'api.action.lf_ingram.settings_save',methods:['POST'],defaults:['_acl'=>['td_bridge:configure']])]
    public function save(Request $request): JsonResponse { return $this->respond(function()use($request){$this->config->save($this->body($request));return ['saved'=>true];}); }
    #[Route(path:'/api/_action/td-bridge/ingram/test',name:'api.action.lf_ingram.test',methods:['POST'],defaults:['_acl'=>['td_bridge:configure']])]
    public function test(): JsonResponse { return $this->respond(fn()=> $this->client->test()); }
    #[Route(path:'/api/_action/td-bridge/ingram/catalogue',name:'api.action.lf_ingram.catalogue',methods:['POST'],defaults:['_acl'=>['td_bridge:read']])]
    public function search(Request $request): JsonResponse { return $this->respond(fn()=> $this->service->search($this->body($request))); }
    #[Route(path:'/api/_action/td-bridge/ingram/link',name:'api.action.lf_ingram.link',methods:['POST'],defaults:['_acl'=>['td_bridge:import']])]
    public function link(Request $request): JsonResponse
    {
        return $this->respond(function()use($request){$b=$this->body($request);$part=$b['partNumber']??null;$id=$b['productId']??null;
            if(!is_string($part)||$part===''||strlen($part)>100||($id!==null&&(!is_string($id)||!preg_match('/^[a-f0-9]{32}$/D',$id)))||!is_bool($b['enabled']??null)){throw new BridgeException('Liaison Ingram invalide.');}
            $this->service->link($part,$id,$b['enabled']);return ['saved'=>true];
        });
    }
    private function body(Request $request): array
    {
        if(strlen($request->getContent())>65536){throw new BridgeException('Requête trop volumineuse.',413);}
        try{$b=json_decode($request->getContent(),true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new BridgeException('JSON invalide.');}
        if(!is_array($b)||($b!==[]&&array_is_list($b))){throw new BridgeException('Objet JSON attendu.');}return $b;
    }
    private function respond(callable $fn): JsonResponse
    {
        try{$r=new JsonResponse($fn());}catch(BridgeException $e){$code=in_array($e->httpStatus,[400,409,413,422,429],true)?$e->httpStatus:502;$r=new JsonResponse(['errors'=>[['code'=>'LF_INGRAM_ERROR','detail'=>$e->getMessage()]]],$code);if($e->retryAfter>0){$r->headers->set('Retry-After',(string)$e->retryAfter);}}
        $r->headers->set('Cache-Control','no-store, private');return $r;
    }
}
