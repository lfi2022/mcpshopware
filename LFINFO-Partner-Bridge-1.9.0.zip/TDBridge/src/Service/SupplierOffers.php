<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Defaults;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\SupplierFeed;

final class SupplierOffers
{
    public function __construct(private readonly Connection $db) {}
    public function providers(): array
    {
        return [
            ['id' => 'tdsynnex', 'name' => 'TD SYNNEX', 'transport' => 'API', 'available' => true],
            ['id' => 'copaco', 'name' => 'Copaco', 'transport' => 'Datafile XML / CSV (FTP ou FTPS)', 'available' => true, 'note' => 'Catalogue revendeur quotidien ; ATP temps réel exclu des actualisations automatiques.'],
            ['id' => 'ingram', 'name' => 'Ingram Micro', 'transport' => 'API revendeur v6 Belgique', 'available' => true, 'note' => 'Recherche, prix et stocks via API ; accès à configurer.'],
        ];
    }
    public function feed(array $input, bool $commit): array
    {
        if (($input['supplier'] ?? '') !== 'copaco') { throw new BridgeException('Ce fournisseur ne prend pas en charge le chargement CSV.'); }
        if (!is_string($input['csv'] ?? null) || !is_array($input['mapping'] ?? null) || (isset($input['delimiter']) && !is_string($input['delimiter']))) { throw new BridgeException('CSV et mapping requis.'); }
        $items = SupplierFeed::parse($input['csv'], $input['mapping'], $input['delimiter'] ?? ';');
        if ($commit) {
            $this->db->transactional(function () use ($items): void {
                foreach ($items as $item) {
                    $this->db->executeStatement('INSERT INTO lf_supplier_offer (supplier,part_number,name,manufacturer,manufacturer_number,ean,cost,currency,stock,observed_at,next_sync_at) VALUES (?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE name=VALUES(name),manufacturer=VALUES(manufacturer),manufacturer_number=VALUES(manufacturer_number),ean=VALUES(ean),cost=VALUES(cost),currency=VALUES(currency),stock=VALUES(stock),observed_at=VALUES(observed_at),next_sync_at=VALUES(next_sync_at),source_kind=\'manual\',catalogue_available=1,cost_inclusive=NULL,description=NULL,product_class=\'\',supplier_status=\'\',last_error=NULL',
                        ['copaco', $item['partNumber'], $item['name'], $item['manufacturer'], $item['manufacturerNumber'], $item['ean'], $item['cost'], $item['currency'], $item['stock']]);
                }
            });
        }
        return ['total' => count($items), 'saved' => $commit, 'sample' => array_slice($items, 0, 10)];
    }
    public function listing(string $supplier, string $term, int $page, array $filters = []): array
    {
        if ($supplier !== 'copaco' || mb_strlen($term)>200) { throw new BridgeException('Recherche fournisseur invalide.'); }
        $query=\TDBridge\Domain\CatalogueSearch::query(['text'=>$term,'brands'=>$filters['brands']??'','classes'=>$filters['classes']??'','minCost'=>$filters['minCost']??'','maxCost'=>$filters['maxCost']??'','onlyInStock'=>$filters['onlyInStock']??false,'notImported'=>$filters['notImported']??false,'page'=>$page,'pageSize'=>25]);
        $where=str_replace('p.part_number IS NULL','c.product_id IS NULL',$query['where']);
        $where=($where ?: ' WHERE 1=1') . ' AND c.supplier=? AND c.catalogue_available=1'; $params=[...$query['params'],$supplier];
        $table="(SELECT *,CONCAT_WS(' ',part_number,name,manufacturer,manufacturer_number,ean) AS search_text FROM lf_supplier_offer) c";
        return ['items'=>$this->db->fetchAllAssociative('SELECT c.supplier,c.part_number,c.name,c.manufacturer,c.manufacturer_number,c.ean,c.cost,c.currency,c.stock,c.product_class,c.supplier_status,c.cost_inclusive,c.source_kind,c.sync_enabled,c.observed_at,c.last_synced_at,c.last_error,LOWER(HEX(c.product_id)) AS product_id FROM '.$table.$where.' ORDER BY c.name,c.part_number LIMIT 25 OFFSET '.(($query['page']-1)*25),$params),
            'total'=>(int)$this->db->fetchOne('SELECT COUNT(*) FROM '.$table.$where,$params),'page'=>$query['page']];
    }
    public function bind(string $supplier, string $part, ?string $productId, bool $enabled): void
    {
        if (!in_array($supplier, ['tdsynnex', 'copaco', 'ingram'], true) || $part === '' || strlen($part) > 100 || ($productId !== null && !preg_match('/^[a-f0-9]{32}$/D', $productId))) { throw new BridgeException('Liaison fournisseur invalide.'); }
        $this->db->transactional(function () use ($supplier, $part, $productId, $enabled): void {
            if ($productId && !$this->db->fetchOne('SELECT id FROM product WHERE id=UNHEX(?) AND version_id=UNHEX(?) FOR UPDATE', [$productId, Defaults::LIVE_VERSION])) { throw new BridgeException('Produit Shopware introuvable.'); }
            $table = $supplier === 'tdsynnex' ? 'td_bridge_product' : 'lf_supplier_offer';
            $where = $supplier === 'tdsynnex' ? 'part_number=?' : 'supplier=? AND part_number=?';
            $params = $supplier === 'tdsynnex' ? [$part] : [$supplier, $part];
            $old = $this->db->fetchAssociative("SELECT LOWER(HEX(product_id)) AS id FROM $table WHERE $where FOR UPDATE", $params);
            if ($supplier === 'tdsynnex' && !$old && $productId) {
                if ($this->db->fetchOne('SELECT part_number FROM td_bridge_product WHERE product_id=UNHEX(?)', [$productId])) { throw new BridgeException('Ce produit possède déjà une liaison TD SYNNEX.'); }
                $this->db->executeStatement('INSERT INTO td_bridge_product (part_number,product_id,name,sync_enabled,next_sync_at,created_at) VALUES (?,UNHEX(?),?,?,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3))', [$part,$productId,$part,(int)$enabled]);
            } elseif (!$old) { throw new BridgeException('Offre fournisseur introuvable.'); }
            else {
                if (!$productId && $old['id']) {
                    $this->db->executeStatement('INSERT INTO lf_supplier_detached (supplier,part_number,detached_at) VALUES (?,?,UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE detached_at=VALUES(detached_at)',[$supplier,$part]);
                }
                if ($supplier === 'tdsynnex' && $productId && $old['id'] !== $productId) { throw new BridgeException('Déliez cette référence avant de la relier à un autre produit.'); }
                if ($supplier === 'tdsynnex' && !$productId) { $this->db->executeStatement("DELETE FROM $table WHERE $where", $params); }
                else { $this->db->executeStatement("UPDATE $table SET product_id=UNHEX(?),sync_enabled=?,next_sync_at=UTC_TIMESTAMP(3) WHERE $where", [$productId,(int)($enabled && $productId !== null),...$params]); }
            }
            $this->db->executeStatement('DELETE FROM lf_supplier_source WHERE supplier=? AND part_number=?', [$supplier,$part]);
            if ($productId && $enabled) {
                // Selecting a source pauses competing links; queued jobs also recheck this choice.
                $this->db->executeStatement('UPDATE td_bridge_product SET sync_enabled=0 WHERE product_id=UNHEX(?)', [$productId]);
                $this->db->executeStatement('UPDATE lf_supplier_offer SET sync_enabled=0 WHERE product_id=UNHEX(?)', [$productId]);
                $this->db->executeStatement("UPDATE $table SET sync_enabled=1 WHERE $where", $params);
                $this->db->executeStatement('INSERT INTO lf_supplier_source (product_id,supplier,part_number,updated_at) VALUES (UNHEX(?),?,?,UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE supplier=VALUES(supplier),part_number=VALUES(part_number),updated_at=VALUES(updated_at)', [$productId,$supplier,$part]);
            }
        });
    }
    public function item(string $supplier, string $part, bool $allowUnlinked = false): ?array
    {
        $row = $this->db->fetchAssociative('SELECT o.*, LOWER(HEX(o.product_id)) AS product_uuid FROM lf_supplier_offer o LEFT JOIN product p ON p.id=o.product_id AND p.version_id=UNHEX(?) LEFT JOIN lf_supplier_source s ON s.product_id=o.product_id AND s.supplier=o.supplier AND s.part_number=o.part_number WHERE o.supplier=? AND o.part_number=? AND ((o.sync_enabled=1 AND p.id IS NOT NULL AND s.product_id IS NOT NULL)' . ($allowUnlinked ? ' OR o.product_id IS NULL' : '') . ')', [Defaults::LIVE_VERSION,$supplier,$part]);
        if (!$row) { return null; }
        // A local feed must not silently overwrite current data with an old snapshot.
        if (!(bool)$row['catalogue_available']) { throw new BridgeException('Offre absente du dernier catalogue : produit Shopware conservé sans mise à zéro.'); }
        $hours=$row['source_kind']==='datafile'?36:24;
        if (strtotime($row['observed_at'].' UTC')<time()-$hours*3600) { throw new BridgeException('Offre périmée : rechargez le Datafile ou le fichier manuel avant synchronisation.'); }
        return ['partNumber'=>$part,'name'=>$row['name'],'manufacturer'=>$row['manufacturer'],'manufacturerNumber'=>$row['manufacturer_number'],'ean'=>$row['ean'],'description'=>$row['description']??null,
            'cost'=>$row['cost'] === null ? null : (float)$row['cost'],'currency'=>$row['currency'],'stock'=>$row['stock'] === null ? null : (int)$row['stock'],'_productId'=>$row['product_uuid']];
    }
}
