<?php declare(strict_types=1);

namespace TDBridge;

use Shopware\Core\Framework\Plugin;

final class TDBridge extends Plugin
{
    // Keep mappings and history on uninstall. Removing the extension never removes shop products.
}
