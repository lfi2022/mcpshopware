<?php declare(strict_types=1);

namespace TDBridge\Domain;

/** Official Datafile schema, not the XML order/ATP gateway. Bounded streaming reader. */
final class CopacoDatafile
{
    public function rows(string $file, string $format, string $encoding='UTF-8'): \Generator
    {
        if (!is_file($file) || filesize($file)>200000000 || filesize($file)===0) { throw new BridgeException('Datafile vide ou supérieur à 200 Mo.'); }
        if (!in_array($encoding,['UTF-8','Windows-1252','ISO-8859-1'],true)) { throw new BridgeException('Encodage Datafile invalide.'); }
        if ($format==='xml') { yield from $this->xml($file); }
        elseif ($format==='csv') { yield from $this->csv($file,$encoding); }
        else { throw new BridgeException('Format Datafile invalide.'); }
    }
    private function xml(string $file): \Generator
    {
        $previous=libxml_use_internal_errors(true);libxml_clear_errors();$reader=new \XMLReader();$count=0;$root=false;
        try {
            if (!$reader->open($file,null,LIBXML_NONET|LIBXML_COMPACT)) { throw new BridgeException('Datafile XML illisible.'); }
            $reader->setParserProperty(\XMLReader::LOADDTD,false);$reader->setParserProperty(\XMLReader::SUBST_ENTITIES,false);$reader->setParserProperty(\XMLReader::VALIDATE,false);
            while ($reader->read()) {
                if ($reader->nodeType===\XMLReader::DOC_TYPE && str_contains($reader->readOuterXml(),'[')) { throw new BridgeException('Déclarations internes XML interdites.'); }
                if ($reader->nodeType===\XMLReader::ENTITY_REF) { throw new BridgeException('Entités XML non prises en charge.'); }
                if ($reader->nodeType!==\XMLReader::ELEMENT) { continue; }
                if ($reader->depth===0) {
                    if ($reader->name!=='XMLOUT_pricelist_01') { throw new BridgeException('Racine Datafile Copaco incorrecte. Utilisez le catalogue, pas une réponse ATP ou une commande.'); }
                    $root=true;
                }
                if ($reader->depth===1 && in_array($reader->name,['Item','item'],true)) {
                    if (++$count>1000000) { throw new BridgeException('Datafile limité à un million de références.'); }
                    $fragment=$reader->readOuterXml();
                    if (strlen($fragment)>262144) { throw new BridgeException('Article XML trop volumineux.'); }
                    $item=simplexml_load_string($fragment,\SimpleXMLElement::class,LIBXML_NONET|LIBXML_COMPACT);
                    if (!$item) { throw new BridgeException('Article XML invalide.'); }
                    // Both the documented mixed-case dialect and the delivered lower-case dialect.
                    $fields=[];
                    foreach($item->children() as $key=>$value){$fields[strtolower($key)][]=$value;}
                    foreach (['item_id','vendor_id','vendor','long_desc','price','stock','item_group','status'] as $key) {
                        if(count($fields[$key]??[])!==1){throw new BridgeException('Champ XML Datafile manquant ou dupliqué : '.$key);}
                    }
                    foreach(['ean_code','price_incl_levies'] as $key){if(count($fields[$key]??[])>1){throw new BridgeException('Champ XML Datafile dupliqué : '.$key);}}
                    $get=static fn(string $key):string=>(string)($fields[$key][0]??'');
                    $currency=static function(\SimpleXMLElement $element):string{
                        $values=[];foreach($element->attributes() as $key=>$value){if(strtolower($key)==='currency'){$values[]=(string)$value;}}
                        if(count($values)!==1){throw new BridgeException('Attribut devise Datafile manquant ou dupliqué.');}return $values[0];
                    };
                    if(isset($fields['price_incl_levies']) && $currency($fields['price_incl_levies'][0])!=='EUR'){throw new BridgeException('Devise du prix avec taxes fournisseur incohérente.');}
                    yield $this->normalize(['part'=>$get('item_id'),'mpn'=>$get('vendor_id'),'brand'=>$get('vendor'),'name'=>$get('long_desc'),'cost'=>$get('price'),
                        'currency'=>$currency($fields['price'][0]),'stock'=>$get('stock'),'category'=>$get('item_group'),'ean'=>$get('ean_code'),'status'=>$get('status'),'inclusive'=>$get('price_incl_levies')]);
                }
            }
            if (!$root || !$count || array_filter(libxml_get_errors(),static fn($e)=>$e->level>=LIBXML_ERR_ERROR)) { throw new BridgeException('Datafile XML incomplet, vide ou mal formé. Catalogue précédent conservé.'); }
        } finally { $reader->close();libxml_clear_errors();libxml_use_internal_errors($previous); }
    }
    private function csv(string $file,string $encoding): \Generator
    {
        $stream=fopen($file,'rb');$count=0;
        try {
            $first=fgets($stream,65536);
            if ($first===false || !str_contains($first,'Artikel')) { throw new BridgeException('En-têtes officiels Datafile CSV absents.'); }
            $delimiter=';';$best=0;
            foreach ([';',"\t",','] as $candidate) { $n=count(str_getcsv($first,$candidate,'"',''));if($n>$best){$best=$n;$delimiter=$candidate;} }
            rewind($stream);$header=fgetcsv($stream,65536,$delimiter,'"','');
            $header=array_map(static fn($v)=>trim(preg_replace('/^\xEF\xBB\xBF/','',(string)$v)), $header);
            foreach (['Artikel','Fabrikantscode','Merk','Omschrijving','Prijs','Voorraad','Productindeling','Status'] as $key) { if(count(array_keys($header,$key,true))!==1){throw new BridgeException('Colonne Datafile absente ou dupliquée : '.$key);} }
            $dateColumn=array_search('Datum aanmaken:',$header,true);$width=$dateColumn===false?count($header):$dateColumn;
            while (($row=fgetcsv($stream,1048576,$delimiter,'"',''))!==false) {
                if ($row===[null]) { continue; }
                if(count($row)!==$width){throw new BridgeException('Nombre de colonnes Datafile CSV incohérent.');}
                if (++$count>1000000) { throw new BridgeException('Datafile limité à un million de références.'); }
                // Copaco's creation-date columns occur only in the first line.
                $get=static function(string $key)use($header,$row,$encoding):string{$i=array_search($key,$header,true);$v=$i===false?'':(string)($row[$i]??'');return $encoding==='UTF-8'?$v:mb_convert_encoding($v,'UTF-8',$encoding);};
                yield $this->normalize(['part'=>$get('Artikel'),'mpn'=>$get('Fabrikantscode'),'brand'=>$get('Merk'),'name'=>$get('Omschrijving'),'cost'=>$get('Prijs'),'currency'=>'EUR','stock'=>$get('Voorraad'),'category'=>$get('Productindeling'),'ean'=>$get('EAN_code'),'status'=>$get('Status'),'inclusive'=>$get('Prijs_incl_heffingen')]);
            }
            if (!$count) { throw new BridgeException('Datafile CSV vide.'); }
        } finally { fclose($stream); }
    }
    private function normalize(array $r): array
    {
        $r=array_map('trim',$r);$cost=str_replace(',','.',$r['cost']);$inclusive=str_replace(',','.',$r['inclusive']);
        if (!mb_check_encoding(implode('',$r),'UTF-8') || $r['part']==='' || strlen($r['part'])>100 || preg_match('/[\x00-\x1f]/',$r['part']) || $r['name']==='' || strlen($r['name'])>200000 || mb_strlen($r['brand'])>255 || mb_strlen($r['mpn'])>255
            || !preg_match('/^\d+(?:\.\d{1,6})?$/D',$cost) || (float)$cost>100000000 || !preg_match('/^\d{1,9}$/D',$r['stock']) || (int)$r['stock']>100000000 || $r['currency']!=='EUR'
            || strlen($r['category'])>100 || !preg_match('/^\d{2}$/D',$r['status'])
            || ($inclusive!=='' && (!preg_match('/^\d+(?:\.\d{1,6})?$/D',$inclusive) || (float)$inclusive>100000000 || (float)$inclusive<(float)$cost))) { throw new BridgeException('Article Datafile invalide : identité, prix, devise, stock, EAN ou statut. Aucune publication partielle.'); }
        $invalidEan=$r['ean']!=='' && !preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D',$r['ean']);
        return ['eanInvalid'=>(bool)$invalidEan,'partNumber'=>$r['part'],'name'=>mb_substr($r['name'],0,255),'description'=>$r['name'],'manufacturer'=>$r['brand']?:null,'manufacturerNumber'=>$r['mpn']?:null,'ean'=>$invalidEan?null:($r['ean']?:null),'cost'=>(float)$cost,'currency'=>'EUR','stock'=>(int)$r['stock'],'class'=>$r['category'],'status'=>$r['status'],'costInclusive'=>$inclusive===''?null:(float)$inclusive];
    }
}
