<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueCriteria;
use TDBridge\Domain\CatalogueSearch;
use TDBridge\Domain\ProductMapper;

/** One provider page per call. No catalogue writes, index build or background work. */
final class CatalogueBrowser
{
    public function __construct(private readonly Connection $db, private readonly Settings $settings, private readonly TdClient $client, private readonly ProductMapper $mapper) {}

    public function search(array $input): array
    {
        CatalogueSearch::query($input); // Share validation with the previous advanced filter format.
        $filters = [];
        foreach (['text', 'brands', 'classes', 'subclasses'] as $key) { $filters[$key] = CatalogueSearch::terms($input[$key] ?? ''); }
        foreach (['onlyInStock', 'hasPrice', 'notImported'] as $key) { $filters[$key] = $input[$key] ?? false; }
        foreach (['minCost', 'maxCost', 'minStock', 'productStatusCode'] as $key) { $filters[$key] = $input[$key] ?? ''; }
        $fingerprint = hash('sha256', json_encode($filters, JSON_THROW_ON_ERROR));
        $brands = $filters['brands'] ?: [''];
        $state = $this->cursor($input['scanCursor'] ?? null, $fingerprint, count($brands));
        if (!in_array(false, $state['done'], true)) { return ['items' => [], 'scanCursor' => $state, 'hasMore' => false, 'scanned' => $state['scanned'], 'total' => null]; }
        $position = $state['turn'];
        while ($state['done'][$position]) { $position = ($position + 1) % count($brands); }
        $page = $state['pages'][$position];
        $criteria = ['page' => $page, 'pageSize' => 100, 'includeStock' => true, 'includePrice' => true];
        if ($brands[$position] !== '') { $criteria['manufacturer'] = $brands[$position]; }
        if ($filters['productStatusCode'] !== '') { $criteria['productStatusCode'] = $filters['productStatusCode']; }
        $response = $this->client->catalogue($criteria);
        $result = $this->mapper->catalogue($response, $this->settings->all()['mapping']);
        $rows = $result['items'];
        $size = isset($response['pageSize']) && is_numeric($response['pageSize']) && (int) $response['pageSize'] > 0 && (int) $response['pageSize'] <= 100 ? (int) $response['pageSize'] : 100;
        if (!$rows && $result['total'] !== null && ($page - 1) * $size < $result['total']) { throw new BridgeException('Le fournisseur retourne une page vide avant la fin annoncée. Réessayez ou affinez les marques.', 422); }
        $state['done'][$position] = $result['total'] !== null ? $page * $size >= $result['total'] : count($rows) < $size;
        $state['pages'][$position] = $page + 1;
        $state['turn'] = ($position + 1) % count($brands);
        $state['scanned'] += count($rows);
        $alreadyImported = [];
        if ($filters['notImported'] && $rows) {
            $alreadyImported = $this->db->fetchFirstColumn('SELECT part_number FROM td_bridge_product WHERE part_number IN (' . implode(',', array_fill(0, count($rows), '?')) . ')', array_column($rows, 'partNumber'));
        }
        $items = array_values(array_filter($rows, static fn (array $item): bool => self::matches($item, $filters) && !in_array($item['partNumber'], $alreadyImported, true)));
        return ['items' => $items, 'scanCursor' => $state, 'hasMore' => in_array(false, $state['done'], true), 'scanned' => $state['scanned'], 'total' => null, 'source' => 'supplier'];
    }

    public static function matches(array $item, array $filters): bool
    {
        $normalise = static function (string $text): string {
            $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
            return mb_strtolower($ascii === false ? $text : $ascii);
        };
        foreach (['brands' => 'manufacturer', 'classes' => 'class', 'subclasses' => 'subclass'] as $filter => $field) {
            $values = $filters[$filter] ?? [];
            if ($values && !in_array($normalise((string) ($item[$field] ?? '')), array_map($normalise, $values), true)) { return false; }
        }
        if ($filters['text'] ?? []) {
            $text = $normalise(implode(' ', array_map(static fn ($v) => (string) $v, array_intersect_key($item, array_flip(['partNumber', 'name', 'description', 'manufacturerNumber', 'manufacturer', 'ean'])))));
            if (!array_filter($filters['text'], static fn (string $term): bool => str_contains($text, $normalise($term)))) { return false; }
        }
        if (($filters['onlyInStock'] ?? false) && ($item['stock'] === null || $item['stock'] <= 0)) { return false; }
        if (($filters['hasPrice'] ?? false) && ($item['cost'] === null || $item['cost'] <= 0)) { return false; }
        foreach (['minCost' => ['cost', true], 'maxCost' => ['cost', false], 'minStock' => ['stock', true]] as $key => [$field, $minimum]) {
            $value = $filters[$key] ?? '';
            if ($value !== '' && $value !== null && ($item[$field] === null || ($minimum ? $item[$field] < (float) $value : $item[$field] > (float) $value))) { return false; }
        }
        return empty($filters['productStatusCode']) || ($item['status'] ?? null) === $filters['productStatusCode'];
    }

    private function cursor(mixed $cursor, string $fingerprint, int $count): array
    {
        if ($cursor === null) { return ['fingerprint' => $fingerprint, 'pages' => array_fill(0, $count, 1), 'done' => array_fill(0, $count, false), 'turn' => 0, 'scanned' => 0]; }
        if (!is_array($cursor) || ($cursor['fingerprint'] ?? '') !== $fingerprint || !isset($cursor['pages'], $cursor['done'], $cursor['turn'], $cursor['scanned']) || !is_array($cursor['pages']) || !array_is_list($cursor['pages']) || count($cursor['pages']) !== $count || !is_array($cursor['done']) || !array_is_list($cursor['done']) || count($cursor['done']) !== $count) { throw new BridgeException('La recherche a changé. Relancez-la depuis le début.'); }
        foreach ($cursor['pages'] as $page) { CatalogueCriteria::integer($page, 1, 100001); }
        foreach ($cursor['done'] as $done) { if (!is_bool($done)) { throw new BridgeException('Curseur de recherche invalide.'); } }
        $cursor['turn'] = CatalogueCriteria::integer($cursor['turn'], 0, $count - 1);
        $cursor['scanned'] = CatalogueCriteria::integer($cursor['scanned'], 0, 100000000);
        return $cursor;
    }
}
