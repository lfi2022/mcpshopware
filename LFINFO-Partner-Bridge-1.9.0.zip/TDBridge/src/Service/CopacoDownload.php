<?php declare(strict_types=1);

namespace TDBridge\Service;

/** Interface permits offline transport tests; downloaded files are always temporary. */
interface CopacoDownload
{
    /** @return array{path:string,modified:int} */
    public function download(array $config,string $password): array;
}
