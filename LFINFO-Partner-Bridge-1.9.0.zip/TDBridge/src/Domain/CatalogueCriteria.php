<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class CatalogueCriteria
{
    public static function build(array $input): array
    {
        $result = ['page' => self::integer($input['page'] ?? 1, 1, 100000), 'pageSize' => self::integer($input['pageSize'] ?? 50, 1, 100)];
        $filters = 0;
        foreach (['tdsynnexPartNumber', 'manufPartNumber', 'upcEan', 'customerPartNumber'] as $key) {
            $value = $input[$key] ?? null;
            if ($value === null || $value === '' || $value === []) { continue; }
            if (!is_array($value) || count($value) > 50) { throw new BridgeException("$key : fournissez de 1 à 50 références exactes."); }
            $value = array_values(array_unique(array_map(static function ($item): string {
                if (!is_string($item) || trim($item) === '' || strlen($item) > 100) { throw new BridgeException('Référence invalide.'); }
                return trim($item);
            }, $value)));
            $result[$key] = $value;
            ++$filters;
        }
        foreach (['manufacturer', 'class', 'subclass'] as $key) {
            if (isset($input[$key]) && $input[$key] !== '') {
                if (!is_string($input[$key]) || strlen($input[$key]) > 200) { throw new BridgeException('Filtre invalide.'); }
                $result[$key] = trim($input[$key]);
                ++$filters;
            }
        }
        // The supplied documentation is contradictory about manufacturer + class.
        // Enforce its explicit one-non-null-search-parameter rule until confirmed by TD SYNNEX.
        if ($filters > 1) { throw new BridgeException('Un seul critère de recherche est autorisé par requête TD SYNNEX.'); }
        foreach (['includeStock', 'onlyInStock', 'includePrice', 'includePricePerQuantity', 'includeOutlet', 'includeEndUserPrice'] as $key) {
            if (isset($input[$key]) && !is_bool($input[$key])) { throw new BridgeException("$key doit être un booléen."); }
            $value = $input[$key] ?? in_array($key, ['includeStock', 'includePrice'], true);
            // False is the documented default: omit inactive optional flags from the wire request.
            if ($value || in_array($key, ['includeStock', 'includePrice'], true)) { $result[$key] = $value; }
        }
        foreach (['modifiedFrom', 'modifiedTo', 'createdFrom', 'createdTo', 'eolDateFrom', 'eolDateTo'] as $key) {
            if (!empty($input[$key])) { $result[$key] = self::date($input[$key]); }
        }
        if (!empty($input['productStatusCode'])) {
            if (!in_array($input['productStatusCode'], ['Active', 'Allocated', 'Discontinued', 'PhasedOut'], true)) { throw new BridgeException('Statut produit invalide.'); }
            $result['productStatusCode'] = $input['productStatusCode'];
        }
        return $result;
    }

    public static function integer(mixed $value, int $min, int $max): int
    {
        if (filter_var($value, FILTER_VALIDATE_INT) === false || (int) $value < $min || (int) $value > $max) {
            throw new BridgeException("Valeur entière attendue entre $min et $max.");
        }
        return (int) $value;
    }

    public static function date(mixed $value): string
    {
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z?)?$/D', $value)) { throw new BridgeException('Date ISO attendue (AAAA-MM-JJ ou horodatage ISO).'); }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', substr($value, 0, 10));
        if (!$date || $date->format('Y-m-d') !== substr($value, 0, 10) || (strlen($value) > 10 && (int) substr($value, 11, 2) > 23) || (strlen($value) > 10 && ((int) substr($value, 14, 2) > 59 || (int) substr($value, 17, 2) > 59))) { throw new BridgeException('Date invalide.'); }
        return $value;
    }
}
