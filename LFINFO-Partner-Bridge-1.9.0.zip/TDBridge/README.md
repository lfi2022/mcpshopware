# LFINFO Partner Bridge pour Shopware 6

Plugin PHP natif destiné à **Shopware 6.7.15.1**, avec module de gestion intégré à l’administration. Le ZIP de livraison contient les fichiers JavaScript et CSS déjà compilés et le manifeste Vite attendu par Shopware 6.7.

![Aperçu du module, données fictives](docs/assets/apercu.png)

## Version 1.9.0 — interface multi-fournisseurs

**Fournisseurs** regroupe les accès TD SYNNEX, le FTP/FTPS Copaco et l'API Ingram Micro. **Catalogue** propose un sélecteur de source, dont **Tous les fournisseurs** pour une recherche globale. **Paramètres** conserve les règles communes de création, de prix, de synchronisation et Open Icecat.

La recherche globale interroge les API TD et Ingram et le Datafile Copaco publié. Texte, marques séparées par `;`, coût et stock sont communs ; les catégories gardent leurs codes propres à chaque fournisseur. Les filtres avancés sont dépliables. Chaque source conserve ses résultats, sa pagination et ses confirmations d'import ; une erreur de connexion n'empêche pas les autres résultats. Les filtres prix/stock Ingram s'appliquent à la page consultée et le parcours TD est progressif. Aucun total global exhaustif n'est annoncé.

Voir le [guide de navigation](docs/INTERFACE.md) et les [commandes de mise à jour](docs/SUPPLIERS.md). L'archive contient les fichiers d'administration compilés ; recharger avec Ctrl+Maj+R après installation.

## Version 1.8.0 — Ingram Micro Belgique

Nouvel onglet **Ingram Micro**, configuration des accès revendeur dans les paramètres, recherche API v6 combinée et prix/disponibilités relus par lots de 50. Imports sélectionnés, liaison aux produits existants, achat natif avec forfait de 50 € HT, synchronisation globale et Icecat sans photo couvrent maintenant les trois fournisseurs.

Le sandbox est réservé à la lecture. Les changements de compte sont protégés par une empreinte de source ; les données ne sont pas remplacées par un autre compte sans vérification des liaisons. Le total de recherche reste celui de l'API : les filtres prix/stock sont appliqués sur chaque page reçue. La connexion réelle reste à tester avec l'application Ingram du revendeur.

Voir [docs/INGRAM.md](docs/INGRAM.md). Copaco conserve son onglet, les paramètres FTP et le déclenchement quotidien à minuit Europe/Brussels.

## Version 1.7.0 — LFINFO Partner Bridge

Le nom du module et de l'extension devient **LFINFO Partner Bridge**. L'identité technique reste TDBridge pour mettre à jour l'installation existante. L'onglet **Copaco** regroupe le catalogue, les filtres, les imports et le suivi FTP. Les identifiants et l'activation quotidienne sont dans **Paramètres → Copaco — paramètres FTP**.

La récupération automatique démarre au premier passage du worker à partir de **00:00 Europe/Brussels**, avec une réussite par jour civil local, sans doublon au changement d'heure. Le worker doit rester actif lorsque l'administration est fermée. Un échec préserve l'ancien catalogue et peut être repris après une heure ; un passage manqué peut être rattrapé au retour du worker. À minuit, le fichier disponible peut dater de la veille si Copaco génère le nouveau catalogue plus tard. Aucune nouvelle fiche boutique n'est créée par le seul téléchargement.

## Version 1.6.1 — format réel Copaco

Le lecteur reconnaît aussi les balises et attributs en minuscules réellement livrés par Copaco. Les EAN non standard sont ignorés avec un compteur d'avertissements, sans rejeter les articles ni modifier leurs références fournisseur/fabricant. Les autres contrôles de prix, stock, doublon et intégrité XML restent obligatoires. Les fichiers revendeur privés sont exclus du ZIP et du suivi Git.

## Version 1.6.0 — Datafile Copaco officiel

La connexion au Datafile XML/CSV Copaco est implémentée via FTP ou FTPS explicite, avec configuration chiffrée, demande de chargement et actualisation quotidienne optionnelle après 04 h. Publication atomique, descriptions longues, prix avec taxes séparé, codes catégorie, filtre et contrôle de fraîcheur du fichier distant. L'ATP interactif n'est jamais utilisé pour la synchronisation automatique.

L'accès revendeur utilisateur est en attente d'activation ; le transport réel reste à valider. Voir [docs/COPACO.md](docs/COPACO.md) pour la configuration et les limites. SFTP, FTPS implicite et ZIP non pris en charge.

## Version 1.5.0 — fournisseurs et produits Shopware

Le nom affiché est **LFINFO Supplier Bridge**. L'identité technique reste `TDBridge` (dossier, commandes, configuration et routes) pour mettre à jour l'installation existante et conserver l'historique. Ne pas installer une seconde extension ni désinstaller l'ancienne.

- **Mes produits** regroupe les liaisons TD SYNNEX et Copaco ; les actions ciblent le fournisseur affiché.
- **Fournisseurs & liaisons** permet de choisir un produit Shopware existant, sa référence fournisseur et sa source de synchronisation. Aucune fusion automatique par nom/EAN. Activer une source met en pause les autres offres du produit.
- Supprimer le produit live Shopware retire la liaison TD et délie les offres des autres fournisseurs. Les tâches déjà en attente ne le recréent pas. Les offres du catalogue et le journal restent consultables. Le nettoyage manuel et le worker rattrapent les associations orphelines.
- **Copaco : flux CSV manuel**, UTF-8, mapping explicite, aperçu puis enregistrement ; sélection d'un article à créer ou liaison à une fiche existante. Aucun appel à une API Copaco non documentée. Les synchronisations relisent ce cache, limité à 24 h de fraîcheur ; rechargez un export récent pour actualiser les données. Le Datafile officiel est pris en charge depuis la version 1.6.0 ; voir le guide Copaco.
- **TD SYNNEX : API réelle conservée**, recherche combinée, cache des marques, import et synchronisation. **Ingram Micro : prévu, aucun connecteur actif**.
- Synchronisation globale et Icecat sans photo couvrent les sources actives des deux fournisseurs. Le coût d'achat natif conserve le supplément de **50 € HT**, sans effet sur la base du prix de vente.

Le détail du flux, de la migration et des limites se trouve dans [docs/SUPPLIERS.md](docs/SUPPLIERS.md). Le périmètre reste l'administration de cette extension ; aucun écran client ajouté.

## Correction 1.4.3

Une migration élargit le statut des tâches de 20 à 32 caractères : le statut `completed_with_errors` (21 caractères) provoquait SQLSTATE 22001 après une erreur produit, dont les refus Icecat. Les tâches et journaux sont conservés. Lancer `plugin:update TDBridge` pour appliquer cette migration, puis redémarrer les workers. Le diagnostic en lecture seule affiche désormais `jobSchema.statusType` et `terminalStatusFits`.

Les erreurs Icecat affichent le `StatusCode` numérique stable du fournisseur et un conseil adapté, sans exposer son message brut ni les jetons. La correction SQL ne donne pas de droits supplémentaires sur les fiches Icecat : tester la référence dans l’aperçu pour connaître le code exact.

## Correction 1.4.2

L’arrêt du pool par Ctrl+C laisse les enfants terminer leur lot. Les sorties attendues lors d’une interruption ne deviennent plus une erreur générique du pool. Une erreur réelle reste signalée et son diagnostic est conservé côté serveur. Voir [WORKERS.md](docs/WORKERS.md).

## Nouveautés 1.4.1

Le **prix d’achat natif HT** est désormais le coût TD SYNNEX HT **+ 50 € HT par produit**, pour intégrer le forfait environnement/transport demandé. Le TTC applique la TVA du produit à ce total. Ce forfait ne modifie pas le calcul du prix de vente ni le coût fournisseur brut conservé par le bridge. Chaque synchronisation recalcule depuis le coût TD : aucun cumul. Les prix absents ou nuls restent refusés, et le forfait EUR nécessite des prix fournisseur EUR.

La commande serveur accepte maintenant `php bin/console tdbridge:worker --max-workers=4 --seconds=3600` : elle enregistre la limite globale (1 à 8) puis lance le coordinateur. Voir [WORKERS.md](docs/WORKERS.md).

## Nouveautés 1.4.0

Dans **Mes produits**, les deux boutons groupés sont maintenant visibles au-dessus du filtre : **Tout synchroniser maintenant** et **Enrichir Icecat — produits sans photo**. Le second ne cible que les références liées actives sans image, avec recontrôle au traitement. Les images sont activées pour cette campagne.

Le worker traite jusqu’à 50 références TD par appel, conserve une reprise par produit et autorise plusieurs tâches en parallèle. Un pool CLI crée automatiquement les processus nécessaires selon la file, avec une limite de 2 par défaut (1 à 8 configurable) et une pause commune sur HTTP 429. Voir [activation et fonctionnement des workers](docs/WORKERS.md). Aucun service distant n’est installé automatiquement depuis l’administration.

![Actions groupées dans Mes produits, données fictives](docs/assets/mes-produits-bulk.png)

## Prix d’achat natif — 1.3.1

Depuis 1.3.2, **Mes produits** et **Imports** proposent **Tout synchroniser maintenant** : la confirmation affiche le nombre de produits liés dont le suivi est actif et les réglages prix/stock/contenu enregistrés. L’action couvre toutes les pages, indépendamment du filtre affiché, et respecte les produits en pause. Les tâches sont traitées par le worker ; aucune nouvelle référence du catalogue n’est importée. Une synchronisation déjà en attente ou en cours doit se terminer avant une nouvelle demande globale. Depuis 1.4, la capacité de la file est de 1 000 tâches actives et les synchronisations groupées utilisent 50 références par tâche ; une capacité insuffisante refuse toute l’opération sans ajouter de lots partiels.

Depuis 1.4.1, le champ natif **Prix d’achat** reçoit `price.customerPrice` TD SYNNEX + 50 € HT par produit, avec TTC calculé selon la TVA du produit. Il est renseigné à chaque création et actualisé avec **Prix de vente et d’achat** lors des synchronisations. Les prix d’achat dans les autres devises sont conservés. Un prix absent, nul ou dans une devise différente bloque la mise à jour au lieu d’écraser le coût existant.

Pour compléter les produits déjà importés, mettre à jour le plugin, activer **Prix de vente et d’achat**, enregistrer puis relancer leur synchronisation depuis **Mes produits**. Les tâches déjà en attente conservent les options enregistrées lors de leur création.

## Nouveautés 1.3.0

- Catalogue fournisseur persistant par marques (`Lenovo;HP`) ou complet si autorisé par TD SYNNEX, avec confirmation, progression, pause et reprise.
- Recherche SQL sur toutes les références chargées, y compris non importées : texte, marques, classes, sous-classes, prix, stock et statut. Comptages de la structure fournisseur.
- Open Icecat intégré : aperçu, descriptions, caractéristiques dans la description et jusqu’à huit images hébergées localement. Jetons chiffrés, activation explicite, enrichissement à l’import ou sur un produit déjà lié. Voir [configuration Icecat](docs/ICECAT.md).
- Toute la gestion reste dans TD Bridge. Aucun composant global de Shopware ni thème client n’est modifié.

## Fonctionnalités

- Authentification OAuth client credentials, cache du jeton, renouvellement après HTTP 401 et test de connexion.
- Recherche catalogue V2 par fabricant, référence TD, référence constructeur, EAN/UPC, référence revendeur, classe ou sous-classe.
- Filtres de stock, statut, dates de création/modification et fin de vie ; pagination jusqu’à 100 résultats par page.
- Sélection de références conservée entre les pages, fiche d’aperçu et confirmation avant création de la tâche ; jusqu’à 500 références par tâche.
- Import Shopware avec SKU préfixé, nom, description en texte, fabricant, référence fabricant, EAN valide, stock, prix de vente et prix d’achat natif, TVA, catégorie et visibilité sur un canal de vente.
- Majoration sur coût HT, supplément fixe, réserve de stock, brouillon par défaut et vérification de la devise.
- Synchronisation automatique des produits liés, activation/suspension par référence, choix des stocks, prix et contenus à mettre à jour.
- File persistante, lots de 50 produits (un produit avec Icecat), progression, reprise après interruption, annulation des tâches en attente et relance des tâches en erreur.
- Consultation des commandes et factures fournisseur, filtres documentés, détails JSON et export.
- Tableau de bord, journaux avec recherche et export CSV de la page, purge de l’historique configurable.
- Permissions serveur et administration distinctes pour consulter, importer, configurer et lire les documents fournisseur.

## Installation

1. Décompresser `dist/LFINFO-Partner-Bridge-1.8.0.zip` dans `custom/plugins/` à la racine de Shopware. Le fichier doit se trouver dans `custom/plugins/TDBridge/composer.json`.
2. Exécuter depuis la racine de Shopware :

```bash
bin/console plugin:refresh
bin/console plugin:install --activate TDBridge
bin/console assets:install
bin/console cache:clear
bin/console scheduled-task:register
```

3. Recharger l’administration et ouvrir **Catalogues → TD SYNNEX Bridge**.
4. Renseigner les paramètres, enregistrer puis tester l’authentification. Choisir la TVA, la devise principale de la boutique et son code ISO avant l’import.
5. Cliquer sur **Voir un produit JSON**, adapter le mapping aux véritables réponses de votre compte, puis lancer une recherche et un import de quelques références en brouillon.

Le serveur doit exécuter PHP avec Sodium et les extensions requises par Shopware. `APP_SECRET` doit être stable : il sert au chiffrement des identifiants. Les postes d’administration ne contactent pas directement TD SYNNEX.

## Recherche fournisseur dans l’onglet TD SYNNEX Bridge

Dans **Catalogue → Recherche et filtres fournisseur**, saisir les marques, choisir une catégorie fournisseur et combiner si nécessaire texte, prix, stock et statut. Exemple : **Marques = Lenovo ; HP**, **Catégorie = Ordinateurs portables**, prix maximum `900`. Le texte peut rester vide.

Les alternatives d’un même champ sont séparées par `;` (« OU »). Les différents champs sont combinés (« ET »). Les catégories sont les types TD SYNNEX : portables `COMPORT`, PC de bureau `COMDESK`, écrans `PERMONIT`. Choisir ces filtres ne crée et ne modifie aucune catégorie Shopware. Le texte recherche les noms, descriptions, références et EAN par sous-chaîne, sans correction orthographique automatique.

La recherche lit directement les pages du fournisseur pour les marques demandées. Elle n’exige aucune construction d’index et ne dépend pas d’une marque préchargée. Pour respecter le contrat API documenté, chaque appel fournisseur porte sur une marque ; les autres filtres sont appliqués aux références retournées. Les marques sont parcourues à tour de rôle, avec un curseur de continuation propre à la recherche.

Les résultats et la sélection restent dans l’écran Bridge. La recherche n’écrit ni produit, ni catégorie, ni stock, ni prix, ni tâche d’import ou index du catalogue. L’authentification conserve uniquement son cache de jeton habituel. Aucun traitement d’alimentation du catalogue ne continue en arrière-plan après une recherche.

Le nombre de références consultées et celui des correspondances retenues sont affichés. Une recherche partielle est explicitement signalée ; **Chercher plus de résultats** consulte les pages suivantes. Chaque action lit au maximum quatre pages fournisseur et conserve jusqu’à 1 000 correspondances dans l’écran ; au-delà, affiner les critères. Le bouton d’arrêt interrompt la poursuite après la requête en cours. Les résultats partiels ne représentent pas le total du catalogue fournisseur.

Cocher uniquement les références souhaitées, cliquer **Préparer l’import**, vérifier la sélection et confirmer **Créer la tâche d’import**. C’est cette action explicite, séparée de la recherche, qui autorise la création des produits sélectionnés selon les paramètres enregistrés.

Le mode **Références exactes / API** conserve les recherches par références TD, constructeur et EAN. Le mode fournisseur est destiné aux combinaisons marque + catégorie + autres filtres.

![Recherche fournisseur dans TD SYNNEX Bridge, données fictives](docs/assets/recherche-fournisseur.png)

### Mise à jour depuis les versions avec index

Après copie de la version 1.8.0, exécuter les commandes de mise à jour habituelles :

```bash
bin/console plugin:refresh
bin/console plugin:update TDBridge
bin/console assets:install
bin/console cache:clear
```

Les anciens workers CLI doivent charger le nouveau code via leur superviseur. La tâche d’indexation traite désormais uniquement les nouveaux périmètres explicitement démarrés. Les anciennes actions `catalogue-index/{action}` restent refusées. L’ancien cache interne au plugin est conservé sans être alimenté ou supprimé ; il ne sert plus à la recherche. La version 1.3 crée deux nouvelles tables `td_bridge_scope` et `td_bridge_supplier`. Elle ne reprend jamais les anciens chargements : le démarrage est explicite dans le module. La tâche planifiée alimente uniquement ces nouveaux périmètres.

## Connexion européenne et mapping

L’URL de base du catalogue est préremplie avec `https://api.tdsynnex.com/eu`. L’URL OAuth est **indépendante et configurable**. L’URL `https://api.tdsynnex.com/eu/auth/token` et l’encodage formulaire ont été confirmés par le test utilisateur du 25 octobre 2026. L’authentification ne garantit pas à elle seule la validité des paramètres du catalogue ou les droits sur chaque ressource.

Le mapping par défaut correspond maintenant au JSON catalogue réellement obtenu par le test utilisateur du 25 octobre 2026. Le plugin refuse un schéma inconnu, une référence absente, un stock non numérique ou un prix absent, nul ou dans une autre devise lorsqu’il doit être écrit. Des articles discontinués peuvent ne comporter aucun objet `price` ou `stock` ; leurs valeurs restent absentes et ne deviennent jamais implicitement zéro.

```json
{
  "items": "data",
  "total": "totalResults",
  "partNumber": "tdsynnexPartNumber",
  "name": "productDescription",
  "description": "productDescription",
  "manufacturer": "manufacturer",
  "manufacturerNumber": "manufPartNumber",
  "ean": "upcEan",
  "stock": "stock.quantityAvailableTotal",
  "cost": "price.customerPrice",
  "currency": "price.currencyCode"
}
```

Exemple : si la liste se trouve dans `data.items` et le coût dans `pricing.customerPrice`, modifier ces deux chemins. Les indices de tableau sont possibles (`stock.0.available`). `items` peut être vide si la réponse est une liste à la racine. `total` absent laisse la navigation fonctionner en fonction de la taille de la page.

La documentation est contradictoire sur le cumul fabricant/classe : elle impose un seul critère non nul tout en mentionnant ce cumul. Le plugin applique la règle stricte d’un seul critère jusqu’à confirmation fournisseur. Les valeurs de classe et sous-classe se saisissent librement car les listes fournies sont tronquées.

## Traitements automatiques

Utiliser les workers Shopware habituels, par exemple sous Supervisor/systemd :

```bash
bin/console scheduled-task:run --time-limit=60
bin/console messenger:consume async low_priority --time-limit=60 --memory-limit=256M
```

Les noms de transports doivent correspondre à la configuration Messenger de votre boutique. La tâche `td_bridge.process` se déclenche toutes les 60 secondes. Chaque passage traite au maximum dix références, ou programme une synchronisation des références arrivées à échéance. L’intervalle configuré est un objectif, dépendant de la file et des workers. Pour accélérer une file, vous pouvez exécuter :

```bash
bin/console tdbridge:process --batches=20
```

Autre possibilité : planifier cette commande chaque minute via cron. Le verrou MySQL empêche deux traitements concurrents du bridge. Le bouton **Traiter un lot** permet un dépannage ponctuel depuis l’administration.

Les erreurs transitoires et HTTP 429 font l’objet de cinq tentatives au maximum, avec délai progressif et respect de `Retry-After` (plafonné à 24 h). Une tâche interrompue reprend après 30 minutes ; un lot peut être rejoué, les liaisons étant idempotentes. Les erreurs propres à un produit ne bloquent pas les autres produits. Une relance manuelle recommence la tâche entière avec ses réglages d’origine.

## Règles de données

La formule est `vente HT = coût HT × (1 + majoration / 100) + supplément fixe`. Il s’agit d’une majoration sur coût, pas d’un taux de marge sur prix de vente. Le TTC est calculé avec la TVA du produit. La devise fournisseur doit correspondre à la devise principale Shopware ; aucune conversion de change n’est effectuée. Les autres prix en devises sont conservés.

La source du coût est `price.customerPrice`, et non le tarif catalogue `listPrice`. Les champs `governmentFees`, `govFeesRecycling` et `govFeesCopyright` sont présents séparément dans la réponse observée : ils ne sont pas additionnés automatiquement, car leur inclusion éventuelle dans le prix et leur relation entre eux restent à confirmer avec TD SYNNEX. Le stock retenu est `quantityAvailableTotal` ; le stock local et les arrivages ne lui sont pas additionnés.

En mise à jour depuis 1.0.0, le mapping provisoire est remplacé uniquement s’il correspond exactement à celui livré initialement. Les mappings personnalisés sont conservés. Annuler et recréer les anciennes tâches encore en attente si elles utilisent le mapping provisoire, car leurs options sont figées à leur création. Après copie des fichiers, exécuter `bin/console plugin:refresh`, `bin/console plugin:update TDBridge`, `bin/console assets:install` et `bin/console cache:clear`.

Catégorie, canal, TVA initiale, préfixe et activation sont appliqués à la création. Pour un produit déjà lié, la TVA existante est conservée et les options de synchronisation déterminent les champs actualisés. Une catégorie existante ou un canal déjà affecté n’est pas remplacé. Les prix avancés/règles tarifaires Shopware ne sont pas modifiés. Le coût fournisseur est conservé dans la liaison du bridge.

Un SKU existant sans liaison est refusé ; le plugin ne rapproche pas automatiquement les articles par EAN. Une référence introuvable côté TD SYNNEX conserve son dernier état Shopware et produit une erreur. Un produit Shopware supprimé doit être examiné avant réimport. La désinstallation conserve les liaisons, l’historique et les produits ; elle ne supprime aucun article du magasin.

## Périmètre et recette restant à effectuer

Le code, le ZIP et les assets compilés sont livrés. Les tests automatisés couvrent la validation, le mapping, les calculs, le chiffrement, les échanges HTTP simulés et le parcours de l’interface sur données fictives. Les appels authentifiés effectués par l’utilisateur ont confirmé OAuth, une réponse catalogue et les enveloppes des commandes/factures. **L’installation et les écritures DAL n’ont pas été exécutées dans une boutique Shopware réelle.** Suivre la [recette de connexion et d’import](docs/RECETTE.md) avant production.

La documentation expose la lecture des commandes et des factures, sans endpoint pour passer une commande. Le plugin ne transmet donc aucune commande client à TD SYNNEX. Les médias, PDF, traductions multilingues, variantes, caractéristiques techniques et tarifs dégressifs ne sont pas importés : leurs schémas et sources ne sont pas fournis. Les drapeaux catalogue correspondants peuvent être interrogés et les chemins du mapping adaptés à un prix de base confirmé.

## Développement et aperçu

```bash
npm ci
npm run preview
```

Ouvrir `http://127.0.0.1:5173`. Cet aperçu monte **le véritable composant du module** avec des services Shopware simulés. Toutes les données et opérations sont fictives. Aucune boutique ni API fournisseur n’est modifiée.

```bash
composer install --working-dir=tests/runtime
# Les tests de filtres SQL utilisent l’extension PHP pdo_sqlite.
php tests/run.php
npm run test:admin
npx playwright install chromium
npm run test:e2e
npm run build
npm run package
```

La compilation locale produit les assets et le manifeste Vite. Une compilation habituelle de l’administration Shopware peut également partir des sources du plugin. L’archive ne contient ni identifiants, ni dépendances de développement, ni démonstration, ni outils PHP locaux.

Architecture : `src/Domain` pour la validation, les filtres et le mapping, `src/Service` pour OAuth/import/file/recherche, `src/Controller` pour les actions administrateur, `src/ScheduledTask` pour les traitements périodiques, `src/Resources/app/administration` pour l’interface.

## Diagnostic des imports et Icecat

La version 1.1.0 corrige les appels de génération UUID des nouveaux produits/fabricants pour Shopware 6.7.15.1. Après mise à jour, relancer une tâche échouée depuis **Imports** et consulter son **Journal**. Les validations DAL indiquent désormais le champ et le code refusés. Les anciennes tâches avec le mapping provisoire de 1.0.0 sont migrées lors de leur reprise ; les mappings personnalisés restent conservés.

Depuis 1.1.1, `bin/console tdbridge:diagnose --part=10201179` produit un rapport ciblé en lecture seule. Il affiche les versions source/installée, la présence de la colonne `processed`, les références de configuration, les dernières erreurs et la présence des champs catalogue nécessaires à l’import. Il n’affiche pas les identifiants, le jeton ou la réponse brute et n’écrit aucun produit. Les workers CLI déjà lancés doivent être redémarrés via leur superviseur après mise à jour afin de charger le nouveau code.

Open Icecat est maintenant intégré directement. La [notice Icecat](docs/ICECAT.md) décrit la configuration et les limites de couverture. Le service commercial externe n’est ni requis ni installé.

Références Shopware utilisées : [modules d’administration](https://developer.shopware.com/docs/guides/plugins/plugins/administration/module-component-management/add-custom-module.html), [permissions](https://developer.shopware.com/docs/guides/plugins/plugins/administration/permissions-error-handling/add-acl-rules.html), [tâches planifiées](https://developer.shopware.com/docs/guides/plugins/plugins/plugin-fundamentals/add-scheduled-task.html). Les mécanismes de chargement et d’authentification administrateur ont aussi été vérifiés dans les sources du tag `v6.7.15.1`.

## Chargement persistant du fournisseur (1.3)

Dans **Catalogue**, saisir les marques en haut puis **Préparer le chargement → Confirmer**. Le worker traite une page de 100 références maximum par passage (intervalle de 60 secondes). Le bouton **Traiter une page maintenant** permet une lecture manuelle. Les périmètres sont indépendants ; le catalogue complet peut encore recevoir HTTP 400 selon les droits API. Aucun import boutique n’est déclenché.

Choisir ensuite **Recherche dans le catalogue chargé**. Les filtres portent sur toutes les références en cache, sans plafond de 1 000 résultats, avec pagination serveur. Les autres modes de recherche directe restent disponibles. Les comptages sont ceux des données chargées, pas une estimation du catalogue non parcouru. Un périmètre interrompu reste partiel et affiche son état.

Pour actualiser, redemander le même périmètre : seul son ancien cache est remplacé. Une marque terminée reste disponible jusqu’à une actualisation manuelle. Pas de synchronisation automatique du catalogue entier ni de garantie de prix temps réel. Les imports relisent toujours TD SYNNEX ; `modifiedFrom` ne couvrant pas les changements de prix, les actualisations sont des parcours complets du périmètre.

### Mise à jour depuis une version précédente

Remplacer le dossier du plugin par celui du ZIP, puis exécuter dans l’environnement PHP de Shopware :

```bash
bin/console plugin:refresh
bin/console plugin:update TDBridge
bin/console assets:install
bin/console cache:clear
bin/console scheduled-task:register
```

Redémarrer les workers Messenger via leur superviseur et recharger l’administration. Ne pas désinstaller le plugin pour cette mise à jour. Aucun chargement massif ne démarre lors de l’installation.
