<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\DataAbstractionLayer\Event\EntityDeletedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/** Product deletions remove associations, never supplier catalogue offers or audit logs. */
final class ProductLifecycle implements EventSubscriberInterface
{
    public function __construct(private readonly Connection $db) {}
    public static function getSubscribedEvents(): array { return ['product.deleted' => 'deleted']; }
    public function deleted(EntityDeletedEvent $event): void
    {
        // A draft version deletion must not detach the live product.
        if ($event->getContext()->getVersionId() !== Defaults::LIVE_VERSION) { return; }
        $this->reconcile();
    }
    public function reconcile(): array
    {
        $live = hex2bin(Defaults::LIVE_VERSION);
        return $this->db->transactional(function () use ($live): array {
            $this->db->executeStatement("INSERT INTO lf_supplier_detached (supplier,part_number,detached_at) SELECT 'tdsynnex',l.part_number,UTC_TIMESTAMP(3) FROM td_bridge_product l LEFT JOIN product p ON p.id=l.product_id AND p.version_id=? WHERE p.id IS NULL ON DUPLICATE KEY UPDATE detached_at=VALUES(detached_at)", [$live]);
            $this->db->executeStatement('INSERT INTO lf_supplier_detached (supplier,part_number,detached_at) SELECT o.supplier,o.part_number,UTC_TIMESTAMP(3) FROM lf_supplier_offer o LEFT JOIN product p ON p.id=o.product_id AND p.version_id=? WHERE o.product_id IS NOT NULL AND p.id IS NULL ON DUPLICATE KEY UPDATE detached_at=VALUES(detached_at)', [$live]);
            $td = $this->db->executeStatement('DELETE l FROM td_bridge_product l LEFT JOIN product p ON p.id=l.product_id AND p.version_id=? WHERE p.id IS NULL', [$live]);
            $offers = $this->db->executeStatement('UPDATE lf_supplier_offer o LEFT JOIN product p ON p.id=o.product_id AND p.version_id=? SET o.product_id=NULL, o.sync_enabled=0 WHERE o.product_id IS NOT NULL AND p.id IS NULL', [$live]);
            $this->db->executeStatement('DELETE s FROM lf_supplier_source s LEFT JOIN product p ON p.id=s.product_id AND p.version_id=? WHERE p.id IS NULL', [$live]);
            return ['removedTdLinks' => $td, 'detachedOffers' => $offers];
        });
    }
}
