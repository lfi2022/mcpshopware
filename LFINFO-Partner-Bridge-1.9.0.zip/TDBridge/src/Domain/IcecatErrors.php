<?php declare(strict_types=1);

namespace TDBridge\Domain;

/** Only stable numeric provider codes are exposed; never its raw Message or file URLs. */
final class IcecatErrors
{
    public static function code(array $data): ?int
    {
        $value = $data['StatusCode'] ?? null;
        return (is_int($value) || (is_string($value) && ctype_digit($value))) && (int) $value >= 1 && (int) $value <= 999 ? (int) $value : null;
    }
    public static function message(int $httpStatus, ?int $code): string
    {
        $hint = match ($code) {
            1 => 'Langue ou identification du compte manquante.',
            2 => 'Langue Icecat inconnue. Vérifiez FR ou FR_BE.',
            3 => 'Utilisateur inconnu ou compte incompatible. Vérifiez le compte Channel Partner.',
            4, 16 => 'Identifiants produit invalides. Vérifiez EAN ou fabricant et référence constructeur.',
            5 => 'Accès refusé pour l’adresse IP du serveur. Vérifiez le mode d’accès et le jeton API dans MyIcecat.',
            7 => 'Identifiants du compte incompatibles avec la clé utilisée.',
            8, 17 => 'Fiche produit introuvable dans Icecat.',
            9 => 'Fiche réservée à Full Icecat : votre accès Open Icecat peut ne pas couvrir cette référence. Un compte Full doit transmettre son jeton API.',
            12 => 'Catégorie non incluse dans les droits du compte Icecat.',
            14 => 'Marque, produit ou langue soumis à une autorisation Icecat.',
            15 => 'Fiche non encore publiée par Icecat.',
            18 => 'Jeton API inconnu ou révoqué. Vérifiez que le jeton contenu n’a pas été saisi à sa place.',
            19 => 'Format du jeton API invalide. Copiez le jeton API complet depuis MyIcecat.',
            20, 30, 34 => 'Paramètre de requête refusé par Icecat.',
            default => match (true) {
                $httpStatus === 429 => 'Limite de requêtes atteinte. Le worker respectera Retry-After.',
                $httpStatus >= 500 => 'Service Icecat temporairement indisponible.',
                $httpStatus === 403 => 'Accès refusé sans motif numérique exploitable. Vérifiez les droits de la fiche, le compte et le jeton API.',
                default => 'Fiche indisponible ou accès Icecat refusé. Vérifiez le compte et la couverture de cette référence.',
            },
        };
        return 'Icecat HTTP ' . $httpStatus . ($code !== null ? ' (code ' . $code . ')' : '') . ' : ' . $hint;
    }
}
