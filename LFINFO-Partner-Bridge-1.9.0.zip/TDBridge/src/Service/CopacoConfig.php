<?php declare(strict_types=1);

namespace TDBridge\Service;

use Shopware\Core\System\SystemConfig\SystemConfigService;
use TDBridge\Domain\BridgeException;

final class CopacoConfig
{
    private const KEY='TDBridge.config.copaco';
    public function __construct(private readonly SystemConfigService $config, private readonly string $appSecret) {}
    public function all(): array
    {
        return array_replace(['enabled'=>false,'protocol'=>'ftps','host'=>'','port'=>21,'username'=>'','encryptedPassword'=>'','path'=>'','format'=>'xml','encoding'=>'UTF-8'], $this->config->get(self::KEY)??[]);
    }
    public function publicSettings(): array
    {
        $v=$this->all();$v['hasPassword']=$v['encryptedPassword']!=='';unset($v['encryptedPassword']);return $v;
    }
    public function save(array $input): void
    {
        $v=$this->all();
        foreach (['protocol','host','username','path','format','encoding'] as $key) {
            if (isset($input[$key])) {
                if (!is_string($input[$key]) || strlen($input[$key])>1024 || preg_match('/[\x00-\x1f\x7f]/',$input[$key])) { throw new BridgeException('Paramètre Datafile Copaco invalide.'); }
                $v[$key]=trim($input[$key]);
            }
        }
        $v['host']=strtolower($v['host']);
        if (!in_array($v['protocol'],['ftp','ftps'],true) || !in_array($v['format'],['xml','csv'],true) || !in_array($v['encoding'],['UTF-8','Windows-1252','ISO-8859-1'],true)) { throw new BridgeException('Protocole, format ou encodage Copaco non pris en charge.'); }
        if ($v['host']!=='' && (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/D',$v['host']) || str_ends_with($v['host'],'.local'))) { throw new BridgeException('Nom de serveur public attendu, sans URL, chemin ou identifiants.'); }
        if ($v['path']!=='' && (!str_starts_with($v['path'],'/') || str_contains($v['path'],'\\') || preg_match('~(?:^|/)\.\.(?:/|$)~',$v['path']))) { throw new BridgeException('Chemin distant absolu requis, sans traversée de dossier.'); }
        if (isset($input['port'])) { $v['port']=\TDBridge\Domain\CatalogueCriteria::integer($input['port'],1,65535); }
        if (isset($input['enabled'])) { if (!is_bool($input['enabled'])) { throw new BridgeException('Activation Copaco invalide.'); } $v['enabled']=$input['enabled']; }
        if (($input['clearPassword']??false)===true) { $v['encryptedPassword']=''; }
        $password=$input['password']??'';
        if (!is_string($password) || strlen($password)>4096 || preg_match('/[\r\n\x00]/',$password)) { throw new BridgeException('Mot de passe Copaco invalide.'); }
        if ($password!=='') { $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$v['encryptedPassword']=base64_encode($nonce.sodium_crypto_secretbox($password,$nonce,$this->key())); }
        if ($v['enabled'] && ($v['host']==='' || $v['username']==='' || $v['path']==='' || $v['encryptedPassword']==='')) { throw new BridgeException('Complétez le serveur, le compte, le mot de passe et le chemin avant activation.'); }
        $this->config->set(self::KEY,$v);
    }
    public function password(): string
    {
        $raw=base64_decode($this->all()['encryptedPassword'],true);
        if ($raw===false || strlen($raw)<=SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) { throw new BridgeException('Mot de passe Datafile Copaco absent ou invalide.'); }
        $plain=sodium_crypto_secretbox_open(substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),$this->key());
        if ($plain===false) { throw new BridgeException('Mot de passe Copaco indéchiffrable : enregistrez-le à nouveau.'); }
        return $plain;
    }
    private function key(): string
    {
        if ($this->appSecret==='') { throw new BridgeException('APP_SECRET requis pour les identifiants Copaco.'); }
        return hash('sha256','lfinfo.copaco:'.$this->appSecret,true);
    }
}
