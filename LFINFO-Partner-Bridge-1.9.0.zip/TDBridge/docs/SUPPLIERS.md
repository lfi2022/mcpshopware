# LFINFO Partner Bridge — fournisseurs et produits

## Mise à jour 1.9.0

La navigation actuelle est décrite dans [INTERFACE.md](INTERFACE.md). Les connexions sont désormais dans Fournisseurs ; le sélecteur du Catalogue remplace les onglets Copaco et Ingram. Les réglages enregistrés sont conservés.

Arrêter les pools CLI et workers Shopware qui utilisent cette extension. Remplacer le contenu de `custom/plugins/TDBridge` par le dossier `TDBridge` du ZIP, sans désinstaller le plugin. Conserver la base et `APP_SECRET` pour déchiffrer les identifiants existants.

Depuis l'hôte Docker de cette boutique :

```bash
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console plugin:refresh
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console plugin:update TDBridge
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console cache:clear
docker exec -w /var/www/html sw-shop-70e6ac-web-1 php bin/console assets:install
```

Recharger l'administration avec Ctrl+Maj+R. Relancer les workers après migration. Le nom de commande reste compatible :

```bash
docker exec -it -w /var/www/html sw-shop-70e6ac-web-1 php bin/console tdbridge:worker --max-workers=8 --seconds=3600
```

La migration crée `lf_supplier_offer`, `lf_supplier_source` et `lf_supplier_detached`, sans convertir ni supprimer les tables TD historiques. Elle mémorise les associations des anciennes tâches en attente. La migration 1.4.3 corrige toujours la largeur du statut des tâches. Les rôles personnalisés qui utilisent le sélecteur de produits nécessitent désormais les droits de lecture produit et traduction ; réenregistrer le rôle si nécessaire.

## Ingram Micro depuis 1.8.0

La recherche et le PNA Ingram v6 Belgique sont disponibles dans un onglet dédié. Voir [INGRAM.md](INGRAM.md) pour les paramètres et les protections. Le sandbox est en lecture uniquement. Les offres Ingram partagent le suivi et les campagnes des autres sources sans fusion automatique par EAN.

## Copaco depuis 1.6.0

Le connecteur Datafile officiel XML/CSV est disponible par FTP ou FTPS explicite. La configuration reste désactivée tant que le compte revendeur n'est pas reçu. Voir [COPACO.md](COPACO.md) pour l'activation, les paramètres, les horaires, les limites de fraîcheur et les tests réels encore nécessaires. Les paragraphes CSV ci-dessous décrivent le chargement manuel à mapping libre, toujours disponible.

## Parcours de gestion

1. Ouvrir **Fournisseurs & liaisons** dans LFINFO Supplier Bridge.
2. Pour une fiche existante : choisir le fournisseur, saisir sa référence exacte, sélectionner le produit Shopware et confirmer la liaison. Cocher « source des prix et stocks » pour activer le suivi ; les autres sources de ce produit passent en pause.
3. Pour TD SYNNEX : continuer à rechercher/importer dans Catalogue. La référence sera vérifiée lors de la tâche de synchronisation. Une référence incorrecte ne supprime jamais le produit.
4. Pour Copaco : charger un export CSV, adapter les en-têtes du mapping, contrôler l'aperçu puis enregistrer les offres. Le chargement ne modifie aucun produit boutique. Les offres absentes du fichier ne sont ni supprimées ni remises à zéro.
5. Dans les offres Copaco, choisir **Importer ce produit** puis confirmer, ou **Gérer la liaison** pour réutiliser une fiche existante. Un nouveau SKU utilise `COPACO-<référence>`. L'état actif, la TVA, la destination, les marges et le stock suivent les paramètres d'import enregistrés.
6. Dans **Mes produits**, synchroniser une référence ou lancer la synchronisation globale, avec les paramètres enregistrés. La source fournisseur figure sur chaque ligne et chaque tâche.

Pour retirer une association, vider le produit dans le formulaire de liaison puis confirmer. Cela ne supprime jamais la fiche Shopware. Supprimer une fiche live Shopware déclenche le nettoyage des associations ; une suppression de brouillon conserve le suivi du produit live. Le bouton de nettoyage rattrape les anciens orphelins, comme le worker lorsqu'il ne trouve plus de tâche prête. Les offres fournisseur non liées et les historiques restent disponibles.

Le forfait d'achat demeure **50 € HT par produit**, recalculé depuis le coût brut, sans cumul et sans effet sur la base du prix de vente. Les réglages sont figés par tâche. Pas de conversion de devises.

## Format CSV Copaco

Ce format est le contrat d'entrée du plugin, **pas une affirmation sur le format réel de l'API ou des exports Copaco**. Adapter le mapping à l'export disponible. UTF-8 avec ou sans BOM, séparateur point-virgule ou virgule, 2 Mo / 5 000 lignes par chargement. Le séparateur tabulation est aussi accepté par l'API interne.

```csv
reference;name;cost;currency;stock;brand;mpn;ean
CP-EXEMPLE;Portable exemple;600,50;EUR;12;Lenovo;MPN-EXEMPLE;1234567890123
```

Champs obligatoires : `partNumber`, `name`, `cost`, `currency`, `stock`. Facultatifs : `manufacturer`, `manufacturerNumber`, `ean`. Le prix est HT, positif, sans symbole ni séparateur de milliers ; le stock est un entier positif ou nul. EAN/UPC de 8, 12, 13 ou 14 chiffres. Les en-têtes doivent être uniques et les références non dupliquées. Une erreur de ligne refuse tout le fichier avant écriture.

Le chargement fusionne les offres par couple fournisseur/référence et conserve leurs liaisons. Le mapping est fourni avec chaque chargement : le conserver localement pour un export régulier. Le flux n'est pas relu automatiquement sur un serveur Copaco. La synchronisation et Icecat refusent un snapshot de plus de 24 heures ; recharger un fichier récent pour continuer. Aucune catégorie n'est déduite en l'absence de données documentées. Les filtres TD avancés restent disponibles dans le catalogue TD.

## Connecteurs et limites

`Supplier/CatalogueConnector` fournit des produits normalisés, sans écrire dans Shopware. `ConnectorRegistry` charge les services portant le tag `lfinfo.supplier.connector`. TD utilise `TdSynnexConnector`, Copaco utilise `CopacoFeedConnector`. Les imports, calculs de prix et workers restent communs.

Pour un futur connecteur supplémentaire : valider l'authentification et les droits du compte, implémenter le contrat normalisé, ajouter son inscription/capacités et adapter les périmètres d'offres, de catalogue et de campagnes globales. L'inscription d'un driver seule ne suffit pas à rendre tous ces écrans compatibles. Ne pas brancher la facturation Copaco Cloud sur un catalogue matériel sans documentation correspondante.

À fournir pour la connexion directe : documentation revendeur catalogue/prix/stock, URL, mécanisme d'authentification, pagination, limites et un exemple anonymisé. Les secrets sont à saisir dans l'administration lorsque leur prise en charge est implémentée. Ingram est implémenté depuis 1.8.0 via son API revendeur ; sa connexion réelle doit être testée avec un compte autorisé.

Les contrôles locaux utilisent MariaDB et les vraies bibliothèques Symfony/DBAL ; les écritures DAL sont observées via doubles ciblés. La compilation complète du conteneur Shopware et la persistance média doivent encore être validées sur une boutique de recette. Aucune migration ni action de masse n'est effectuée sur la boutique de production par la création de ce paquet.
