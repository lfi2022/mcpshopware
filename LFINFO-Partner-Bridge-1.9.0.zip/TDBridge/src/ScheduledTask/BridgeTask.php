<?php declare(strict_types=1);

namespace TDBridge\ScheduledTask;

use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTask;

final class BridgeTask extends ScheduledTask
{
    public static function getTaskName(): string { return 'td_bridge.process'; }
    public static function getDefaultInterval(): int { return 15; }
    public static function shouldRescheduleOnFailure(): bool { return true; }
}
