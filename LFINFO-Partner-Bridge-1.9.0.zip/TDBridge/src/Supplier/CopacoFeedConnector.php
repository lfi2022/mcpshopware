<?php declare(strict_types=1);

namespace TDBridge\Supplier;

use TDBridge\Service\SupplierOffers;

/** Manual reseller export, not an implementation of an undocumented Copaco API. */
final class CopacoFeedConnector implements CatalogueConnector
{
    public function __construct(private readonly SupplierOffers $offers) {}
    public function id(): string { return 'copaco'; }
    public function products(array $parts, array $options, string $purpose): array
    {
        $items=[];
        foreach ($parts as $part) {
            $item=$this->offers->item('copaco',$part,$purpose==='import');
            if ($item) { $items[]=$item; }
        }
        return $items;
    }
}
