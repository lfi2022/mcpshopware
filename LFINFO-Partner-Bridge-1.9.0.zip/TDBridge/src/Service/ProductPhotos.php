<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Defaults;

/** Read native media only. Parent photos also protect variants from unnecessary enrichment. */
final class ProductPhotos
{
    public function __construct(private readonly Connection $db) {}
    private function condition(): string
    {
        return "EXISTS (SELECT 1 FROM product_media pm JOIN media m ON m.id = pm.media_id WHERE (pm.product_id = p.id OR pm.product_id = p.parent_id) AND pm.product_version_id = p.version_id AND m.mime_type LIKE 'image/%' AND m.file_name IS NOT NULL AND m.file_name <> '')";
    }
    public function missingParts(): array
    {
        return $this->db->fetchFirstColumn('SELECT l.part_number FROM td_bridge_product l JOIN product p ON p.id = l.product_id AND p.version_id = UNHEX(?) WHERE l.sync_enabled = 1 AND NOT ' . $this->condition() . ' ORDER BY l.part_number', [Defaults::LIVE_VERSION]);
    }
    public function hasPhoto(string $productId): bool
    {
        return (bool) $this->db->fetchOne('SELECT ' . $this->condition() . ' FROM product p WHERE p.id = UNHEX(?) AND p.version_id = UNHEX(?)', [$productId, Defaults::LIVE_VERSION]);
    }
}
