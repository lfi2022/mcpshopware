<?php declare(strict_types=1);

namespace TDBridge\Service;

use Psr\Cache\CacheItemPoolInterface;
use Symfony\Component\HttpClient\NoPrivateNetworkHttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueCriteria;

final class TdClient
{
    private readonly HttpClientInterface $http;

    public function __construct(HttpClientInterface $http, private readonly Settings $settings, private readonly CacheItemPoolInterface $cache)
    {
        $this->http = new NoPrivateNetworkHttpClient($http);
    }

    public function catalogue(array $criteria): array
    {
        return $this->call('POST', '/resellers/v2/products/catalogue', ['json' => CatalogueCriteria::build($criteria)]);
    }

    public function documents(string $type, array $input): array
    {
        $common = ['CreatedFrom', 'CreatedTo', 'ModifiedFrom', 'ModifiedTo', 'CustomerOrderNumber', 'TdsynnexOrderNumber', 'DeliveryNoteNumber', 'InvoiceNumber', 'IncludeDetails', 'SortBy', 'SortDirection', 'Page', 'PageSize'];
        $allowed = array_merge($common, $type === 'orders' ? ['EtaDateFrom', 'EtaDateTo', 'OrderStatus', 'TdsynnexPartNumber', 'ManufPartNumber', 'Manufacturer'] : ['EndUserOrderNumber', 'BillingDateFrom', 'BillingDateTo', 'DueDateFrom', 'DueDateTo', 'DocumentType']);
        $query = [];
        foreach ($input as $key => $value) {
            if (!in_array($key, $allowed, true)) { throw new BridgeException("Paramètre non documenté : $key."); }
            if ($value === '' || $value === null) { continue; }
            if (str_ends_with($key, 'From') || str_ends_with($key, 'To')) {
                $value = CatalogueCriteria::date($value);
                if ($type === 'orders') { $value = (new \DateTimeImmutable($value, new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z'); }
            }
            elseif ($key === 'IncludeDetails') { if (!is_bool($value)) { throw new BridgeException('IncludeDetails doit être booléen.'); } $value = $value ? 'true' : 'false'; }
            elseif (!in_array($key, ['Page', 'PageSize', 'OrderStatus'], true) && (!is_string($value) || strlen($value) > 200)) { throw new BridgeException('Filtre document invalide.'); }
            $query[$key] = $value;
        }
        $query['Page'] = CatalogueCriteria::integer($query['Page'] ?? 1, 1, 100000);
        $query['PageSize'] = CatalogueCriteria::integer($query['PageSize'] ?? 20, 1, $type === 'orders' && ($query['IncludeDetails'] ?? 'false') === 'true' ? 20 : 100);
        $enums = ['SortDirection' => ['ASC', 'DESC'], 'SortBy' => $type === 'orders' ? ['CREATED', 'UPDATED', 'ORDERID'] : ['BILLINGDATE', 'DOCUMENTID', 'DOCUMENTTYPE'], 'DocumentType' => ['Invoice', 'CreditMemo', 'DebitMemo', 'ProFormaInvoice']];
        foreach ($enums as $key => $values) { if (isset($query[$key]) && !in_array($query[$key], $values, true)) { throw new BridgeException("$key invalide."); } }
        $statuses = $query['OrderStatus'] ?? [];
        unset($query['OrderStatus']);
        if (!is_array($statuses) || count($statuses) > 5 || array_diff($statuses, ['OPEN', 'INVESTIGATION', 'SHIPPING', 'REJECTED', 'COMPLETED'])) { throw new BridgeException('Statut commande invalide.'); }
        $encoded = http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        foreach ($statuses as $status) { $encoded .= '&OrderStatus=' . rawurlencode($status); }
        return $this->call('GET', '/resellers/v1/' . $type . '?' . $encoded);
    }

    public function test(): array
    {
        $this->token(true);
        return ['connected' => true, 'message' => 'Authentification OAuth réussie. Testez ensuite le catalogue pour vérifier vos droits.'];
    }

    private function token(bool $refresh = false): string
    {
        $settings = $this->settings->all();
        $secret = $this->settings->secret();
        if ($settings['clientId'] === '') { throw new BridgeException('Client ID manquant.'); }
        $key = 'tdbridge.token.' . hash('sha256', $settings['tokenUrl'] . $settings['baseUrl'] . $settings['clientId'] . $secret);
        $item = $this->cache->getItem($key);
        if (!$refresh && $item->isHit()) { return (string) $item->get(); }
        $body = ['grant_type' => 'client_credentials', 'client_id' => $settings['clientId'], 'client_secret' => $secret];
        $options = $settings['tokenEncoding'] === 'json' ? ['json' => $body] : ['body' => $body, 'headers' => ['Content-Type' => 'application/x-www-form-urlencoded']];
        $response = $this->request('POST', $settings['tokenUrl'], $options);
        if (!isset($response['access_token']) || !is_string($response['access_token']) || $response['access_token'] === '') { throw new BridgeException('Réponse OAuth sans access_token.', 502); }
        $expires = $response['expires_in'] ?? 300;
        $expires = is_numeric($expires) ? max(1, min(86400, (int) $expires - 60)) : 240;
        $item->set($response['access_token']);
        $item->expiresAfter($expires);
        $this->cache->save($item);
        return $response['access_token'];
    }

    private function call(string $method, string $path, array $options = []): array
    {
        $settings = $this->settings->all();
        for ($attempt = 0; $attempt < 2; ++$attempt) {
            $options['headers'] = ['Authorization' => 'Bearer ' . $this->token($attempt > 0), 'TraceId' => bin2hex(random_bytes(16)), 'Accept-Language' => $settings['language'], 'Accept' => 'application/json'];
            try { return $this->request($method, $settings['baseUrl'] . $path, $options); }
            catch (BridgeException $e) { if ($e->httpStatus !== 401 || $attempt > 0) { throw $e; } }
        }
        throw new BridgeException('Authentification refusée.', 401);
    }

    private function request(string $method, string $url, array $options): array
    {
        try {
            $response = $this->http->request($method, $url, array_replace($options, ['timeout' => 20, 'max_duration' => 45, 'max_redirects' => 0]));
            $status = $response->getStatusCode();
            if ($status < 200 || $status >= 300) {
                $retry = $response->getHeaders(false)['retry-after'][0] ?? '60';
                $delay = ctype_digit($retry) ? (int) $retry : max(60, (strtotime($retry) ?: time()) - time());
                throw new BridgeException(match ($status) {
                    400 => 'TD SYNNEX a refusé les paramètres (HTTP 400).',
                    401 => 'TD SYNNEX : identifiants ou jeton refusés (HTTP 401).',
                    403 => 'TD SYNNEX : votre compte ne dispose pas des droits nécessaires (HTTP 403).',
                    429 => 'Limite TD SYNNEX atteinte ; la tâche sera réessayée plus tard.',
                    default => "Erreur de service TD SYNNEX (HTTP $status).",
                }, $status, $status === 429 ? max(1, min(86400, $delay)) : 0);
            }
            $result = $response->toArray(false);
            if ($result === []) { return []; }
            return $result;
        } catch (BridgeException $e) { throw $e; }
        catch (\Throwable) { throw new BridgeException('Réponse JSON invalide ou connexion TD SYNNEX indisponible. Vérifiez les URL et le réseau.', 502); }
    }
}
