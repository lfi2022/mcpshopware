<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class CatalogueCategories
{
    // TD product classes, independent of the destination categories in Shopware.
    public const LABELS = [
        'COMPORT' => 'Ordinateurs portables',
        'COMDESK' => 'Ordinateurs de bureau',
        'COMSER' => 'Serveurs',
        'PERMONIT' => 'Écrans et moniteurs',
        'KEYBMICE' => 'Claviers et souris',
        'POSSYSTEM' => 'Systèmes de point de vente',
        'COMACCSER' => 'Accessoires pour serveurs',
        'COMHAND' => 'Ordinateurs de poche',
        'CALCS' => 'Calculatrices',
    ];

    public static function options(array $rows): array
    {
        $options = [];
        foreach (self::LABELS as $value => $label) { $options[$value] = ['value' => $value, 'label' => $label, 'total' => 0]; }
        foreach ($rows as $row) {
            $value = (string) $row['value'];
            if ($value === '') { continue; }
            $options[$value] = ['value' => $value, 'label' => self::LABELS[$value] ?? $value, 'total' => (int) $row['total']];
        }
        uasort($options, static fn (array $a, array $b) => strcmp($a['label'], $b['label']));
        return array_values($options);
    }
}
