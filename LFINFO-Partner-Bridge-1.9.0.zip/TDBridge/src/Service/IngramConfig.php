<?php declare(strict_types=1);

namespace TDBridge\Service;

use Shopware\Core\System\SystemConfig\SystemConfigService;
use TDBridge\Domain\BridgeException;

final class IngramConfig
{
    private const KEY='TDBridge.config.ingram';
    public function __construct(private readonly SystemConfigService $config,private readonly string $appSecret) {}
    public function all(): array { return array_replace(['enabled'=>false,'environment'=>'sandbox','customerNumber'=>'','clientId'=>'','encryptedSecret'=>'','senderId'=>'LFINFO Partner Bridge','language'=>'fr','oauthVersion'=>'20'],$this->config->get(self::KEY)??[]); }
    public function publicSettings(): array { $v=$this->all();$v['hasSecret']=$v['encryptedSecret']!=='';unset($v['encryptedSecret']);return $v; }
    public function scope(): string { $v=$this->all();return hash('sha256',$v['environment'].'|BE|'.$v['customerNumber']); }
    public function save(array $input): void
    {
        $v=$this->all();
        foreach(['environment','customerNumber','clientId','senderId','language','oauthVersion'] as $key){if(isset($input[$key])){if(!is_string($input[$key])||strlen($input[$key])>200||preg_match('/[\x00-\x1f\x7f]/',$input[$key])){throw new BridgeException('Configuration Ingram Micro invalide.');}$v[$key]=trim($input[$key]);}}
        if(!in_array($v['environment'],['sandbox','production'],true)||!in_array($v['oauthVersion'],['20','30'],true)||!in_array($v['language'],['fr','nl','en'],true)||strlen($v['senderId'])>32||($v['customerNumber']!==''&&!preg_match('/^[A-Za-z0-9-]{1,10}$/D',$v['customerNumber']))){throw new BridgeException('Environnement, numéro client, Sender ID, langue ou version OAuth Ingram invalide.');}
        if(isset($input['enabled'])){if(!is_bool($input['enabled'])){throw new BridgeException('Activation Ingram invalide.');}$v['enabled']=$input['enabled'];}
        if(($input['clearSecret']??false)===true){$v['encryptedSecret']='';}
        $secret=$input['clientSecret']??'';if(!is_string($secret)||strlen($secret)>4096||preg_match('/[\x00\r\n]/',$secret)){throw new BridgeException('Secret Ingram invalide.');}
        if($secret!==''){$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$v['encryptedSecret']=base64_encode($nonce.sodium_crypto_secretbox($secret,$nonce,$this->key()));}
        if($v['enabled']&&(!$v['customerNumber']||!$v['clientId']||!$v['encryptedSecret'])){throw new BridgeException('Complétez le numéro client et les identifiants OAuth avant activation Ingram.');}
        $this->config->set(self::KEY,$v);
    }
    public function secret(): string
    {
        $raw=base64_decode($this->all()['encryptedSecret'],true);if($raw===false||strlen($raw)<=SODIUM_CRYPTO_SECRETBOX_NONCEBYTES){throw new BridgeException('Secret Ingram absent ou invalide.');}
        $v=sodium_crypto_secretbox_open(substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),$this->key());if($v===false){throw new BridgeException('Secret Ingram indéchiffrable : enregistrez-le à nouveau.');}return $v;
    }
    public function ready(bool $write=false): void
    {
        $v=$this->all();if(!$v['enabled']||!$v['customerNumber']||!$v['clientId']||!$v['encryptedSecret']){throw new BridgeException('Activez et configurez Ingram Micro dans les paramètres.');}
        if($write&&$v['environment']!=='production'){throw new BridgeException('Le sandbox Ingram est réservé à la lecture. Les imports et mises à jour Shopware nécessitent le mode production.');}
    }
    private function key(): string { if($this->appSecret===''){throw new BridgeException('APP_SECRET requis.');}return hash('sha256','lfinfo.ingram:'.$this->appSecret,true); }
}
