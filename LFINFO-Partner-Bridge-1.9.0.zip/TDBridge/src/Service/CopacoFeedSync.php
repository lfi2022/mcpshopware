<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CopacoDatafile;

final class CopacoFeedSync
{
    public function __construct(private readonly Connection $db,private readonly CopacoConfig $config,private readonly CopacoDownload $download,private readonly CopacoDatafile $reader) {}
    private function stage(array $rows): void
    {
        try {
            $this->db->executeStatement('INSERT INTO lf_copaco_stage (batch,part_number,name,description,manufacturer,manufacturer_number,ean,cost,currency,stock,product_class,supplier_status,cost_inclusive) VALUES '.implode(',',array_fill(0,count($rows),'(?,?,?,?,?,?,?,?,?,?,?,?,?)')),array_merge(...$rows));
        } catch (\Doctrine\DBAL\Exception\UniqueConstraintViolationException) { throw new BridgeException('Référence dupliquée dans le Datafile. Catalogue précédent conservé.'); }
    }
    public function status(): array { return ($this->db->fetchAssociative('SELECT * FROM lf_copaco_refresh WHERE id=1')?:[]) + ['workerActive'=>$this->db->fetchOne("SELECT IS_USED_LOCK('lfinfo.copaco.refresh')")!==null]; }
    public function request(): array
    {
        $v=$this->config->all();if(!$v['host'] || !$v['path'] || !$v['encryptedPassword']){throw new BridgeException('Enregistrez les paramètres Datafile Copaco avant le chargement.');}
        if((int)$this->db->fetchOne("SELECT GET_LOCK('lfinfo.copaco.refresh',0)")!==1){throw new BridgeException('Un chargement Copaco est déjà en cours.',409);}
        try { $this->db->executeStatement("UPDATE lf_copaco_refresh SET status='queued',requested=1,next_attempt_at=UTC_TIMESTAMP(3) WHERE id=1"); }
        finally { $this->db->fetchOne("SELECT RELEASE_LOCK('lfinfo.copaco.refresh')"); }
        return $this->status();
    }
    private function due(array $config,array $state,\DateTimeImmutable $now): bool
    {
        if(!($state['requested']??false)){
            if(!$config['enabled'] || $state['completed_day']===$now->format('Y-m-d')){return false;}
            $last=$state['last_attempt_at']?(new \DateTimeImmutable($state['last_attempt_at'],new \DateTimeZone('UTC')))->setTimezone($now->getTimezone())->format('Y-m-d'):null;
            if($last!==$now->format('Y-m-d')){return true;}
        }
        return !$state['next_attempt_at'] || strtotime($state['next_attempt_at'].' UTC')<=$now->getTimestamp();
    }
    public function refreshIfDue(?\DateTimeImmutable $now = null): array
    {
        $v=$this->config->all();$s=$this->status();$now=($now??new \DateTimeImmutable('now'))->setTimezone(new \DateTimeZone('Europe/Brussels'));
        $due=$this->due($v,$s,$now);
        if (!$due) { return ['state'=>'idle']; }
        if ((int)$this->db->fetchOne("SELECT GET_LOCK('lfinfo.copaco.refresh',0)")!==1) { return ['state'=>'busy']; }
        $file=null;
        try {
            $current=$this->status();
            $stillDue=$this->due($v,$current,$now);
            if(!$stillDue) { return ['state'=>'idle']; }
            $this->db->executeStatement('DELETE FROM lf_copaco_stage');
            $this->db->executeStatement("UPDATE lf_copaco_refresh SET status='running',requested=0,last_attempt_at=?,next_attempt_at=?,last_error=NULL WHERE id=1",[$now->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'),$now->modify('+1 hour')->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s')]);
            $file=$this->download->download($v,$this->config->password());
            $result=$this->publish($file['path'],$file['modified'],$v['format'],$v['encoding']);
            $this->db->update('lf_copaco_refresh',['completed_day'=>$now->format('Y-m-d'),'next_attempt_at'=>null],['id'=>1]);
            return ['state'=>'ready']+$result;
        } catch (\Throwable $e) {
            // Transport/parser errors contain no provider body, URL or credentials.
            $message=$e instanceof BridgeException?$e->getMessage():'Échec interne du Datafile Copaco. Catalogue précédent conservé.';
            $this->db->executeStatement("UPDATE lf_copaco_refresh SET status='failed',last_error=? WHERE id=1",[mb_substr($message,0,500)]);
            return ['state'=>'failed','message'=>$message];
        } finally {
            if($file){@unlink($file['path']);}$this->db->fetchOne("SELECT RELEASE_LOCK('lfinfo.copaco.refresh')");
        }
    }
    /** Publish only after validating the complete file; staging never changes Shopware products. */
    public function publish(string $path,int $modified,string $format,string $encoding='UTF-8'): array
    {
        if ($modified>time()+300 || $modified<time()-36*3600) { throw new BridgeException('Datafile distant datant de plus de 36 h ou date future : publication refusée.'); }
        $batch=bin2hex(random_bytes(16));$count=0;$invalidEans=0;$checksum=hash_file('sha256',$path);
        try {
            $rows=[];$bytes=0;
            foreach ($this->reader->rows($path,$format,$encoding) as $item) {
                $rows[]=[$batch,$item['partNumber'],$item['name'],$item['description'],$item['manufacturer'],$item['manufacturerNumber'],$item['ean'],$item['cost'],$item['currency'],$item['stock'],$item['class'],$item['status'],$item['costInclusive']];
                ++$count;$invalidEans+=(int)$item['eanInvalid'];$bytes+=strlen($item['description']);
                if(count($rows)===500 || $bytes>=1000000){$this->stage($rows);$rows=[];$bytes=0;}
            }
            if($rows){$this->stage($rows);}
            if(!$count){throw new BridgeException('Datafile sans article : catalogue précédent conservé.');}
            $this->db->transactional(function()use($batch,$modified,$checksum,$count,$invalidEans):void{
                $this->db->executeStatement("UPDATE lf_supplier_offer SET catalogue_available=0,last_error='Article absent du dernier Datafile ; fiche Shopware conservée.' WHERE supplier='copaco'");
                $this->db->executeStatement(<<<'SQL'
INSERT INTO lf_supplier_offer (supplier,part_number,name,description,manufacturer,manufacturer_number,ean,cost,currency,stock,observed_at,next_sync_at,product_class,supplier_status,cost_inclusive,source_kind,catalogue_available)
SELECT 'copaco',part_number,name,description,manufacturer,manufacturer_number,ean,cost,currency,stock,?,UTC_TIMESTAMP(3),product_class,supplier_status,cost_inclusive,'datafile',1 FROM lf_copaco_stage WHERE batch=?
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),manufacturer=VALUES(manufacturer),manufacturer_number=VALUES(manufacturer_number),ean=VALUES(ean),cost=VALUES(cost),currency=VALUES(currency),stock=VALUES(stock),observed_at=VALUES(observed_at),next_sync_at=VALUES(next_sync_at),product_class=VALUES(product_class),supplier_status=VALUES(supplier_status),cost_inclusive=VALUES(cost_inclusive),source_kind='datafile',catalogue_available=1,last_error=NULL
SQL,[gmdate('Y-m-d H:i:s',$modified),$batch]);
                $this->db->executeStatement("UPDATE lf_copaco_refresh SET status='ready',last_success_at=UTC_TIMESTAMP(3),source_modified_at=?,checksum=?,total=?,invalid_eans=?,last_error=NULL WHERE id=1",[gmdate('Y-m-d H:i:s',$modified),$checksum,$count,$invalidEans]);
            });
            return ['total'=>$count,'invalidEans'=>$invalidEans,'sourceModifiedAt'=>gmdate('c',$modified)];
        } finally { $this->db->executeStatement('DELETE FROM lf_copaco_stage WHERE batch=?',[$batch]); }
    }
}
