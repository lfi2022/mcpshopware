# Navigation — LFINFO Partner Bridge 1.9

## Fournisseurs

Choisir une carte TD SYNNEX, Copaco ou Ingram Micro affiche sa connexion. Les identifiants déjà enregistrés sont conservés. L'enregistrement reste propre à chaque compte. Le mapping JSON TD est dans « Mapping avancé TD SYNNEX » ; le CSV manuel Copaco reste facultatif.

Le chemin FTP Copaco doit désigner le **fichier complet**, par exemple `/compte/Out/catalogue.xml`, et non son dossier. L'activation du chargement quotidien reste explicite et nécessite le worker.

Le bouton « Explorer ce fournisseur » ouvre le catalogue correspondant. Les liaisons aux fiches Shopware restent explicites et une seule source contrôle les prix et stocks d'un produit.

## Catalogue

Le sélecteur propose TD SYNNEX, Copaco, Ingram Micro ou **Tous les fournisseurs**. Changer de vue ne lance aucun import, téléchargement FTP ou index complet. Les sélections d'import sont conservées par source.

Dans la vue globale, renseigner par exemple les marques `Lenovo ; HP`, le texte `ThinkBook`, un coût maximum et le stock souhaité. Les catégories sont distinctes : un code TD n'est pas automatiquement traduit en catégorie Copaco ou Ingram. Sans filtre avancé déplié, les critères supplémentaires issus d'une précédente recherche individuelle sont réinitialisés lors de la recherche globale. Avec les filtres avancés activés, leurs valeurs sont conservées et visibles dans les formulaires de chaque source.

Les champs communs du formulaire global remplacent les champs équivalents des formulaires individuels au lancement. Les filtres avancés servent aux critères supplémentaires propres à chaque source.

Le bouton global lance trois recherches indépendantes et en lecture seule :

| Source | Données consultées | Portée et suite |
| --- | --- | --- |
| TD SYNNEX | API catalogue, références importées ou non | Au maximum quatre pages fournisseur par passage ; continuer avec « Chercher plus de résultats TD ». Limite de 1 000 correspondances par recherche. |
| Copaco | Dernier Datafile publié dans le plugin | Filtres SQL sur tout ce catalogue, 25 offres par page. Charger le Datafile depuis la vue Copaco si nécessaire. |
| Ingram Micro | API catalogue puis prix et disponibilités | 25 références API par page ; filtres de coût et stock sur la page reçue. Le total annoncé par Ingram peut donc dépasser les lignes affichées. |

Une erreur est affichée au nom de sa source. Les autres résultats restent disponibles. La vue globale ne fusionne pas les produits par EAN et n'additionne pas les stocks ni les totaux de recherche. Les références et confirmations d'import restent propres à chaque fournisseur. Le sandbox Ingram conserve la lecture seule.

Dans une vue individuelle, tous les filtres et les fonctions avancées habituelles sont disponibles, dont le catalogue de marques TD en mémoire et le suivi FTP Copaco.

## Paramètres et Mes produits

**Paramètres** contient la TVA, la devise, la destination des nouveaux produits, les règles de prix, la synchronisation, le nombre de workers et Icecat. **Mes produits** conserve les synchronisations individuelles/globales et l'enrichissement Icecat des produits sans photo.

Cette version change uniquement le module du plugin. Le nom technique du dossier, des commandes et de l'extension reste `TDBridge` pour mettre à jour l'installation existante.
