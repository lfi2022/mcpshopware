<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793060000JobStatusLength extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793060000; }
    public function update(Connection $db): void
    {
        // completed_with_errors is 21 characters; the initial schema allowed only 20.
        $db->executeStatement("ALTER TABLE td_bridge_job MODIFY COLUMN status VARCHAR(32) NOT NULL DEFAULT 'queued'");
    }
    public function updateDestructive(Connection $db): void {}
}
