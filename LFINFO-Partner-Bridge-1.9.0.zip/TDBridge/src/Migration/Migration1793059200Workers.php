<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793059200Workers extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793059200; }
    public function update(Connection $db): void
    {
        $db->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS td_bridge_worker_state (
 id TINYINT NOT NULL PRIMARY KEY, cooldown_until DATETIME(3) NULL,
 pool_heartbeat DATETIME(3) NULL, pool_workers INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $db->executeStatement('INSERT IGNORE INTO td_bridge_worker_state (id) VALUES (1)');
        // Only the plugin's own task, and only its previous default interval.
        $db->executeStatement("UPDATE scheduled_task SET run_interval = 15 WHERE name = 'td_bridge.process' AND run_interval = 60");
    }
    public function updateDestructive(Connection $db): void {}
}
