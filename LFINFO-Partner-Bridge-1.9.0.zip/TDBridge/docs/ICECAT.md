# Open Icecat intégré — 1.3.0

## Erreurs SQL et accès Icecat — 1.4.3

Le schéma initial limitait `td_bridge_job.status` à 20 caractères. Après une erreur produit, l’enregistrement du statut `completed_with_errors` (21 caractères) échouait avec SQLSTATE 22001 et masquait le refus initial. La migration 1.4.3 passe le champ à 32 caractères, sans supprimer l’historique. Elle est appliquée par `plugin:update TDBridge`. Le diagnostic en lecture seule `tdbridge:diagnose` doit afficher `statusType: varchar(32)` et `terminalStatusFits: true`.

Un HTTP 403 reste un refus fournisseur indépendant. Depuis 1.4.3, **Paramètres → Open Icecat → Tester / voir la fiche** affiche le code numérique `StatusCode` s’il est présent, sans écrire de produit ni relancer une tâche. Les jetons et le corps de réponse brut restent masqués.

| Code Icecat | Motif documenté | Vérification |
| --- | --- | --- |
| 5 | IP refusée | Mode d’accès du compte et jeton API ; avec une app key, liste des IP autorisées |
| 9 | Fiche Full Icecat | Couverture de cette référence par Open Icecat ; pour un compte Full, jeton API transmis |
| 12 | Catégorie non couverte | Droits de catégorie du compte |
| 14 | Restriction de marque/produit/langue | Autorisation de revendeur et langue demandée |
| 18 / 19 | Jeton API inconnu ou format invalide | Jeton API complet ; ne pas l’intervertir avec le jeton contenu |
| 3 | Compte inconnu ou incompatible | Utilisateur et type Channel Partner |

Ces codes n’ont pas tous le même statut HTTP. La correspondance est celle du [manuel officiel Icecat, section Errors](https://iceclog.com/manual-for-icecat-json-product-requests/#9-errors). Un compte Open ne garantit pas l’accès à toutes les fiches. Un 403 sans code exploitable ne permet pas de conclure que le jeton est incorrect. Résoudre l’accès avant de relancer les enrichissements en erreur ; la mise à jour ne relance rien automatiquement.

Le connecteur est désormais inclus dans TD SYNNEX Bridge. Aucun abonnement au connecteur commercial Shopware n’est nécessaire pour cette intégration. La disponibilité des fiches et fichiers dépend de vos droits Open Icecat.

## Configuration dans TD Bridge

1. Dans MyIcecat, vérifier que le compte est de type **Channel Partner**, compatible avec Product JSON.
2. Dans **Access Tokens**, créer un **API token** et un **content token**. Ne pas partager ces jetons dans une conversation ou un journal.
3. Dans **TD SYNNEX Bridge → Paramètres → Open Icecat**, saisir le nom utilisateur, les jetons et la langue (`FR_BE` ou `FR`). Les jetons sont masqués et chiffrés côté serveur avec Sodium et `APP_SECRET`. Un champ vide conserve le jeton enregistré.
4. Enregistrer, saisir une référence TD connue puis cliquer **Tester / voir la fiche**. Cette action lit TD et Icecat sans importer de produit. L’aperçu ne contient pas les URL signées ni les jetons.
5. Choisir les contenus et activer **Enrichir les imports sélectionnés avec Icecat**. Cette option est désactivée à l’installation.

L’API JSON est appelée côté serveur à `https://live.icecat.biz/api`, par fabricant + référence fabricant, avec le GTIN comme possibilité de repli. Le SKU boutique préfixé `TD-…` n’est pas utilisé comme référence constructeur. Les jetons sont envoyés dans les en-têtes `api-token` et `content-token`. Sans jeton API, le nom utilisateur peut suffire pour une fiche Open Icecat, selon les droits du compte.

## Enrichissement

- Un **nouvel import sélectionné** reçoit les contenus Icecat choisis. TD reste la source du prix et du stock ; les données TD sont relues au traitement.
- Pour un produit déjà importé, **Mes produits → Enrichir Icecat** crée une tâche explicite. Ce bouton ne crée pas un article fournisseur non lié.
- Les textes existants sont conservés sauf si **Autoriser le remplacement des textes existants** est activé. Les nouveaux produits reçoivent immédiatement les contenus choisis. Le titre Icecat est une option distincte désactivée par défaut.
- Les caractéristiques sont ajoutées sous forme de tableau dans la description. Aucun groupe ou option de propriétés Shopware global n’est créé. Les textes sont convertis en texte puis échappés avant génération du HTML.
- Jusqu’à huit images sont téléchargées et enregistrées avec le gestionnaire média Shopware. Les médias et la couverture existants sont conservés ; la première image Icecat sert de couverture seulement en l’absence de couverture. Les identifiants stables évitent les doublons à la reprise.
- Les fichiers doivent provenir de HTTPS sur `icecat.biz` ou ses sous-domaines, sans redirection ni accès réseau privé. JPEG, PNG et WebP seulement, maximum 12 Mo et 40 millions de pixels par fichier.
- Un échec Icecat après un import TD réussi produit un avertissement dans le journal ; le produit TD reste importé. Un échec d’image conserve les textes réussis et peut être repris avec **Enrichir Icecat**. Une tâche Icecat seule en erreur peut être relancée dans **Imports**.
- Quand Icecat est activé, la synchronisation automatique TD conserve les textes et ne déclenche aucun appel Icecat. L’enrichissement n’est jamais exécuté pendant l’indexation fournisseur.

Une tâche enrichie traite un produit par passage du worker. Aucun appel Icecat n’est fait depuis le navigateur client ; aucun thème ou composant storefront n’est ajouté.

## Limites et recette

Open Icecat ne couvre pas toutes les marques/références. L’aperçu indique la langue effectivement fournie pour la description, qui peut différer de celle demandée. Cette version écrit les contenus dans la langue principale du contexte Shopware ; elle ne crée pas de traductions multiples. PDF, vidéos, accessoires et propriétés de filtrage natives ne sont pas importés. Les images déjà téléchargées sont réutilisées lors d’une nouvelle demande ; cette version ne programme pas leur renouvellement automatique.

Tester une référence couverte, avec EAN ou référence fabricant fiable, puis un import en brouillon. Vérifier textes, tableau de caractéristiques et fichiers hébergés localement. Relancer l’enrichissement pour vérifier l’absence de doublons, puis une synchronisation TD pour contrôler la conservation du contenu. Les tests automatisés utilisent des réponses simulées et des doubles DAL ; les droits de votre compte et la persistance dans votre instance doivent être vérifiés après installation.

Contrat : [documentation officielle Product JSON Icecat](https://iceclog.com/manual-for-icecat-json-product-requests/), version 3.0 consultée le 26 octobre 2026. Le [connecteur commercial Icecat–Shopware](https://icecat.com/connectors-3/shopware/) reste une alternative indépendante ; il n’est pas installé par TD Bridge.

## Campagne sans photo — 1.4

**Mes produits → Enrichir Icecat — produits sans photo** prépare une campagne sur les seules références liées avec suivi actif sans image live ou héritée. Le filtre de liste n’en réduit pas le périmètre. L’aperçu est en lecture seule ; une confirmation crée les tâches. Le contrôle de photo est répété au traitement, les images sont activées pour cette campagne et les autres contenus suivent les options enregistrées. Les produits déjà illustrés sont ignorés sans appel Icecat. Les prix, stocks et catégories ne sont pas modifiés par cette campagne. La couverture Open Icecat reste applicable.
