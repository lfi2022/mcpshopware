<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793064000CopacoMidnight extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793064000; }
    public function update(Connection $db): void
    {
        $columns=array_column($db->fetchAllAssociative('SHOW COLUMNS FROM lf_copaco_refresh'),'Field');
        if(!in_array('completed_day',$columns,true)){
            $db->executeStatement('ALTER TABLE lf_copaco_refresh ADD COLUMN completed_day DATE NULL');
            $last=$db->fetchOne('SELECT last_success_at FROM lf_copaco_refresh WHERE id=1');
            if($last){
                $day=(new \DateTimeImmutable($last,new \DateTimeZone('UTC')))->setTimezone(new \DateTimeZone('Europe/Brussels'))->format('Y-m-d');
                $db->update('lf_copaco_refresh',['completed_day'=>$day,'next_attempt_at'=>null],['id'=>1]);
            }
        }
    }
    public function updateDestructive(Connection $db): void {}
}
