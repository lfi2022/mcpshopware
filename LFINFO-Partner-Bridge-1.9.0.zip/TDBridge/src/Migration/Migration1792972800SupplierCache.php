<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1792972800SupplierCache extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1792972800; }
    public function update(Connection $connection): void
    {
        // New opt-in state: never resumes the index retired in 1.2.
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS td_bridge_scope (
 id VARCHAR(64) NOT NULL PRIMARY KEY, brand VARCHAR(200) NOT NULL,
 status VARCHAR(20) NOT NULL, next_page INT NOT NULL DEFAULT 1,
 scanned INT NOT NULL DEFAULT 0, total INT NULL, attempts INT NOT NULL DEFAULT 0,
 last_error VARCHAR(500) NULL, available_at DATETIME(3) NOT NULL,
 started_at DATETIME(3) NOT NULL, completed_at DATETIME(3) NULL, updated_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS td_bridge_supplier (
 scope_id VARCHAR(64) NOT NULL, part_number VARCHAR(100) NOT NULL,
 manufacturer VARCHAR(200) NOT NULL, product_class VARCHAR(200) NOT NULL,
 product_subclass VARCHAR(200) NOT NULL, product_status VARCHAR(30) NOT NULL,
 class_label VARCHAR(255) NOT NULL, subclass_label VARCHAR(255) NOT NULL,
 search_text LONGTEXT NOT NULL, stock INT NULL, cost DECIMAL(18,6) NULL,
 payload LONGTEXT NOT NULL, indexed_at DATETIME(3) NOT NULL,
 PRIMARY KEY(scope_id, part_number),
 KEY `idx.td_bridge.supplier.part` (part_number),
 KEY `idx.td_bridge.supplier.brand` (manufacturer),
 KEY `idx.td_bridge.supplier.class` (product_class, product_subclass)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
    }
    public function updateDestructive(Connection $connection): void {}
}
