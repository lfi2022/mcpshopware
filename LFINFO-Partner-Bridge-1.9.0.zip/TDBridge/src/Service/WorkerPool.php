<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\Process\Process;
use Psr\Log\LoggerInterface;

/** One coordinator, bounded short-lived PHP workers, no shell or daemon from HTTP. */
final class WorkerPool
{
    private bool $stopping = false;
    private array $childErrors = [];
    public function __construct(private readonly JobManager $jobs, private readonly Connection $db, private readonly KernelInterface $kernel, private readonly ?LoggerInterface $logger = null) {}
    public function stop(): void { $this->stopping = true; }
    public function run(int $seconds = 20, ?callable $report = null): array
    {
        $this->stopping = false;
        $this->childErrors = [];
        if (PHP_SAPI !== 'cli' || !function_exists('proc_open')) { return ['mode' => 'serial', 'result' => $this->jobs->drain($seconds)]; }
        if ((int) $this->db->fetchOne("SELECT GET_LOCK('tdbridge.pool', 0)") !== 1) { return ['mode' => 'existing-pool']; }
        $children = []; $launched = 0; $deadline = microtime(true) + $seconds;
        try {
            do {
                foreach ($children as $key => $process) {
                    $process->checkTimeout();
                    if (!$process->isRunning()) {
                        if (!$process->isSuccessful() && !$this->expectedStop($process)) { $this->childFailure($process); }
                        unset($this->childErrors[spl_object_id($process)], $children[$key]);
                    }
                }
                $status = $this->jobs->workerStatus();
                $target = min($status['demand'], max(0, $status['maximum'] - $status['active'] + count($children)));
                if (!$children && !$target) {
                    // Also schedules due automatic syncs when the queue was empty.
                    $this->jobs->drain(1, 1);
                    if ($seconds <= 20 && !$this->jobs->workerDemand()) { break; }
                }
                while (!$this->stopping && count($children) < $target && microtime(true) < $deadline) {
                    $process = new Process([PHP_BINARY, $this->kernel->getProjectDir() . '/bin/console', 'tdbridge:process', '--batches=20', '--seconds=20', '--no-interaction'], $this->kernel->getProjectDir(), null, null, 900);
                    $processKey = spl_object_id($process);
                    $this->childErrors[$processKey] = '';
                    $process->start(function (string $type, string $buffer) use ($processKey): void {
                        if ($type === Process::ERR) { $this->childErrors[$processKey] = mb_substr($this->childErrors[$processKey] . $buffer, -4000); }
                    });
                    $children[] = $process; ++$launched;
                }
                $this->heartbeat(count($children));
                // Keep output bounded while allowing server-side diagnostics for a failed boot.
                foreach ($children as $process) {
                    if ($process->isRunning()) { $process->clearOutput(); $process->clearErrorOutput(); }
                }
                if ($report) { $report(['workers' => count($children), 'maximum' => $status['maximum'], 'demand' => $status['demand']]); }
                if (!$this->stopping && microtime(true) < $deadline) { usleep(500000); }
            } while (!$this->stopping && microtime(true) < $deadline);
            // Drain in-flight requests. Do not kill an import merely to scale down.
            foreach ($children as $process) {
                try { $code = $process->wait(); }
                catch (\Symfony\Component\Process\Exception\ProcessSignaledException $e) {
                    if (!$this->expectedStop($process)) { throw $e; }
                    $code = 0;
                }
                if ($code !== 0 && !$this->expectedStop($process)) { $this->childFailure($process); }
            }
            return ['mode' => 'adaptive', 'launched' => $launched, 'stopped' => $this->stopping];
        } catch (\Throwable $e) {
            foreach ($children as $process) {
                if ($process->isRunning()) { try { $process->wait(); } catch (\Throwable) {} }
            }
            throw $e;
        } finally {
            foreach ($children as $process) { if ($process->isRunning()) { $process->stop(5); } }
            $this->heartbeat(0);
            $this->db->fetchOne("SELECT RELEASE_LOCK('tdbridge.pool')");
            $this->childErrors = [];
        }
    }
    private function expectedStop(Process $process): bool
    {
        if (!$this->stopping) { return false; }
        return in_array($process->getExitCode(), [130, 143], true)
            || ($process->hasBeenSignaled() && in_array($process->getTermSignal(), [2, 15], true));
    }
    private function childFailure(Process $process): never
    {
        $this->logger?->error('LFINFO Partner Bridge child worker failed.', ['exitCode' => $process->getExitCode(), 'stderr' => $this->childErrors[spl_object_id($process)] ?? mb_substr($process->getErrorOutput(), -4000)]);
        throw new \RuntimeException('Un worker PHP a échoué (code ' . ($process->getExitCode() ?? 'inconnu') . '). Vérifiez les journaux Shopware.');
    }
    private function heartbeat(int $workers): void
    {
        $this->db->executeStatement('UPDATE td_bridge_worker_state SET pool_heartbeat = UTC_TIMESTAMP(3), pool_workers = ? WHERE id = 1', [$workers]);
    }
}
