<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1793061000SupplierOffers extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1793061000; }
    public function update(Connection $connection): void
    {
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lf_supplier_detached (
 supplier VARCHAR(32) NOT NULL,
 part_number VARCHAR(100) NOT NULL,
 detached_at DATETIME(3) NOT NULL,
 PRIMARY KEY (supplier,part_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lf_supplier_offer (
 supplier VARCHAR(32) NOT NULL,
 part_number VARCHAR(100) NOT NULL,
 name VARCHAR(255) NOT NULL,
 manufacturer VARCHAR(255) NULL,
 manufacturer_number VARCHAR(255) NULL,
 ean VARCHAR(14) NULL,
 cost DECIMAL(18,6) NULL,
 currency VARCHAR(3) NOT NULL,
 stock INT NULL,
 product_id BINARY(16) NULL,
 sync_enabled TINYINT(1) NOT NULL DEFAULT 0,
 observed_at DATETIME(3) NOT NULL,
 next_sync_at DATETIME(3) NOT NULL,
 last_synced_at DATETIME(3) NULL,
 last_error VARCHAR(500) NULL,
 PRIMARY KEY (supplier, part_number),
 KEY idx_lf_supplier_product (product_id),
 KEY idx_lf_supplier_due (sync_enabled, next_sync_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        // Explicit selection: one supplier controls a product, other offers remain comparable.
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS lf_supplier_source (
 product_id BINARY(16) NOT NULL PRIMARY KEY,
 supplier VARCHAR(32) NOT NULL,
 part_number VARCHAR(100) NOT NULL,
 updated_at DATETIME(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        // Snapshot legacy tasks too: a deletion after upgrade cannot turn an old
        // queued re-import into a request to recreate the deleted native product.
        foreach ($connection->fetchAllAssociative("SELECT id,parts,options FROM td_bridge_job WHERE status IN ('queued','running')") as $job) {
            $options = json_decode($job['options'], true, 512, JSON_THROW_ON_ERROR);
            if (isset($options['_linkedProducts'])) { continue; }
            $parts = json_decode($job['parts'], true, 512, JSON_THROW_ON_ERROR);
            $options['supplier'] = 'tdsynnex';
            $options['_linkedProducts'] = $parts ? $connection->fetchAllKeyValue('SELECT part_number,LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number IN (' . implode(',',array_fill(0,count($parts),'?')) . ')',$parts) : [];
            $connection->update('td_bridge_job',['options'=>json_encode($options,JSON_THROW_ON_ERROR)],['id'=>$job['id']]);
        }
    }
    public function updateDestructive(Connection $connection): void {}
}
