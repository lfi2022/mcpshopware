import template from './page.html.twig';
import './style.scss';

export const pageDefinition = {
    template,
    inject: ['loginService', 'acl'],
    mixins: [Shopware.Mixin.getByName('notification')],
    data() {
        return {
            catalogueSupplier: 'tdsynnex', supplierSettings: 'tdsynnex', globalAdvanced: false, globalErrors: {}, globalQuery: {text:'',brands:'',minCost:'',maxCost:'',onlyInStock:false},
            ingramConfig: null, ingramSecret: '', ingramTest: '', ingramImportConfirm: false, ingramBasket: [], ingramResult: null, ingramSearchKey: '',
            ingramQuery: {text:'',brands:'',vendorPartNumbers:'',category:'',type:'IM::physical',minCost:'',maxCost:'',minStock:'',onlyInStock:false},
            copacoConfig: null, copacoPassword: '', copacoState: {}, offerImport: null, providers: [], offers: { items: [], total: 0, page: 1 }, offerTerm: '', offerFilters: {classes:'',brands:'',minCost:'',maxCost:'',onlyInStock:false,notImported:false},
            feedCsv: '', feedDelimiter: ';', feedPreview: null, feedFilename: '',
            feedMapping: JSON.stringify({partNumber:'reference',name:'name',cost:'cost',currency:'currency',stock:'stock',manufacturer:'brand',manufacturerNumber:'mpn',ean:'ean'}, null, 2),
            binding: { supplier: 'tdsynnex', partNumber: '', productId: null, enabled: false }, bindingConfirmed: false,
            tab: 'overview', busy: false, loading: false, error: '', notice: '', connection: '',
            stats: {}, settings: null, secret: '', mappingText: '', raw: null,
            cacheState: { scopes: [], indexed: 0 }, cacheBrands: '', cacheFull: false, cacheConfirm: false,
            syncAllConfirm: false, syncAllSummary: null,
            icecatMissingConfirm: false, icecatMissingSummary: null, workers: { active: 0, maximum: 2, state: null },
            icecatApiToken: '', icecatContentToken: '', icecatPreview: null, icecatPart: '',
            query: { mode: 'browse', text: '', brands: '', classes: '', subclasses: '', minCost: '', maxCost: '', minStock: '', hasPrice: false, notImported: false, field: 'manufacturer', value: '', page: 1, pageSize: 25, onlyInStock: false, includeStock: true, includePrice: true, productStatusCode: '', modifiedFrom: '', modifiedTo: '', createdFrom: '', createdTo: '', eolDateFrom: '', eolDateTo: '', includePricePerQuantity: false, includeOutlet: false, includeEndUserPrice: false },
            lastSearchKey: '', catalogueFacets: { classes: [], brands: [] },
            browseMatches: [], browseCursor: null, browseScanned: 0, browseComplete: false, browseStopped: false, browseTruncated: false,
            catalogue: [], catalogueTotal: null, searched: false, basket: [], detail: null, confirmImport: false,
            list: { items: [], total: 0, page: 1, pageSize: 25 }, listTerm: '', listPage: 1,
            documentQuery: { Page: 1, PageSize: 20, IncludeDetails: false, SortDirection: 'DESC' },
            documentFields: {}, documentResult: null, timer: null, previousFocus: null,
            fields: [
                { value: 'manufacturer', label: 'Fabricant' }, { value: 'tdsynnexPartNumber', label: 'Référence TD SYNNEX' },
                { value: 'manufPartNumber', label: 'Référence fabricant' }, { value: 'upcEan', label: 'Code EAN / UPC' },
                { value: 'customerPartNumber', label: 'Référence revendeur' }, { value: 'class', label: 'Classe produit' },
                { value: 'subclass', label: 'Sous-classe produit' }, { value: '', label: 'Tout le catalogue' },
            ],
        };
    },
    computed: {
        modalOpen() { return this.ingramImportConfirm || this.offerImport !== null || this.detail !== null || this.confirmImport || this.raw !== null || this.cacheConfirm || this.syncAllConfirm || this.icecatMissingConfirm; },
        canEdit() { return this.acl.can('td_bridge.editor'); },
        canConfigure() { return this.acl.can('td_bridge.configure'); },
        canDocuments() { return this.acl.can('td_bridge.documents'); },
        tabs() {
            return [
                { id: 'overview', label: 'Vue d’ensemble' }, { id: 'catalogue', label: 'Catalogue' },
                { id: 'links', label: 'Mes produits' }, { id: 'suppliers', label: 'Fournisseurs' }, { id: 'jobs', label: 'Imports' },
                ...(this.canDocuments ? [{ id: 'orders', label: 'Commandes TD' }, { id: 'invoices', label: 'Factures TD' }] : []),
                { id: 'logs', label: 'Journal' }, ...(this.canConfigure ? [{ id: 'settings', label: 'Paramètres' }] : []),
            ];
        },
        allSelected() { return this.catalogue.length > 0 && this.catalogue.every(p => this.basket.some(b => b.partNumber === p.partNumber)); },
        catalogueHasNext() { if (this.query.mode === 'browse') return this.query.page * this.query.pageSize < this.browseMatches.length; return this.catalogueTotal === null ? this.catalogue.length === this.query.pageSize : this.query.page * this.query.pageSize < this.catalogueTotal; },
        documentRows() {
            if (Array.isArray(this.documentResult)) return this.documentResult;
            if (!this.documentResult) return [];
            return Object.values(this.documentResult).find(v => Array.isArray(v)) || [];
        },
        documentColumns() { return this.documentRows.length ? Object.keys(this.documentRows[0]).filter(k => this.documentRows.some(r => r[k] === null || typeof r[k] !== 'object')).slice(0, 7) : []; },
        listHasNext() { return this.listPage * this.list.pageSize < this.list.total; },
        dates() { return [{ key: 'modifiedFrom', label: 'Modifié depuis' }, { key: 'modifiedTo', label: 'Modifié jusqu’au' }, { key: 'createdFrom', label: 'Créé depuis' }, { key: 'createdTo', label: 'Créé jusqu’au' }, { key: 'eolDateFrom', label: 'Fin de vie depuis' }, { key: 'eolDateTo', label: 'Fin de vie jusqu’au' }]; },
        documentFilterKeys() {
            return this.tab === 'orders'
                ? ['CustomerOrderNumber', 'TdsynnexOrderNumber', 'InvoiceNumber', 'DeliveryNoteNumber', 'TdsynnexPartNumber', 'ManufPartNumber', 'Manufacturer', 'CreatedFrom', 'CreatedTo', 'ModifiedFrom', 'ModifiedTo', 'EtaDateFrom', 'EtaDateTo']
                : ['InvoiceNumber', 'CustomerOrderNumber', 'TdsynnexOrderNumber', 'DeliveryNoteNumber', 'EndUserOrderNumber', 'BillingDateFrom', 'BillingDateTo', 'CreatedFrom', 'CreatedTo', 'ModifiedFrom', 'ModifiedTo', 'DueDateFrom', 'DueDateTo'];
        },
    },
    watch: {
        feedMapping() { this.feedPreview = null; },
        feedDelimiter() { this.feedPreview = null; },
        modalOpen(open) {
            if (open) {
                this.previousFocus = document.activeElement;
                this.$nextTick(() => document.querySelector('.td-modal button, .td-modal a, .td-modal input')?.focus());
            } else { this.previousFocus?.focus?.(); this.previousFocus = null; }
        },
    },
    created() {
        document.addEventListener('keydown', this.modalKeyboard);
        this.refresh();
        this.timer = setInterval(() => {
            if (this.busy || this.loading || (typeof document !== 'undefined' && document.hidden)) return;
            if (['overview', 'jobs', 'catalogue', 'links', 'suppliers', 'copaco', 'ingram'].includes(this.tab)) this.refresh(true);
        }, 15000);
    },
    beforeUnmount() { this.browseStopped = true; clearInterval(this.timer); document.removeEventListener('keydown', this.modalKeyboard); },
    methods: {
        async selectCatalogue(supplier) {
            this.catalogueSupplier = supplier; this.error = ''; this.notice = '';
            await this.refresh();
        },
        async configureSupplier(supplier) { this.supplierSettings=supplier; await this.changeTab('suppliers'); },
        async searchGlobal() {
            await this.work(async () => {
                this.globalErrors={};
                const q={...this.globalQuery};
                Object.assign(this.query,q,{mode:'browse',page:1});
                Object.assign(this.ingramQuery,q);
                this.offerTerm=q.text; Object.assign(this.offerFilters,{brands:q.brands,minCost:q.minCost,maxCost:q.maxCost,onlyInStock:q.onlyInStock});
                if (!this.globalAdvanced) {
                    Object.assign(this.query,{subclasses:'',minStock:'',hasPrice:false,notImported:false,productStatusCode:''});
                    Object.assign(this.offerFilters,{notImported:false});
                    Object.assign(this.ingramQuery,{vendorPartNumbers:'',type:'IM::physical',minStock:''});
                }
                this.catalogue=[]; this.browseMatches=[]; this.browseCursor=null; this.browseScanned=0; this.browseComplete=false; this.lastSearchKey=''; this.searched=false; this.catalogueTotal=null;
                this.offers={items:[],total:0,page:1}; this.ingramResult=null;
                // Independent read-only sources. Never reuse failed results from an earlier search.
                const ids=['tdsynnex','copaco','ingram'];
                const results=await Promise.allSettled([
                    this.browseSearch(1), this.loadOffers(1),
                    (async()=>{const key=JSON.stringify(this.ingramQuery); const result=await this.api('ingram/catalogue',{...this.ingramQuery,page:1,pageSize:25});this.ingramResult=result;this.ingramSearchKey=key;})(),
                ]);
                results.forEach((result,i)=>{if(result.status==='rejected')this.globalErrors[ids[i]]=this.message(result.reason);});
            });
        },
        providerName(id) {return ({tdsynnex:'TD SYNNEX',copaco:'Copaco',ingram:'Ingram Micro'})[id] || id || 'TD SYNNEX';},
        async saveIngram() { await this.work(async()=> {await this.api('ingram/settings',{...this.ingramConfig,clientSecret:this.ingramSecret});this.ingramSecret='';this.ingramConfig=await this.api('ingram/settings');this.ingramResult=null;this.ingramBasket=[];this.ingramTest='';this.notice='Configuration Ingram Micro enregistrée.';}); },
        async testIngram() {await this.work(async()=>{this.ingramTest=(await this.api('ingram/test',{})).message;});},
        async searchIngram(page=1) {await this.work(async()=>{const key=JSON.stringify(this.ingramQuery);if(key!==this.ingramSearchKey)page=1;const result=await this.api('ingram/catalogue',{...this.ingramQuery,page,pageSize:25});this.ingramResult=result;this.ingramSearchKey=key;});},
        toggleIngram(item) { if(this.ingramResult?.environment!=='production'||!item.authorized)return;const i=this.ingramBasket.findIndex(x=>x.partNumber===item.partNumber);if(i>=0)this.ingramBasket.splice(i,1);else if(this.ingramBasket.length<500)this.ingramBasket.push(item);else this.error='Maximum 500 références par sélection.'; },
        async importIngram() {await this.work(async()=>{const r=await this.api('supplier-sync',{supplier:'ingram',parts:this.ingramBasket.map(x=>x.partNumber),type:'import'});this.ingramImportConfirm=false;this.ingramBasket=[];this.notice='Import Ingram planifié : '+r.id;});},
        async chooseIngram(item) {this.binding={supplier:'ingram',partNumber:item.partNumber,productId:null,enabled:false};this.bindingConfirmed=false;await this.changeTab('suppliers');},
        async saveCopaco() { await this.work(async()=> { await this.api('copaco/settings', {...this.copacoConfig,password:this.copacoPassword}); this.copacoPassword='';this.copacoConfig=await this.api('copaco/settings');this.notice='Configuration Datafile Copaco enregistrée.'; }); },
        async requestCopaco() { await this.work(async()=> { this.copacoState=await this.api('copaco/refresh',{});this.notice='Chargement du catalogue demandé. Le worker le traitera dès son prochain passage. Aucun produit boutique ne sera créé.'; }); },
        async loadOffers(page = 1) { this.offers = await this.api('supplier-offers', { supplier: 'copaco', term: this.offerTerm, page, ...this.offerFilters }); },
        async readFeed(event) {
            this.feedPreview = null; this.feedCsv = ''; const file = event.target.files?.[0];
            if (!file) return;
            if (file.size > 2000000) { this.error = 'Fichier limité à 2 Mo.'; return; }
            this.feedCsv = await file.text(); this.feedFilename = file.name;
        },
        async previewFeed() { await this.work(async () => { this.feedPreview = await this.api('supplier-feed/preview', { supplier:'copaco', csv:this.feedCsv, delimiter:this.feedDelimiter, mapping:JSON.parse(this.feedMapping) }); }); },
        async commitFeed() { await this.work(async () => { const r = await this.api('supplier-feed/commit', { supplier:'copaco', csv:this.feedCsv, delimiter:this.feedDelimiter, mapping:JSON.parse(this.feedMapping) }); this.notice = r.total + ' offres enregistrées. Aucun produit Shopware créé ou modifié.'; this.feedPreview = null; await this.loadOffers(); }); },
        async chooseOffer(offer) { this.binding = { supplier:'copaco', partNumber:offer.part_number, productId:offer.product_id || null, enabled:false }; this.bindingConfirmed = false; await this.changeTab('suppliers'); },
        async saveBinding() { if (!this.bindingConfirmed) return; await this.work(async () => { await this.api(this.binding.supplier==='ingram'?'ingram/link':'supplier-bind', this.binding); this.notice = 'Liaison enregistrée. La synchronisation peut être lancée.'; this.bindingConfirmed = false; await this.refresh(); }); },
        async submitOfferImport() { const selected = this.offerImport; await this.work(async () => { const r = await this.api('supplier-sync', {supplier:'copaco',parts:[selected.part_number],type:'import'}); this.offerImport = null; this.notice = 'Import planifié : ' + r.id; }); },
        async confirmOfferImport(offer) {
            this.offerImport = offer;
        },
        async syncOffer(offer, type = 'sync') { await this.work(async () => { const r = await this.api('supplier-sync', { supplier:'copaco', parts:[offer.part_number], type }); this.notice = 'Tâche créée : ' + r.id; }); },
        async reconcileProducts() { await this.work(async () => { const r = await this.api('reconcile-products', {}); this.notice = r.removedTdLinks + ' liaisons TD retirées ; ' + r.detachedOffers + ' offres déliées.'; await this.refresh(); }); },
        modalKeyboard(event) {
            if (!this.modalOpen) return;
            if (event.key === 'Escape' && !this.busy) { this.ingramImportConfirm=false;this.offerImport = null; this.detail = null; this.raw = null; this.confirmImport = false; this.cacheConfirm = false; this.syncAllConfirm = false; this.icecatMissingConfirm = false; event.preventDefault(); }
            if (event.key !== 'Tab') return;
            const targets = [...document.querySelectorAll('.td-modal button:not(:disabled), .td-modal a, .td-modal input, .td-modal select, .td-modal textarea')];
            const first = targets[0], last = targets[targets.length - 1];
            if (event.shiftKey && document.activeElement === first) { last?.focus(); event.preventDefault(); }
            else if (!event.shiftKey && document.activeElement === last) { first?.focus(); event.preventDefault(); }
        },
        async api(path, data = undefined, method = undefined) {
            const http = Shopware.Application.getContainer('init').httpClient;
            const headers = { Authorization: `Bearer ${this.loginService.getToken()}`, 'Content-Type': 'application/json' };
            const response = await http.request({ url: `_action/td-bridge/${path}`, method: method || (data === undefined ? 'GET' : 'POST'), data, headers });
            return response.data;
        },
        message(e) { return e?.response?.data?.errors?.[0]?.detail || e?.message || 'La requête a échoué.'; },
        async work(fn) {
            if (this.busy) return;
            this.busy = true; this.error = ''; this.notice = '';
            try { return await fn(); } catch (e) { this.error = this.message(e); return undefined; } finally { this.busy = false; }
        },
        async refresh(silent = false) {
            if (this.loading) return;
            this.loading = true;
            try {
                this.stats = await this.api('stats');
                if (['links', 'jobs', 'logs'].includes(this.tab)) await this.loadList();
                if (['links', 'jobs'].includes(this.tab)) this.workers = await this.api('workers');
                if (this.tab === 'suppliers') this.providers = (await this.api('suppliers')).items;
                if (this.tab === 'catalogue' && ['copaco','all'].includes(this.catalogueSupplier)) { this.copacoState = await this.api('copaco/status'); await this.loadOffers(this.offers.page || 1); }
                if (this.tab === 'catalogue' && ['tdsynnex','all'].includes(this.catalogueSupplier)) { this.cacheState = await this.api('supplier-cache'); await this.loadFacets(); }
            } catch (e) { if (!silent) this.error = this.message(e); } finally { this.loading = false; }
        },
        async changeTab(tab) {
            if (['copaco','ingram'].includes(tab)) { this.catalogueSupplier=tab; tab='catalogue'; }
            this.list = { items: [], total: 0, page: 1, pageSize: 25 };
            this.tab = tab; this.error = ''; this.notice = ''; this.listPage = 1; this.listTerm = ''; this.detail = null;
            this.documentResult = null; this.documentFields = {}; this.documentQuery = { Page: 1, PageSize: 20, IncludeDetails: false, SortDirection: 'DESC' };
            if (['settings','suppliers'].includes(tab) && this.canConfigure) await this.work(async () => {
                if (!this.settings) { this.settings = await this.api('settings'); this.mappingText = JSON.stringify(this.settings.mapping, null, 2); }
                if (!this.copacoConfig) this.copacoConfig = await this.api('copaco/settings');
                if (!this.ingramConfig) this.ingramConfig = await this.api('ingram/settings');
                if (tab === 'suppliers') { this.providers=(await this.api('suppliers')).items; this.copacoState=await this.api('copaco/status'); }
            });
            else await this.refresh();
        },
        buildCriteria() {
            if (['browse', 'cache'].includes(this.query.mode)) {
                const keys = ['text', 'brands', 'classes', 'subclasses', 'minCost', 'maxCost', 'minStock', 'hasPrice', 'notImported', 'onlyInStock', 'productStatusCode', 'page', 'pageSize'];
                return { mode: this.query.mode, ...Object.fromEntries(keys.map(key => [key, this.query[key]])) };
            }
            const { field, value } = this.query;
            const keys = ['page', 'pageSize', 'onlyInStock', 'includeStock', 'includePrice', 'productStatusCode', 'modifiedFrom', 'modifiedTo', 'createdFrom', 'createdTo', 'eolDateFrom', 'eolDateTo', 'includePricePerQuantity', 'includeOutlet', 'includeEndUserPrice'];
            const criteria = Object.fromEntries(keys.map(key => [key, this.query[key]]));
            if (field && value.trim()) criteria[field] = ['manufacturer', 'class', 'subclass'].includes(field) ? value.trim() : value.split(/[\n,;]+/).map(v => v.trim()).filter(Boolean);
            return criteria;
        },
        async switchSearchMode(mode) {
            this.query.mode = mode; this.catalogue = []; this.catalogueTotal = null; this.searched = false; this.query.page = 1; this.lastSearchKey = '';
            this.error = ''; await this.refresh();
        },
        async quickFilter(key) {
            if (key === 'active') this.query.productStatusCode = this.query.productStatusCode === 'Active' ? '' : 'Active';
            else this.query[key] = !this.query[key];
            await this.search(1);
        },
        async loadFacets() {
            const facets = await this.api('catalogue-facets', { mode: this.query.mode, brands: this.query.brands });
            if (Array.isArray(facets.classes) && Array.isArray(facets.brands)) {
                facets.classes = facets.classes.map(c => ({ ...c, label: (c.label || c.value) + (facets.countsAvailable ? ` (${c.count})` : '') }));
                this.catalogueFacets = facets;
            }
        },
        async categoryChanged() { this.query.subclasses = ''; await this.search(1); },
        async quickCategory(code) {
            this.query.classes = this.query.classes === code ? '' : code;
            await this.categoryChanged();
        },
        async addBrand(brand) {
            const brands = this.query.brands.split(/[;\r\n]+/).map(v => v.trim()).filter(Boolean);
            if (!brands.some(v => v.toLowerCase() === brand.toLowerCase())) brands.push(brand);
            this.query.brands = brands.join(' ; '); await this.search(1);
        },
        async resetFilters() {
            Object.assign(this.query, { text: '', brands: '', classes: '', subclasses: '', minCost: '', maxCost: '', minStock: '', hasPrice: false, notImported: false, onlyInStock: false, productStatusCode: '', page: 1 });
            await this.search(1);
        },
        async browseSearch(page, more = false) {
            const criteria = { ...this.buildCriteria(), page: 1 };
            const key = JSON.stringify({ ...criteria, page: 1 });
            if (key !== this.lastSearchKey) {
                this.browseMatches = []; this.browseCursor = null; this.browseScanned = 0; this.browseComplete = false; this.browseTruncated = false;
                this.catalogue = []; this.catalogueTotal = null; this.searched = false; page = 1;
            }
            this.lastSearchKey = key; this.browseStopped = false;
            const target = more ? this.browseMatches.length + this.query.pageSize : page * this.query.pageSize;
            const brandCount = Math.max(1, new Set(criteria.brands.split(/[;\r\n]+/).map(v => v.trim().toLowerCase()).filter(Boolean)).size);
            const minimumCalls = more || this.browseScanned === 0 ? Math.min(4, brandCount) : 0;
            let calls = 0;
            while (!this.browseComplete && !this.browseStopped && calls < 4 && this.browseMatches.length < 1000 && (calls < minimumCalls || this.browseMatches.length < target)) {
                const result = await this.api('catalogue', { ...criteria, scanCursor: this.browseCursor });
                if (JSON.stringify({ ...this.buildCriteria(), page: 1 }) !== key) { this.browseStopped = true; break; }
                const combined = new Map(this.browseMatches.map(item => [item.partNumber, item]));
                for (const item of result.items) combined.set(item.partNumber, item);
                this.browseTruncated = combined.size > 1000;
                this.browseMatches = [...combined.values()].slice(0, 1000);
                this.browseCursor = result.scanCursor || null;
                this.browseScanned = result.scanned ?? this.browseScanned + result.items.length;
                this.browseComplete = !result.hasMore && !this.browseTruncated;
                calls++;
                this.searched = true;
                this.catalogue = this.browseMatches.slice((page - 1) * this.query.pageSize, page * this.query.pageSize);
            }
            this.query.page = Math.min(page, Math.max(1, Math.ceil(this.browseMatches.length / this.query.pageSize)));
            this.catalogue = this.browseMatches.slice((this.query.page - 1) * this.query.pageSize, this.query.page * this.query.pageSize);
            this.catalogueTotal = this.browseComplete ? this.browseMatches.length : null;
            this.searched = true;
        },
        async search(page = 1, more = false) {
            await this.work(async () => {
                const previous = this.query.page; this.query.page = page;
                try {
                    if (this.query.mode === 'browse') { await this.browseSearch(page, more); return; }
                    const key = JSON.stringify({ ...this.buildCriteria(), page: 1 });
                    if (key !== this.lastSearchKey) this.query.page = 1;
                    const result = await this.api('catalogue', this.buildCriteria());
                    this.catalogue = result.items; this.catalogueTotal = result.total; this.searched = true; this.lastSearchKey = key;
                    if (this.query.mode === 'cache') { this.cacheState = result.coverage || this.cacheState; await this.loadFacets(); }
                } catch (e) { this.query.page = previous; throw e; }
            });
        },
        isSelected(product) { return this.basket.some(p => p.partNumber === product.partNumber); },
        toggle(product) {
            if (this.isSelected(product)) this.basket = this.basket.filter(p => p.partNumber !== product.partNumber);
            else if (this.basket.length < 500) this.basket.push(product);
            else this.error = 'La sélection est limitée à 500 références par tâche.';
        },
        togglePage() {
            if (this.allSelected) this.basket = this.basket.filter(p => !this.catalogue.some(c => c.partNumber === p.partNumber));
            else this.catalogue.forEach(p => { if (!this.isSelected(p)) this.toggle(p); });
        },
        async submitImport() {
            await this.work(async () => {
                const result = await this.api('import', { parts: this.basket.map(p => p.partNumber) });
                this.confirmImport = false; this.basket = []; this.list = { items: [], total: 0, page: 1, pageSize: 25 }; this.tab = 'jobs'; this.listPage = 1; this.listTerm = '';
                this.notice = `Import créé : ${result.id}. Le traitement s’effectue en arrière-plan.`;
                await this.refresh();
            });
        },
        async loadList() {
            this.list = await this.api(`list/${this.tab}?page=${this.listPage}&term=${encodeURIComponent(this.listTerm)}`);
        },
        async listSearch() { this.listPage = 1; await this.work(() => this.loadList()); },
        async listNavigate(delta) { await this.work(async () => { const previous = this.listPage; this.listPage += delta; try { await this.loadList(); } catch (e) { this.listPage = previous; throw e; } }); },
        async process() {
            await this.work(async () => {
                const result = await this.api('process', {});
                this.notice = result.state === 'busy' ? 'Un traitement est déjà en cours.' : `Lot traité : ${this.status(result.state)}.`;
                await this.refresh();
            });
        },
        async jobAction(job, action) { await this.work(async () => { await this.api(`jobs/${job.id}/${action}`, {}); await this.refresh(); }); },
        async toggleSync(product) { await this.work(async () => { await this.api('supplier-bind', { supplier:product.supplier || 'tdsynnex', partNumber: product.part_number, productId:product.product_id, enabled: !Number(product.sync_enabled) }); await this.refresh(); }); },
        async syncProduct(product) { await this.work(async () => { await this.api('supplier-sync', { supplier:product.supplier || 'tdsynnex', parts: [product.part_number], type: 'sync' }); this.notice = 'Synchronisation ajoutée à la file.'; await this.refresh(); }); },
        async prepareSyncAll() {
            await this.work(async () => { this.syncAllSummary = await this.api('sync-all'); this.syncAllConfirm = true; });
        },
        async prepareIcecatMissing() {
            await this.work(async () => { this.icecatMissingSummary = await this.api('icecat-missing'); this.icecatMissingConfirm = true; });
        },
        async submitIcecatMissing() {
            await this.work(async () => {
                const result = await this.api('icecat-missing', {});
                this.icecatMissingConfirm = false; this.list = { items: [], total: 0, page: 1, pageSize: 25 }; this.tab = 'jobs'; this.listPage = 1; this.listTerm = '';
                this.notice = `${result.products} produit(s) sans photo ajouté(s) à l’enrichissement Icecat, en ${result.jobs} tâche(s).`;
                await this.refresh();
            });
        },
        async submitSyncAll() {
            await this.work(async () => {
                const result = await this.api('sync-all', {});
                this.syncAllConfirm = false; this.list = { items: [], total: 0, page: 1, pageSize: 25 }; this.tab = 'jobs'; this.listPage = 1; this.listTerm = '';
                this.notice = result.products ? `${result.products} produit(s) ajouté(s) à la synchronisation, en ${result.jobs} tâche(s). Le worker les traitera en arrière-plan.` : 'Aucun produit lié avec suivi actif à synchroniser.';
                await this.refresh();
            });
        },
        async showJobLogs(job) { this.tab = 'logs'; this.listPage = 1; this.listTerm = job.id; await this.work(() => this.loadList()); },
        async saveSettings() {
            await this.work(async () => {
                let mapping;
                try { mapping = JSON.parse(this.mappingText); } catch { throw new Error('Le mapping doit être un objet JSON valide.'); }
                await this.api('settings', { ...this.settings, mapping, clientSecret: this.secret, icecatApiToken: this.icecatApiToken, icecatContentToken: this.icecatContentToken });
                this.icecatApiToken = ''; this.icecatContentToken = '';
                this.settings = await this.api('settings'); this.secret = ''; this.connection = '';
                this.notice = 'Configuration enregistrée. Les nouvelles tâches utiliseront ces réglages.';
                await this.refresh();
            });
        },
        async testConnection() { await this.work(async () => { const result = await this.api('test', {}); this.connection = result.message; }); },
        async startCache() {
            await this.work(async () => {
                this.cacheState = await this.api('supplier-cache/start', { brands: this.cacheFull ? '' : this.cacheBrands, fullCatalogue: this.cacheFull });
                this.cacheConfirm = false;
                this.notice = 'Chargement demandé. Le worker lira une page fournisseur par passage. Aucun produit Shopware créé.';
                await this.loadFacets();
            });
        },
        async cacheAction(scope, action) {
            await this.work(async () => { this.cacheState = await this.api(`supplier-cache/${action}`, { id: scope.id }); await this.loadFacets(); });
        },
        async cacheTick() {
            await this.work(async () => { await this.api('supplier-cache/tick', {}); this.cacheState = await this.api('supplier-cache'); await this.loadFacets(); });
        },
        async previewIcecat(part) {
            await this.work(async () => {
                this.icecatPreview = null; this.icecatPart = part;
                this.icecatPreview = await this.api('icecat/preview', { partNumber: part });
            });
        },
        async enrichIcecat(product) {
            await this.work(async () => {
                await this.api('supplier-sync', { supplier:product.supplier || 'tdsynnex', parts: [product.part_number], type: 'icecat' });
                this.notice = 'Enrichissement Icecat ajouté à la file. Les prix et stocks sont conservés.';
            });
        },
        async diagnose() { await this.work(async () => { this.raw = await this.api('diagnose', { page: 1, pageSize: 1, includeStock: true, includePrice: true }); }); },
        async searchDocuments(page = 1) {
            await this.work(async () => {
                const query = { ...this.documentFields, ...this.documentQuery, Page: page };
                this.documentResult = await this.api(`documents/${this.tab}`, query); this.documentQuery.Page = page;
            });
        },
        exportData(value, filename, csv = false) {
            let text;
            if (csv) {
                const columns = Object.keys(value[0] || {});
                const cell = v => { let s = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return `"${s.replaceAll('"', '""')}"`; };
                text = '\uFEFF' + [columns, ...value.map(row => columns.map(key => row[key]))].map(row => row.map(cell).join(';')).join('\r\n');
            } else text = JSON.stringify(value, null, 2);
            const url = URL.createObjectURL(new Blob([text], { type: csv ? 'text/csv;charset=utf-8' : 'application/json' }));
            const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
        },
        money(value, currency = 'EUR') { if (value === null || value === undefined) return '—'; try { return new Intl.NumberFormat('fr-BE', { style: 'currency', currency: currency || 'EUR' }).format(value); } catch { return `${value} ${currency}`; } },
        date(value) { return value ? new Date(value.includes('T') ? value : `${value.replace(' ', 'T')}Z`).toLocaleString('fr-BE') : '—'; },
        status(value) { return ({ ready: 'Prêt', paused: 'En pause', retry: 'Nouvelle tentative prévue', queued: 'En attente', running: 'En cours', completed: 'Terminé', completed_with_errors: 'Terminé avec erreurs', failed: 'Échec', cancelled: 'Annulé', idle: 'File à jour', busy: 'En cours' })[value] || value; },
        pretty(value) { return JSON.stringify(value, null, 2); },
    },
};

Shopware.Component.register('td-bridge-page', pageDefinition);
