<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use TDBridge\Domain\BridgeException;

final class CatalogueIndex
{
    public function __construct(private readonly Connection $db) {}

    public function status(): array
    {
        $state = $this->db->fetchAssociative('SELECT * FROM td_bridge_catalogue_state WHERE id = 1');
        if (!$state) { throw new BridgeException('Ancien index indisponible. Utilisez la recherche fournisseur du module.', 409); }
        $state['scopes'] = json_decode($state['scopes'], true, 512, JSON_THROW_ON_ERROR);
        $state['indexed'] = (int) $this->db->fetchOne('SELECT COUNT(*) FROM td_bridge_catalogue');
        return $state;
    }

}
