<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;

/** Connection-owned advisory locks survive long requests and vanish on a worker crash. */
final class WorkerCoordinator
{
    public function __construct(private readonly Connection $db, private readonly Settings $settings) {}
    public function maximum(): int { return max(1, min(8, (int) $this->settings->all()['workerMax'])); }
    public function demand(): int
    {
        if ($this->cooling()) { return 0; }
        return min($this->maximum(), (int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE status IN ('queued', 'running') AND available_at <= UTC_TIMESTAMP(3)"));
    }
    public function cooling(): bool { return (bool) $this->db->fetchOne('SELECT cooldown_until > UTC_TIMESTAMP(3) FROM td_bridge_worker_state WHERE id = 1'); }
    public function cooldown(int $seconds): void
    {
        $until = gmdate('Y-m-d H:i:s', time() + max(1, $seconds));
        $this->db->executeStatement('UPDATE td_bridge_worker_state SET cooldown_until = GREATEST(COALESCE(cooldown_until, ?), ?) WHERE id = 1', [$until, $until]);
    }
    public function claim(): array
    {
        if ($this->cooling()) { return ['state' => 'cooldown']; }
        $slot = null;
        for ($i = 0; $i < $this->maximum(); ++$i) {
            if ($this->lock('tdbridge.slot.' . $i)) { $slot = 'tdbridge.slot.' . $i; break; }
        }
        if ($slot === null) { return ['state' => 'busy']; }
        if (!$this->lock('tdbridge.worker')) { $this->release($slot); return ['state' => 'busy']; }
        $retain = false;
        try {
            if ($this->cooling()) { return ['state' => 'cooldown']; }
            $candidates = $this->db->fetchAllAssociative("SELECT * FROM td_bridge_job WHERE status IN ('queued', 'running') AND available_at <= UTC_TIMESTAMP(3) ORDER BY created_at, id LIMIT 1000");
            foreach ($candidates as $job) {
                $lock = 'tdbridge.job.' . $job['id'];
                if (!$this->lock($lock)) { continue; }
                try {
                    if (!$this->db->executeStatement("UPDATE td_bridge_job SET status = 'running', updated_at = UTC_TIMESTAMP(3) WHERE id = ? AND status IN ('queued', 'running')", [$job['id']])) { $this->release($lock); continue; }
                } catch (\Throwable $e) { $this->release($lock); throw $e; }
                $retain = true;
                return ['state' => 'claimed', 'job' => $job, 'locks' => [$lock, $slot]];
            }
            return ['state' => $candidates ? 'busy' : 'idle'];
        } finally {
            $this->release('tdbridge.worker');
            if (!$retain) { $this->release($slot); }
        }
    }
    public function lock(string $name): bool { return (int) $this->db->fetchOne('SELECT GET_LOCK(?, 0)', [$name]) === 1; }
    public function release(string $name): void { $this->db->fetchOne('SELECT RELEASE_LOCK(?)', [$name]); }
    public function status(): array
    {
        $active = 0;
        for ($i = 0; $i < 8; ++$i) { if ($this->db->fetchOne('SELECT IS_USED_LOCK(?)', ['tdbridge.slot.' . $i]) !== null) { ++$active; } }
        return ['maximum' => $this->maximum(), 'active' => $active, 'demand' => $this->demand(), 'state' => $this->db->fetchAssociative('SELECT * FROM td_bridge_worker_state WHERE id = 1')];
    }
}
