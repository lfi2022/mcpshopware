<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class ProductMapper
{
    public const PURCHASE_SURCHARGE_EUR = 50.0;
    public const LEGACY_MAP = [
        'items' => 'products', 'total' => 'total', 'partNumber' => 'tdsynnexPartNumber',
        'name' => 'description', 'description' => 'longDescription', 'manufacturer' => 'manufacturer',
        'manufacturerNumber' => 'manufPartNumber', 'ean' => 'upcEan',
        'stock' => 'stock.available', 'cost' => 'price.netPrice', 'currency' => 'price.currency',
    ];

    public const DEFAULT_MAP = [
        'items' => 'data', 'total' => 'totalResults', 'partNumber' => 'tdsynnexPartNumber',
        'name' => 'productDescription', 'description' => 'productDescription', 'manufacturer' => 'manufacturer',
        'manufacturerNumber' => 'manufPartNumber', 'ean' => 'upcEan',
        'stock' => 'stock.quantityAvailableTotal', 'cost' => 'price.customerPrice', 'currency' => 'price.currencyCode',
        'class' => 'class', 'subclass' => 'subclass', 'status' => 'productStatusCode',
    ];

    public static function path(array $data, string $path): mixed
    {
        if ($path === '') { return $data; }
        $value = $data;
        foreach (explode('.', $path) as $key) {
            if (!is_array($value) || !array_key_exists($key, $value)) { return null; }
            $value = $value[$key];
        }
        return $value;
    }

    public function catalogue(array $response, array $mapping): array
    {
        $map = array_replace(self::DEFAULT_MAP, $mapping);
        $rows = self::path($response, $map['items']);
        if (!is_array($rows) || !array_is_list($rows)) { throw new BridgeException('La liste de produits est introuvable. Vérifiez le chemin « items » du mapping.', 422); }
        $items = [];
        foreach ($rows as $row) {
            if (!is_array($row)) { throw new BridgeException('Structure produit inattendue.', 422); }
            $item = [];
            foreach ($map as $key => $path) {
                if (in_array($key, ['items', 'total'], true)) { continue; }
                $item[$key] = self::path($row, $path);
            }
            foreach (['partNumber', 'name', 'description', 'manufacturer', 'manufacturerNumber', 'ean', 'currency', 'class', 'subclass', 'status'] as $field) {
                if ($item[$field] !== null && !is_scalar($item[$field])) { throw new BridgeException("Mapping $field : une valeur simple est attendue.", 422); }
                $item[$field] = $item[$field] === null ? null : trim((string) $item[$field]);
            }
            if (!$item['partNumber'] || strlen($item['partNumber']) > 100) { throw new BridgeException('Référence TD absente ou trop longue. Corrigez le mapping.', 422); }
            // Missing stock is never silently converted to zero; missing price is never made free.
            $item['stock'] = self::number($item['stock'], true);
            $item['cost'] = self::number($item['cost'], false);
            $items[] = $item;
        }
        $total = self::path($response, $map['total']);
        return ['items' => $items, 'total' => is_numeric($total) && (int) $total >= 0 ? (int) $total : null];
    }

    private static function number(mixed $value, bool $integer): int|float|null
    {
        if ($value === null || $value === '') { return null; }
        if (!is_numeric($value) || !is_finite((float) $value) || (float) $value < 0 || ($integer && (floor((float) $value) !== (float) $value || (float) $value > 2147483647))) { throw new BridgeException('Prix ou stock invalide dans la réponse fournisseur.', 422); }
        return $integer ? (int) $value : (float) $value;
    }

    public static function sellingPrice(float $cost, float $markup, float $fixed, float $tax): array
    {
        $net = round($cost * (1 + $markup / 100) + $fixed, 2);
        if (!is_finite($net) || $net <= 0 || $net > 100000000) { throw new BridgeException('Prix de vente invalide ; import refusé.'); }
        return ['net' => $net, 'gross' => round($net * (1 + $tax / 100), 2)];
    }

    public static function purchasePrice(float $supplierCost, float $tax, string $currency): array
    {
        if (strtoupper($currency) !== 'EUR') { throw new BridgeException('Le forfait d’achat de 50 EUR nécessite une devise fournisseur EUR. Aucune conversion automatique.'); }
        $net = round($supplierCost + self::PURCHASE_SURCHARGE_EUR, 6);
        if (!is_finite($supplierCost) || $supplierCost <= 0 || !is_finite($net) || $net > 100000000) { throw new BridgeException('Coût fournisseur invalide : prix d’achat refusé.'); }
        return ['net' => $net, 'gross' => round($net * (1 + $tax / 100), 2)];
    }
}
