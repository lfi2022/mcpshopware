<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class IcecatContent
{
    public static function map(array $data): array
    {
        $general = $data['GeneralInfo'] ?? [];
        $plain = static fn (mixed $value): string => is_scalar($value) ? trim(html_entity_decode(strip_tags(preg_replace('/<br\s*\/?\s*>|<\/p>/i', "\n", (string) $value)), ENT_QUOTES | ENT_HTML5, 'UTF-8')) : '';
        $features = [];
        foreach ($data['FeaturesGroups'] ?? [] as $group) {
            foreach ($group['Features'] ?? [] as $feature) {
                $name = $plain($feature['Feature']['Name']['Value'] ?? '');
                $value = $plain($feature['PresentationValue'] ?? $feature['Value'] ?? '');
                if ($name !== '' && $value !== '') { $features[] = ['group' => $plain($group['FeatureGroup']['Name']['Value'] ?? ''), 'name' => $name, 'value' => $value]; }
                if (count($features) >= 500) { break 2; }
            }
        }
        $images = [];
        foreach (array_merge([$data['Image'] ?? []], $data['Gallery'] ?? []) as $image) {
            $url = $image['HighPic'] ?? $image['Pic500x500'] ?? '';
            if (is_string($url) && $url !== '') { $images[$url] = $url; }
        }
        return ['id' => (string) ($general['IcecatId'] ?? ''), 'title' => $plain($general['Title'] ?? ''), 'brand' => $plain($general['Brand'] ?? ''), 'mpn' => $plain($general['BrandPartCode'] ?? ''),
            'description' => $plain($general['Description']['LongDesc'] ?? ''), 'language' => $plain($general['Description']['Language'] ?? ''), 'features' => $features, 'images' => array_slice(array_values($images), 0, 8), 'demo' => (bool) ($data['DemoAccount'] ?? false)];
    }

    public static function description(array $content, array $options): string
    {
        $escape = static fn (string $v): string => htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $html = ($options['icecatDescription'] ?? true) && $content['description'] !== '' ? '<p>' . nl2br($escape($content['description'])) . '</p>' : '';
        if (($options['icecatSpecs'] ?? true) && $content['features']) {
            $html .= '<h3>Caractéristiques techniques</h3><table><tbody>';
            foreach ($content['features'] as $feature) { $html .= '<tr><th>' . $escape(($feature['group'] ? $feature['group'] . ' — ' : '') . $feature['name']) . '</th><td>' . $escape($feature['value']) . '</td></tr>'; }
            $html .= '</tbody></table>';
        }
        return $html;
    }
}
