<?php declare(strict_types=1);

namespace TDBridge\Domain;

final class IngramMapper
{
    public static function product(array $p,array $catalog=[]): array
    {
        $part=self::text($p['ingramPartNumber']??null,100);if($part===''){throw new BridgeException('Référence Ingram absente de la réponse.');}
        $cost=self::number($p['pricing']['customerPrice']??null,false);$stock=self::number($p['availability']['totalAvailability']??null,true);
        $ean=self::text($p['upc']??$catalog['upcCode']??'',100);if(!preg_match('/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/D',$ean)){$ean=null;}
        $authorized=$p['productAuthorized']??$catalog['authorizedToPurchase']??null;
        if($authorized!==null&&!in_array($authorized,[true,false,'true','false','True','False','Y','N'],true)){throw new BridgeException('Indicateur d’autorisation Ingram non reconnu.');}
        $name=self::text($p['description']??$catalog['description']??$part,200000);
        return ['partNumber'=>$part,'name'=>mb_substr($name?:$part,0,255),'description'=>$name?:null,'manufacturer'=>self::text($p['vendorName']??$catalog['vendorName']??'',255)?:null,
            'manufacturerNumber'=>self::text($p['vendorPartNumber']??$catalog['vendorPartNumber']??'',255)?:null,'ean'=>$ean,'cost'=>$cost,'currency'=>strtoupper(self::text($p['pricing']['currencyCode']??'',3)),
            'stock'=>$stock===null?null:(int)$stock,'class'=>self::text($catalog['category']??'',100),'subclass'=>self::text($catalog['subCategory']??'',100),
            'status'=>self::text($p['productStatus']??$p['productStatusCode']??'',20),'authorized'=>!in_array($authorized,[false,'false','False','N'],true)];
    }
    private static function text(mixed $v,int $max): string
    {
        if($v===null){return '';}
        if(!is_string($v)&&!is_int($v)){throw new BridgeException('Champ produit Ingram non textuel.');}
        $v=trim((string)$v);if(preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f]/',$v)||mb_strlen($v)>$max){throw new BridgeException('Champ produit Ingram invalide ou trop long.');}return $v;
    }
    private static function number(mixed $v,bool $integer): ?float
    {
        if($v===null||$v===''){return null;}
        if(is_bool($v)||!is_numeric($v)||!is_finite((float)$v)||(float)$v<0||(float)$v>100000000||($integer&&floor((float)$v)!==(float)$v)){throw new BridgeException('Prix ou disponibilité Ingram invalide.');}return (float)$v;
    }
}
