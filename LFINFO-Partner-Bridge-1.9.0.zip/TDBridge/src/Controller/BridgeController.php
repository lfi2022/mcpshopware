<?php declare(strict_types=1);

namespace TDBridge\Controller;

use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\CatalogueCriteria;
use TDBridge\Domain\ProductMapper;
use TDBridge\Service\JobManager;
use TDBridge\Service\Settings;
use TDBridge\Service\TdClient;
use TDBridge\Service\CatalogueIndex;
use TDBridge\Service\ImportInspector;
use TDBridge\Service\CatalogueBrowser;
use TDBridge\Domain\CatalogueCategories;
use TDBridge\Service\SupplierCache;
use TDBridge\Service\IcecatClient;

#[Route(defaults: ['_routeScope' => ['api']])]
final class BridgeController
{
    public function __construct(private readonly Connection $db, private readonly Settings $settings, private readonly TdClient $client, private readonly ProductMapper $mapper, private readonly JobManager $jobs, private readonly CatalogueIndex $index, private readonly ImportInspector $inspector, private readonly CatalogueBrowser $browser, private readonly SupplierCache $supplierCache, private readonly IcecatClient $icecat) {}

    #[Route(path: '/api/_action/td-bridge/diagnose-import', name: 'api.action.td_bridge.diagnose_import', methods: ['GET'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function diagnoseImport(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $part = $request->query->get('part');
            if ($part !== null && !is_string($part)) { throw new BridgeException('Référence invalide.'); }
            return $this->inspector->inspect($part);
        });
    }

    #[Route(path: '/api/_action/td-bridge/settings', name: 'api.action.td_bridge.settings', methods: ['GET'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function settings(): JsonResponse { return $this->respond(fn () => $this->settings->publicSettings()); }

    #[Route(path: '/api/_action/td-bridge/settings', name: 'api.action.td_bridge.settings.save', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function save(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) { $this->settings->save($this->body($request)); return ['saved' => true]; });
    }

    #[Route(path: '/api/_action/td-bridge/test', name: 'api.action.td_bridge.test', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function test(): JsonResponse { return $this->respond(fn () => $this->client->test()); }

    #[Route(path: '/api/_action/td-bridge/diagnose', name: 'api.action.td_bridge.diagnose', methods: ['POST'], defaults: ['_acl' => ['td_bridge:configure']])]
    public function diagnose(Request $request): JsonResponse
    {
        return $this->respond(fn () => $this->client->catalogue(array_replace($this->body($request), ['page' => 1, 'pageSize' => 1])));
    }

    #[Route(path: '/api/_action/td-bridge/catalogue', name: 'api.action.td_bridge.catalogue', methods: ['POST'], defaults: ['_acl' => ['td_bridge:read']])]
    public function catalogue(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $input = $this->body($request);
            $settings = $this->settings->all();
            if (($input['mode'] ?? '') === 'cache') {
                $result = $this->supplierCache->search($input);
                $criteria = ['page' => $input['page'] ?? 1, 'pageSize' => $input['pageSize'] ?? 25];
            } elseif (in_array($input['mode'] ?? 'api', ['browse', 'index'], true)) {
                $result = $this->browser->search($input);
                $criteria = ['page' => 1, 'pageSize' => $input['pageSize'] ?? 25];
            } else {
                $criteria = CatalogueCriteria::build($input);
                $result = $this->mapper->catalogue($this->client->catalogue($criteria), $settings['mapping']);
            }
            $linked = $this->db->fetchFirstColumn('SELECT part_number FROM td_bridge_product WHERE part_number IN (' . implode(',', array_fill(0, max(1, count($result['items'])), '?')) . ')', array_column($result['items'], 'partNumber') ?: ['']);
            foreach ($result['items'] as &$item) {
                $item['imported'] = in_array($item['partNumber'], $linked, true);
                $item['saleNet'] = $item['cost'] !== null && $item['cost'] > 0 && strtoupper($item['currency'] ?? '') === $settings['currencyCode'] ? ProductMapper::sellingPrice($item['cost'], (float) $settings['markup'], (float) $settings['fixedMarkup'], 0)['net'] : null;
            }
            unset($item);
            return $result + ['page' => $criteria['page'], 'pageSize' => $criteria['pageSize']];
        });
    }

    #[Route(path: '/api/_action/td-bridge/catalogue-index', name: 'api.action.td_bridge.catalogue_index', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function indexStatus(): JsonResponse { return $this->respond(fn () => $this->index->status()); }

    #[Route(path: '/api/_action/td-bridge/catalogue-facets', name: 'api.action.td_bridge.catalogue_facets', methods: ['POST'], defaults: ['_acl' => ['td_bridge:read']])]
    public function catalogueFacets(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $input = $this->body($request);
            if (($input['mode'] ?? '') === 'cache') { return $this->supplierCache->facets($input); }
            return ['classes' => CatalogueCategories::options([]), 'brands' => [], 'countsAvailable' => false];
        });
    }

    #[Route(path: '/api/_action/td-bridge/catalogue-index/{action}', name: 'api.action.td_bridge.catalogue_index.action', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function indexAction(string $action, Request $request): JsonResponse
    {
        return $this->respond(static fn () => throw new BridgeException('L’indexation a été remplacée par la recherche fournisseur dans l’onglet LFINFO Partner Bridge.', 409));
    }

    #[Route(path: '/api/_action/td-bridge/supplier-cache', name: 'api.action.td_bridge.supplier_cache', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function cacheStatus(): JsonResponse { return $this->respond(fn () => $this->supplierCache->status()); }

    #[Route(path: '/api/_action/td-bridge/supplier-cache/{action}', name: 'api.action.td_bridge.supplier_cache.action', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function cacheAction(string $action, Request $request): JsonResponse
    {
        return $this->respond(fn () => $action === 'tick' ? $this->supplierCache->tick() : $this->supplierCache->action($action, $this->body($request)));
    }

    #[Route(path: '/api/_action/td-bridge/icecat/preview', name: 'api.action.td_bridge.icecat.preview', methods: ['POST'], defaults: ['_acl' => ['td_bridge:read']])]
    public function icecatPreview(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $part = $this->body($request)['partNumber'] ?? '';
            if (!is_string($part) || $part === '' || strlen($part) > 100) { throw new BridgeException('Référence TD invalide.'); }
            $items = $this->mapper->catalogue($this->client->catalogue(['tdsynnexPartNumber' => [$part], 'page' => 1, 'pageSize' => 100]), $this->settings->all()['mapping'])['items'];
            $item = array_values(array_filter($items, static fn ($item) => $item['partNumber'] === $part))[0] ?? null;
            if (!$item) { throw new BridgeException('Référence absente du catalogue.'); }
            $content = $this->icecat->product($item);
            // No signed URLs/content tokens in the browser or exported preview.
            $content['imageCount'] = count($content['images']); unset($content['images']);
            return $content;
        });
    }

    #[Route(path: '/api/_action/td-bridge/import', name: 'api.action.td_bridge.import', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function import(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $body = $this->body($request);
            if (!isset($body['parts']) || !is_array($body['parts'])) { throw new BridgeException('Liste de références attendue.'); }
            return ['id' => $this->jobs->enqueue($body['parts'], $body['type'] ?? 'import')];
        });
    }

    #[Route(path: '/api/_action/td-bridge/process', name: 'api.action.td_bridge.process', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function process(): JsonResponse { return $this->respond(fn () => $this->jobs->tick()); }

    #[Route(path: '/api/_action/td-bridge/sync-all', name: 'api.action.td_bridge.sync_all.preview', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function syncAllPreview(): JsonResponse { return $this->respond(fn () => $this->jobs->syncSummary()); }

    #[Route(path: '/api/_action/td-bridge/sync-all', name: 'api.action.td_bridge.sync_all', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function syncAll(): JsonResponse { return $this->respond(fn () => $this->jobs->syncAll()); }

    #[Route(path: '/api/_action/td-bridge/icecat-missing', name: 'api.action.td_bridge.icecat_missing.preview', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function missingPhotoPreview(): JsonResponse { return $this->respond(fn () => $this->jobs->missingPhotoSummary()); }

    #[Route(path: '/api/_action/td-bridge/icecat-missing', name: 'api.action.td_bridge.icecat_missing', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function missingPhotoEnrich(): JsonResponse { return $this->respond(fn () => $this->jobs->enrichMissingPhotos()); }

    #[Route(path: '/api/_action/td-bridge/workers', name: 'api.action.td_bridge.workers', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function workers(): JsonResponse { return $this->respond(fn () => $this->jobs->workerStatus()); }

    #[Route(path: '/api/_action/td-bridge/jobs/{id}/{action}', name: 'api.action.td_bridge.job_action', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function jobAction(string $id, string $action): JsonResponse
    {
        return $this->respond(function () use ($id, $action) { $this->jobs->action($id, $action); return ['saved' => true]; });
    }

    #[Route(path: '/api/_action/td-bridge/links', name: 'api.action.td_bridge.links.update', methods: ['POST'], defaults: ['_acl' => ['td_bridge:import']])]
    public function link(Request $request): JsonResponse
    {
        return $this->respond(function () use ($request) {
            $body = $this->body($request);
            if (!isset($body['partNumber'], $body['enabled']) || !is_string($body['partNumber']) || !is_bool($body['enabled'])) { throw new BridgeException('Référence et état de synchronisation requis.'); }
            $id = $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number=?', [$body['partNumber']]);
            if (!$id) { throw new BridgeException('Liaison introuvable.'); }
            (new \TDBridge\Service\SupplierOffers($this->db))->bind('tdsynnex',$body['partNumber'],$id,$body['enabled']);
            return ['saved' => true];
        });
    }

    #[Route(path: '/api/_action/td-bridge/list/{kind}', name: 'api.action.td_bridge.list', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function listing(string $kind, Request $request): JsonResponse
    {
        return $this->respond(function () use ($kind, $request) {
            $page = CatalogueCriteria::integer($request->query->get('page', 1), 1, 100000);
            $size = 25;
            $table = match ($kind) { 'links' => "(SELECT 'tdsynnex' AS supplier,1 AS catalogue_available,part_number,product_id,name,sync_enabled,cost,currency,last_synced_at,next_sync_at,last_error,created_at FROM td_bridge_product UNION ALL SELECT supplier,catalogue_available,part_number,product_id,name,sync_enabled,cost,currency,last_synced_at,next_sync_at,last_error,observed_at AS created_at FROM lf_supplier_offer WHERE product_id IS NOT NULL) connected", 'jobs' => 'td_bridge_job', 'logs' => 'td_bridge_log', default => throw new BridgeException('Liste inconnue.') };
            $fields = match ($kind) { 'links' => 'supplier, catalogue_available, part_number, LOWER(HEX(product_id)) AS product_id, name, sync_enabled, cost, currency, last_synced_at, next_sync_at, last_error', 'jobs' => 'id, type, COALESCE(JSON_UNQUOTE(JSON_EXTRACT(options, \'$.supplier\')), \'tdsynnex\') AS supplier, status, processed AS `cursor`, total, succeeded, failed, attempts, last_error, created_at, updated_at, available_at', default => '*' };
            $where = '';
            $params = [];
            $term = trim((string) $request->query->get('term', ''));
            if (strlen($term) > 200) { throw new BridgeException('Recherche trop longue.'); }
            if ($term !== '') {
                $where = match ($kind) { 'links' => ' WHERE part_number LIKE ? OR name LIKE ?', 'jobs' => ' WHERE id = ?', default => ' WHERE job_id = ? OR part_number = ?' };
                $params = $kind === 'jobs' ? [$term] : ($kind === 'links' ? ['%' . $term . '%', '%' . $term . '%'] : [$term, $term]);
            }
            $order = $kind === 'links' ? 'created_at DESC, part_number' : ($kind === 'jobs' ? 'created_at DESC, id DESC' : 'id DESC');
            return ['items' => $this->db->fetchAllAssociative("SELECT $fields FROM $table$where ORDER BY $order LIMIT $size OFFSET " . (($page - 1) * $size), $params), 'total' => (int) $this->db->fetchOne("SELECT COUNT(*) FROM $table$where", $params), 'page' => $page, 'pageSize' => $size];
        });
    }

    #[Route(path: '/api/_action/td-bridge/stats', name: 'api.action.td_bridge.stats', methods: ['GET'], defaults: ['_acl' => ['td_bridge:read']])]
    public function stats(): JsonResponse
    {
        return $this->respond(function () {
            $settings = $this->settings->all();
            return [
                'products' => (int) $this->db->fetchOne('SELECT COUNT(DISTINCT product_id) FROM (SELECT product_id FROM td_bridge_product UNION SELECT product_id FROM lf_supplier_offer WHERE product_id IS NOT NULL) connected'),
                'synchronised' => (int) $this->db->fetchOne('SELECT COUNT(*) FROM td_bridge_product WHERE sync_enabled = 1') + (int)$this->db->fetchOne('SELECT COUNT(*) FROM lf_supplier_offer WHERE sync_enabled=1 AND product_id IS NOT NULL'),
                'pending' => (int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE status IN ('queued', 'running')"),
                'errors' => (int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_log WHERE level = 'error' AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)"),
                'configured' => $settings['encryptedSecret'] !== '' && $settings['clientId'] !== '',
                'syncEnabled' => $settings['syncEnabled'], 'syncMinutes' => $settings['syncMinutes'],
                'activateProducts' => $settings['activateProducts'],
                'worker' => $this->db->fetchAssociative("SELECT status, last_execution_time, next_execution_time FROM scheduled_task WHERE name = 'td_bridge.process'"),
            ];
        });
    }

    #[Route(path: '/api/_action/td-bridge/documents/{type}', name: 'api.action.td_bridge.documents', methods: ['POST'], defaults: ['_acl' => ['td_bridge:documents']])]
    public function documents(string $type, Request $request): JsonResponse
    {
        return $this->respond(function () use ($type, $request) {
            if (!in_array($type, ['orders', 'invoices'], true)) { throw new BridgeException('Type de document inconnu.'); }
            return $this->client->documents($type, $this->body($request));
        });
    }

    private function body(Request $request): array
    {
        if (strlen($request->getContent()) > 65536) { throw new BridgeException('Requête trop volumineuse.', 413); }
        try { $body = json_decode($request->getContent(), true, 32, JSON_THROW_ON_ERROR); }
        catch (\JsonException) { throw new BridgeException('Corps JSON invalide.'); }
        if (!is_array($body) || ($body !== [] && array_is_list($body))) { throw new BridgeException('Objet JSON attendu.'); }
        return $body;
    }

    private function respond(callable $callback): JsonResponse
    {
        try { $response = new JsonResponse($callback()); }
        catch (BridgeException $e) {
            $status = in_array($e->httpStatus, [400, 409, 413, 422, 429], true) ? $e->httpStatus : 502;
            $response = new JsonResponse(['errors' => [['code' => 'TD_BRIDGE_ERROR', 'detail' => $e->getMessage()]]], $status);
            if ($e->retryAfter > 0) { $response->headers->set('Retry-After', (string) $e->retryAfter); }
        }
        $response->headers->set('Cache-Control', 'no-store, private');
        return $response;
    }
}
