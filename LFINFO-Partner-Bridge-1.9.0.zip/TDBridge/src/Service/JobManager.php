<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\ProductMapper;
use TDBridge\Domain\ImportDiagnostics;

final class JobManager
{
    public function __construct(private readonly Connection $db, private readonly Settings $settings, private readonly TdClient $client, private readonly ProductMapper $mapper, private readonly ProductImporter $importer, private readonly IcecatEnricher $icecat, private readonly ?\TDBridge\Supplier\ConnectorRegistry $registry = null, private readonly ?CopacoFeedSync $copaco = null, private readonly ?IngramConfig $ingram = null) {}

    public function enqueue(array $parts, string $type = 'import', string $supplier = 'tdsynnex'): string
    {
        if (!in_array($type, ['import', 'sync', 'icecat', 'icecat_missing'], true) || !$parts || count($parts) > 500) { throw new BridgeException('Sélectionnez entre 1 et 500 références.'); }
        foreach ($parts as $part) { if (!is_string($part) || trim($part) === '' || strlen($part) > 100) { throw new BridgeException('Référence invalide.'); } }
        $parts = array_values(array_unique(array_map('trim', $parts)));
        if (!in_array($supplier, ['tdsynnex', 'copaco', 'ingram'], true)) { throw new BridgeException('Fournisseur ou opération indisponible.'); }
        $options = $this->settings->publicSettings();
        $options['supplier'] = $supplier;
        if($supplier==='ingram'){if(!$this->ingram){throw new BridgeException('Configuration du connecteur Ingram indisponible.');}$this->ingram->ready(true);$options['_ingramScope']=$this->ingram->scope();}
        if ($supplier === 'tdsynnex') {
            $options['_linkedProducts'] = $this->db->fetchAllKeyValue('SELECT part_number,LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number IN (' . implode(',', array_fill(0, count($parts), '?')) . ')', $parts);
        }
        else {
            $options['_linkedProducts'] = $this->db->fetchAllKeyValue('SELECT part_number,LOWER(HEX(product_id)) FROM lf_supplier_offer WHERE supplier=? AND product_id IS NOT NULL AND part_number IN (' . implode(',',array_fill(0,count($parts),'?')) . ')', [$supplier,...$parts]);
        }
        if ($type === 'icecat_missing') { $options['icecatOnlyMissingPhotos'] = true; $options['icecatImages'] = true; }
        if (in_array($type, ['icecat', 'icecat_missing'], true) && !$options['icecatEnabled']) { throw new BridgeException('Activez Open Icecat dans les paramètres.'); }
        foreach (['baseUrl', 'tokenUrl', 'clientId', 'hasSecret'] as $key) { unset($options[$key]); }
        if (!$options['taxId'] || !$options['currencyId']) { throw new BridgeException('Configurez la TVA et la devise avant de lancer un import.'); }
        if ($supplier === 'tdsynnex' && !$this->settings->all()['encryptedSecret']) { throw new BridgeException('Configurez les identifiants TD SYNNEX.'); }
        if ((int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE status IN ('queued', 'running')") >= 1000) { throw new BridgeException('La file contient déjà 1 000 tâches. Attendez leur traitement.', 409); }
        $id = bin2hex(random_bytes(16));
        $now = $this->db->fetchOne('SELECT UTC_TIMESTAMP(3)');
        $this->db->insert('td_bridge_job', ['id' => $id, 'type' => $type, 'parts' => json_encode($parts, JSON_THROW_ON_ERROR), 'options' => json_encode($options, JSON_THROW_ON_ERROR), 'total' => count($parts), 'available_at' => $now, 'created_at' => $now, 'updated_at' => $now]);
        return $id;
    }

    public function action(string $id, string $action): void
    {
        if (!preg_match('/^[a-f0-9]{32}$/D', $id)) { throw new BridgeException('Identifiant de tâche invalide.'); }
        if ($action === 'cancel') {
            $changed = $this->db->executeStatement("UPDATE td_bridge_job SET status = 'cancelled', updated_at = UTC_TIMESTAMP(3) WHERE id = ? AND status = 'queued'", [$id]);
        } elseif ($action === 'retry') {
            $changed = $this->db->executeStatement("UPDATE td_bridge_job SET status = 'queued', processed = 0, succeeded = 0, failed = 0, attempts = 0, last_error = NULL, available_at = UTC_TIMESTAMP(3), updated_at = UTC_TIMESTAMP(3) WHERE id = ? AND status IN ('failed', 'completed_with_errors', 'cancelled')", [$id]);
        } else { throw new BridgeException('Action inconnue.'); }
        if (!$changed) { throw new BridgeException('La tâche a changé d’état. Actualisez la liste.', 409); }
    }

    public function syncSummary(): array
    {
        $settings = $this->settings->all();
        return ['eligible' => (int) $this->db->fetchOne('SELECT COUNT(*) FROM td_bridge_product WHERE sync_enabled = 1') + count($this->linkedSupplierParts('copaco')) + count($this->linkedSupplierParts('ingram')),
            'paused' => (int) $this->db->fetchOne('SELECT COUNT(*) FROM td_bridge_product WHERE sync_enabled = 0') + (int)$this->db->fetchOne('SELECT COUNT(*) FROM lf_supplier_offer WHERE product_id IS NOT NULL AND sync_enabled=0'),
            'syncPrice' => (bool) $settings['syncPrice'], 'syncStock' => (bool) $settings['syncStock'],
            'syncContent' => (bool) $settings['syncContent'] && !(bool) $settings['icecatEnabled']];
    }

    public function syncAll(): array
    {
        if ((int) $this->db->fetchOne("SELECT GET_LOCK('tdbridge.worker', 0)") !== 1) { throw new BridgeException('Un lot est en cours de traitement. Réessayez dans quelques instants.', 409); }
        try {
            return $this->db->transactional(function (): array {
                if ((int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE type = 'sync' AND status IN ('queued', 'running')")) { throw new BridgeException('Une synchronisation est déjà en attente ou en cours. Attendez sa fin avant de tout relancer.', 409); }
                $summary = $this->syncSummary();
                if (!$summary['syncPrice'] && !$summary['syncStock'] && !$summary['syncContent']) { throw new BridgeException('Activez au moins une option de synchronisation dans les paramètres.'); }
                $parts = $this->db->fetchFirstColumn('SELECT part_number FROM td_bridge_product WHERE sync_enabled = 1 ORDER BY part_number');
                $copaco = $this->linkedSupplierParts('copaco');
                if (!$parts && !$copaco && !$this->linkedSupplierParts('ingram')) { return ['products' => 0, 'jobs' => 0]; }
                $chunks = array_chunk($parts, 50); $copacoChunks = array_chunk($copaco,50); $ingram=$this->linkedSupplierParts('ingram');$ingramChunks=array_chunk($ingram,50);
                $pending = (int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE status IN ('queued', 'running')");
                if ($pending + count($chunks) + count($copacoChunks) + count($ingramChunks) > 1000) { throw new BridgeException('La file ne peut pas accueillir toute la synchronisation maintenant (1 000 tâches maximum, 50 références par tâche). Attendez la fin des tâches en cours. Aucun lot ajouté.', 409); }
                foreach ($chunks as $chunk) { $this->enqueue($chunk, 'sync'); }
                foreach ($copacoChunks as $chunk) { $this->enqueue($chunk,'sync','copaco'); }
                foreach($ingramChunks as $chunk){$this->enqueue($chunk,'sync','ingram');}
                return ['products' => count($parts) + count($copaco) + count($ingram), 'jobs' => count($chunks) + count($copacoChunks) + count($ingramChunks)];
            });
        } finally { $this->db->fetchOne("SELECT RELEASE_LOCK('tdbridge.worker')"); }
    }

    public function missingPhotoSummary(): array
    {
        return ['eligible' => count((new ProductPhotos($this->db))->missingParts()) + count($this->linkedSupplierParts('copaco',true)) + count($this->linkedSupplierParts('ingram',true)),
            'paused' => (int) $this->db->fetchOne('SELECT COUNT(*) FROM td_bridge_product WHERE sync_enabled = 0'),
            'enabled' => (bool) $this->settings->all()['icecatEnabled']];
    }

    public function enrichMissingPhotos(): array
    {
        $coordinator = new WorkerCoordinator($this->db, $this->settings);
        if (!$coordinator->lock('tdbridge.worker')) { throw new BridgeException('La file est occupée. Réessayez dans un instant.', 409); }
        try {
            return $this->db->transactional(function (): array {
                if ((int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE type IN ('icecat', 'icecat_missing') AND status IN ('queued', 'running')")) { throw new BridgeException('Un enrichissement Icecat est déjà en attente ou en cours.', 409); }
                if (!$this->settings->all()['icecatEnabled']) { throw new BridgeException('Activez Open Icecat dans les paramètres.'); }
                $parts = (new ProductPhotos($this->db))->missingParts();
                $copaco = $this->linkedSupplierParts('copaco',true);
                $chunks = array_chunk($parts, 25); $copacoChunks = array_chunk($copaco,25);$ingram=$this->linkedSupplierParts('ingram',true);$ingramChunks=array_chunk($ingram,25);
                if (count($chunks) + count($copacoChunks) + count($ingramChunks) + (int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE status IN ('queued', 'running')") > 1000) { throw new BridgeException('File pleine : aucun enrichissement ajouté. Attendez la fin des tâches.', 409); }
                foreach ($chunks as $chunk) { $this->enqueue($chunk, 'icecat_missing'); }
                foreach ($copacoChunks as $chunk) { $this->enqueue($chunk,'icecat_missing','copaco'); }
                foreach($ingramChunks as $chunk){$this->enqueue($chunk,'icecat_missing','ingram');}
                return ['products' => count($parts) + count($copaco) + count($ingram), 'jobs' => count($chunks) + count($copacoChunks) + count($ingramChunks)];
            });
        } finally { $coordinator->release('tdbridge.worker'); }
    }

    public function workerStatus(): array { return (new WorkerCoordinator($this->db, $this->settings))->status(); }
    public function workerDemand(): int { return (new WorkerCoordinator($this->db, $this->settings))->demand(); }

    public function drain(float $seconds = 20, int $batches = 100): array
    {
        $deadline = microtime(true) + $seconds; $last = ['state' => 'idle']; $processed = 0;
        for ($i = 0; $i < $batches && microtime(true) < $deadline; ++$i) {
            $last = $this->tick(); $processed += $last['processed'] ?? 0;
            if (in_array($last['state'], ['idle', 'busy', 'cooldown', 'retry'], true)) { break; }
        }
        return $last + ['drained' => $processed];
    }

    public function tick(): array
    {
        if (PHP_SAPI === 'cli') { $this->copaco?->refreshIfDue(); }
        $coordinator = new WorkerCoordinator($this->db, $this->settings);
        $claim = $coordinator->claim();
        if ($claim['state'] !== 'claimed') {
            if ($claim['state'] === 'idle' && $coordinator->lock('tdbridge.worker')) {
                try {
                    $settings = $this->settings->all();
                    if ($settings['syncEnabled'] && $settings['clientId'] && $settings['encryptedSecret'] && $settings['taxId'] && $settings['currencyId'] && !(int) $this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE type = 'sync' AND status IN ('queued', 'running')")) {
                        $parts = $this->db->fetchFirstColumn('SELECT part_number FROM td_bridge_product WHERE sync_enabled = 1 AND next_sync_at <= UTC_TIMESTAMP(3) ORDER BY next_sync_at LIMIT 200');
                        foreach (array_chunk($parts, 50) as $chunk) { $this->enqueue($chunk, 'sync'); }
                    }
                    if ($settings['syncEnabled'] && !(int)$this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE type='sync' AND status IN ('queued','running')")) {
                        $offers = $this->db->fetchFirstColumn("SELECT part_number FROM lf_supplier_offer WHERE supplier='copaco' AND sync_enabled=1 AND next_sync_at<=UTC_TIMESTAMP(3) AND catalogue_available=1 AND observed_at>=DATE_SUB(UTC_TIMESTAMP(3),INTERVAL IF(source_kind='datafile',36,24) HOUR) ORDER BY next_sync_at LIMIT 200");
                        foreach (array_chunk($offers,50) as $chunk) { $this->enqueue($chunk, 'sync', 'copaco'); }
                    }
                    if($settings['syncEnabled'] && $this->ingram && $this->ingram->all()['enabled'] && $this->ingram->all()['environment']==='production' && !(int)$this->db->fetchOne("SELECT COUNT(*) FROM td_bridge_job WHERE type='sync' AND status IN ('queued','running')")){
                        $parts=$this->db->fetchFirstColumn("SELECT part_number FROM lf_supplier_offer WHERE supplier='ingram' AND sync_enabled=1 AND account_scope=? AND next_sync_at<=UTC_TIMESTAMP(3) ORDER BY next_sync_at LIMIT 200",[$this->ingram->scope()]);foreach(array_chunk($parts,50) as $chunk){$this->enqueue($chunk,'sync','ingram');}
                    }
                    (new ProductLifecycle($this->db))->reconcile();
                    $this->cleanup();
                } finally { $coordinator->release('tdbridge.worker'); }
            }
            return ['state' => $claim['state']];
        }
        $job = $claim['job']; $partLocks = []; $processed = 0;
        try {
            $parts = json_decode($job['parts'], true, 512, JSON_THROW_ON_ERROR);
            $options = json_decode($job['options'], true, 512, JSON_THROW_ON_ERROR);
            $supplier = $options['supplier'] ?? 'tdsynnex';
            if (($options['mapping'] ?? []) == ProductMapper::LEGACY_MAP) { $options['mapping'] = ProductMapper::DEFAULT_MAP; }
            $isIcecat = in_array($job['type'], ['icecat', 'icecat_missing'], true);
            $batch = array_slice($parts, (int) $job['processed'], $isIcecat || ($job['type'] === 'import' && ($options['icecatEnabled'] ?? false)) ? 1 : 50);
            // Avoid conflicting price/content writes even across different task types.
            foreach ($batch as $part) {
                $name = 'tdbridge.part.' . md5($supplier . ':' . $part);
                if (!$coordinator->lock($name)) { throw new BridgeException('Référence déjà traitée par un autre worker.', 409, 2); }
                $partLocks[] = $name;
            }
            $toFetch = $batch;
            $ignored = []; $externalItems = []; $itemErrors = [];
            foreach ($batch as $part) {
                if ($this->db->fetchOne('SELECT 1 FROM lf_supplier_detached WHERE supplier=? AND part_number=? AND detached_at>=?',[$supplier,$part,$job['created_at']])) { $ignored[]=$part; continue; }
                $target = $supplier === 'tdsynnex'
                    ? $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number=?', [$part])
                    : $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM lf_supplier_offer WHERE supplier=? AND part_number=?', [$supplier,$part]);
                if ($target) {
                    $options['_linkedProducts'][$part] ??= $target;
                    $lock = 'tdbridge.product.' . $target;
                    if (!$coordinator->lock($lock)) { throw new BridgeException('Produit déjà traité par un autre worker.', 409, 2); }
                    $partLocks[] = $lock;
                }
                if($supplier==='ingram' && $job['type']==='icecat_missing' && (!$target || (new ProductPhotos($this->db))->hasPhoto($target))){$ignored[]=$part;continue;}
                if ($supplier !== 'tdsynnex') {
                    if (isset($options['_linkedProducts'][$part]) && (!$target || $target !== $options['_linkedProducts'][$part])) { $ignored[] = $part; continue; }
                    if($supplier==='ingram'){continue;}
                    try {
                        $item = $this->connectors()->get($supplier)->products([$part],$options,$job['type'])[0] ?? null;
                        if ($item) { $externalItems[$part] = $item; } else { $ignored[] = $part; }
                    } catch (BridgeException $e) { $itemErrors[$part] = $e; }
                } elseif (isset($options['_linkedProducts'][$part]) && (!$target || $target !== $options['_linkedProducts'][$part])) { $ignored[] = $part; }
                elseif ($target) {
                    $source = $this->db->fetchAssociative('SELECT supplier,part_number FROM lf_supplier_source WHERE product_id=UNHEX(?)', [$target]);
                    $enabled = $this->db->fetchOne('SELECT sync_enabled FROM td_bridge_product WHERE part_number=?', [$part]);
                    if (!$enabled || ($source && ($source['supplier'] !== 'tdsynnex' || $source['part_number'] !== $part))) { $ignored[] = $part; }
                } elseif ($job['type'] !== 'import') { $ignored[] = $part; }
            }
            $toFetch = array_values(array_diff($toFetch, $ignored));
            if ($job['type'] === 'icecat_missing' && $supplier === 'tdsynnex') {
                $toFetch = [];
                foreach ($batch as $part) {
                    $id = $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number = ? AND sync_enabled = 1', [$part]);
                    if (!in_array($part, $ignored, true) && $id && !(new ProductPhotos($this->db))->hasPhoto($id)) { $toFetch[] = $part; }
                }
            }
            $indexed = $externalItems;
            if($supplier==='ingram' && $toFetch){
                foreach($this->connectors()->get('ingram')->products($toFetch,$options,$job['type']) as $item){
                    if(isset($indexed[$item['partNumber']])){throw new BridgeException('Référence dupliquée dans le lot Ingram.');}
                    $indexed[$item['partNumber']]=$item;
                }
                foreach($toFetch as $part){if(!isset($indexed[$part])){$ignored[]=$part;}}
            }
            if ($toFetch && $supplier === 'tdsynnex') {
                $items = $this->connectors()->get($supplier)->products($toFetch,$options,$job['type']);
                foreach ($items as $item) {
                    if (isset($indexed[$item['partNumber']])) { throw new BridgeException('Référence dupliquée dans la réponse fournisseur.', 422); }
                    $indexed[$item['partNumber']] = $item;
                }
            }
            foreach ($batch as $part) {
                try {
                    if (isset($itemErrors[$part])) { throw $itemErrors[$part]; }
                    if (in_array($part, $ignored, true) || ($job['type'] === 'icecat_missing' && !in_array($part, $toFetch, true))) { $result = 'ignored_photo'; }
                    else {
                        if(isset($indexed[$part]['_error'])){throw new BridgeException($indexed[$part]['_error']);}
                        if (!isset($indexed[$part])) { throw new BridgeException('Référence absente du catalogue ; le produit Shopware est conservé.'); }
                        $itemOptions = $options;
                        if ($supplier !== 'tdsynnex') { $itemOptions['_targetProductId'] = $indexed[$part]['_productId']; }
                        if ($isIcecat) { $result = $this->icecat->enrich($indexed[$part], $itemOptions); }
                        else {
                            $result = $this->importer->import($indexed[$part], $itemOptions, $job['type'] === 'sync');
                            if ($job['type'] === 'import' && ($options['icecatEnabled'] ?? false)) {
                                try {
                                    if ($supplier !== 'tdsynnex') { $itemOptions['_targetProductId'] = $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM lf_supplier_offer WHERE supplier=? AND part_number=?',[$supplier,$part]); }
                                    if (!in_array($result,['ignored','ignored_deleted'],true)) { $this->icecat->enrich($indexed[$part], $itemOptions, $result === 'created'); }
                                }
                                catch (\Throwable $e) {
                                    if ($e instanceof BridgeException && $e->httpStatus === 429) { $coordinator->cooldown(max(60, $e->retryAfter)); }
                                    $this->log($job['id'], 'warning', $part, 'Import fournisseur réussi ; enrichissement Icecat à reprendre : ' . ImportDiagnostics::message($e));
                                }
                            }
                        }
                    }
                    if ($supplier !== 'tdsynnex' && !$isIcecat && !in_array($part, $ignored, true)) {
                        $this->db->executeStatement('UPDATE lf_supplier_offer SET last_synced_at=UTC_TIMESTAMP(3),next_sync_at=?,last_error=NULL WHERE supplier=? AND part_number=?', [gmdate('Y-m-d H:i:s', time() + max(900,(int)$options['syncMinutes']*60)),$supplier,$part]);
                    }
                    ++$job['succeeded'];
                    $this->log($job['id'], 'info', $part, match ($result) { 'created' => 'Produit créé.', 'enriched' => 'Contenu Icecat enrichi.', 'ignored_deleted' => 'Produit supprimé : référence ignorée.', 'ignored_photo' => 'Produit délié, suivi suspendu ou photo déjà présente : traitement ignoré.', 'ignored' => 'Synchronisation suspendue : référence ignorée.', default => 'Produit mis à jour.' });
                } catch (\Throwable $e) {
                    if ($e instanceof BridgeException && ($e->httpStatus === 429 || $e->httpStatus >= 500)) { throw $e; }
                    ++$job['failed']; $message = ImportDiagnostics::message($e);
                    $this->log($job['id'], 'error', $part, $message);
                    if ($supplier !== 'tdsynnex') { $this->db->executeStatement('UPDATE lf_supplier_offer SET last_error=?,next_sync_at=? WHERE supplier=? AND part_number=?', [mb_substr($message,0,500),gmdate('Y-m-d H:i:s',time()+3600),$supplier,$part]); }
                    if (!$isIcecat && $supplier === 'tdsynnex') { $this->db->executeStatement('UPDATE td_bridge_product SET last_error = ?, next_sync_at = ? WHERE part_number = ?', [mb_substr($message, 0, 500), gmdate('Y-m-d H:i:s', time() + max(900, (int) $options['syncMinutes'] * 60)), $part]); }
                }
                ++$job['processed']; ++$processed;
                // Checkpoint each product: a later timeout/retry never resets earlier counters.
                $this->db->update('td_bridge_job', ['processed' => $job['processed'], 'succeeded' => $job['succeeded'], 'failed' => $job['failed'], 'updated_at' => gmdate('Y-m-d H:i:s')], ['id' => $job['id']]);
            }
            $status = (int) $job['processed'] >= (int) $job['total'] ? ($job['failed'] ? 'completed_with_errors' : 'completed') : 'queued';
            $this->db->update('td_bridge_job', ['status' => $status, 'attempts' => 0, 'last_error' => null, 'available_at' => gmdate('Y-m-d H:i:s'), 'updated_at' => gmdate('Y-m-d H:i:s')], ['id' => $job['id']]);
            return ['state' => $status, 'id' => $job['id'], 'processed' => $processed];
        } catch (\Throwable $e) {
            $busy = $e instanceof BridgeException && $e->httpStatus === 409;
            $attempts = $busy ? (int) $job['attempts'] : (int) $job['attempts'] + 1;
            $retryable = $busy || ($e instanceof BridgeException && ($e->httpStatus === 429 || $e->httpStatus >= 500));
            $status = $retryable && ($busy || $attempts < 5) ? 'queued' : 'failed';
            $delay = $busy ? 2 : max($e instanceof BridgeException ? $e->retryAfter : 0, min(3600, 30 * 2 ** $attempts));
            if ($e instanceof BridgeException && $e->httpStatus === 429) { $coordinator->cooldown($delay); }
            $message = ImportDiagnostics::message($e);
            $this->db->update('td_bridge_job', ['status' => $status, 'attempts' => $attempts, 'last_error' => mb_substr($message, 0, 500), 'available_at' => gmdate('Y-m-d H:i:s', time() + $delay), 'updated_at' => gmdate('Y-m-d H:i:s')], ['id' => $job['id']]);
            if (!$busy) { $this->log($job['id'], 'error', null, $message); }
            return ['state' => $status === 'queued' ? 'retry' : 'failed', 'id' => $job['id'], 'processed' => $processed];
        } finally {
            foreach (array_reverse($partLocks) as $lock) { $coordinator->release($lock); }
            foreach ($claim['locks'] as $lock) { $coordinator->release($lock); }
        }
    }

    private function connectors(): \TDBridge\Supplier\ConnectorRegistry
    {
        return $this->registry ?? new \TDBridge\Supplier\ConnectorRegistry([
            new \TDBridge\Supplier\TdSynnexConnector($this->client,$this->mapper),
            new \TDBridge\Supplier\CopacoFeedConnector(new SupplierOffers($this->db)),
        ]);
    }

    private function linkedSupplierParts(string $supplier,bool $missingPhotos=false): array
    {
        if($supplier==='ingram' && (!$this->ingram || !$this->ingram->all()['enabled'] || $this->ingram->all()['environment']!=='production')){return [];}
        $rows = $this->db->fetchAllAssociative("SELECT o.part_number, LOWER(HEX(o.product_id)) AS id FROM lf_supplier_offer o INNER JOIN product p ON p.id=o.product_id AND p.version_id=UNHEX(?) INNER JOIN lf_supplier_source s ON s.product_id=o.product_id AND s.supplier=o.supplier AND s.part_number=o.part_number WHERE o.supplier=? AND o.sync_enabled=1 AND o.catalogue_available=1 AND (?<>'ingram' OR o.account_scope=?) ORDER BY o.part_number", [\Shopware\Core\Defaults::LIVE_VERSION,$supplier,$supplier,$this->ingram?->scope()??'']);
        return array_values(array_map(static fn ($row) => $row['part_number'], array_filter($rows, fn ($row) => !$missingPhotos || !(new ProductPhotos($this->db))->hasPhoto($row['id']))));
    }

    private function log(?string $job, string $level, ?string $part, string $message): void
    {
        $this->db->insert('td_bridge_log', ['job_id' => $job, 'level' => $level, 'part_number' => $part, 'message' => mb_substr($message, 0, 500), 'created_at' => gmdate('Y-m-d H:i:s')]);
    }

    private function cleanup(): void
    {
        $cutoff = gmdate('Y-m-d H:i:s', time() - (int) $this->settings->all()['retentionDays'] * 86400);
        $this->db->executeStatement('DELETE FROM td_bridge_log WHERE created_at < ? LIMIT 1000', [$cutoff]);
        $this->db->executeStatement("DELETE FROM td_bridge_job WHERE status IN ('completed', 'completed_with_errors', 'failed', 'cancelled') AND updated_at < ? LIMIT 100", [$cutoff]);
    }
}
