<?php declare(strict_types=1);

namespace TDBridge\Supplier;

use TDBridge\Service\IngramService;

final class IngramConnector implements CatalogueConnector
{
    public function __construct(private readonly IngramService $service) {}
    public function id(): string { return 'ingram'; }
    public function products(array $parts,array $options,string $purpose): array { return $this->service->products($parts,$options,$purpose); }
}
