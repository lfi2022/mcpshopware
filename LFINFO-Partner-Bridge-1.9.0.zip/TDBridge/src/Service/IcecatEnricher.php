<?php declare(strict_types=1);

namespace TDBridge\Service;

use Doctrine\DBAL\Connection;
use Shopware\Core\Content\Media\File\FileSaver;
use Shopware\Core\Content\Media\File\MediaFile;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Uuid\Uuid;
use TDBridge\Domain\BridgeException;
use TDBridge\Domain\IcecatContent;

final class IcecatEnricher
{
    public function __construct(private readonly Connection $db, private readonly IcecatClient $client, private readonly EntityRepository $products, private readonly EntityRepository $media, private readonly FileSaver $fileSaver) {}

    public function enrich(array $item, array $options, bool $new = false): string
    {
        $id = $options['_targetProductId'] ?? $this->db->fetchOne('SELECT LOWER(HEX(product_id)) FROM td_bridge_product WHERE part_number = ?', [$item['partNumber']]);
        if (!$id) { throw new BridgeException('Importez cette référence avant de demander son enrichissement Icecat.'); }
        if (($options['icecatOnlyMissingPhotos'] ?? false) && (new ProductPhotos($this->db))->hasPhoto($id)) { return 'ignored_photo'; }
        $context = Context::createDefaultContext();
        $criteria = (new Criteria([$id]))->addAssociation('media');
        $product = $this->products->search($criteria, $context)->first();
        if (!$product) { throw new BridgeException('Produit lié introuvable.'); }
        $content = $this->client->product($item, $options['icecatLanguage'] ?? null);
        if ($content['demo']) { throw new BridgeException('Le compte de démonstration Icecat ne permet pas cet enrichissement. Renseignez votre propre compte.'); }
        $write = ['id' => $id];
        $description = IcecatContent::description($content, $options);
        if ($description !== '' && ($new || ($options['icecatReplace'] ?? false) || !$product->getDescription())) { $write['description'] = $description; }
        if (($options['icecatTitle'] ?? false) && $content['title'] !== '' && ($new || ($options['icecatReplace'] ?? false) || !$product->getName())) { $write['name'] = mb_substr($content['title'], 0, 255); }
        $position = 0;
        $positions = [];
        foreach ($product->getMedia() ?? [] as $association) { $positions[$association->getId()] = $association->getPosition(); $position = max($position, $association->getPosition() + 1); }
        $imageErrors = 0;
        if ($options['icecatImages'] ?? true) {
            foreach ($content['images'] as $index => $url) {
                try {
                // Stable product + Icecat id + gallery position: signed token rotation creates no duplicates.
                $mediaId = Uuid::fromStringToHex('tdbridge.icecat.' . $id . '.' . $content['id'] . '.' . $index);
                $associationId = Uuid::fromStringToHex('tdbridge.icecat.association.' . $mediaId);
                $existing = $this->media->search(new Criteria([$mediaId]), $context)->first();
                if (!$existing || !$existing->getFileName()) {
                    $download = $this->client->image($url);
                    try {
                        $this->media->upsert([['id' => $mediaId, 'title' => mb_substr($content['title'], 0, 255), 'alt' => mb_substr($content['title'], 0, 255)]], $context);
                        $this->fileSaver->persistFileToMedia(new MediaFile($download['path'], $download['mime'], $download['extension'], $download['size']), 'td-icecat-' . $mediaId, $mediaId, $context);
                    } finally { @unlink($download['path']); }
                }
                $write['media'][] = ['id' => $associationId, 'mediaId' => $mediaId, 'position' => $positions[$associationId] ?? $position++];
                if (!$product->getCoverId() && !isset($write['coverId'])) { $write['coverId'] = $associationId; }
                } catch (\Throwable $e) {
                    if ($e instanceof BridgeException && ($e->httpStatus === 429 || $e->httpStatus >= 500)) { throw $e; }
                    ++$imageErrors;
                }
            }
        }
        // Never changes prices, stock, category, visibility or existing non-Icecat media.
        if (($options['icecatOnlyMissingPhotos'] ?? false) && (new ProductPhotos($this->db))->hasPhoto($id)) { return 'ignored_photo'; }
        if (count($write) > 1) { $this->products->update([$write], $context); }
        if ($imageErrors) { throw new BridgeException("Contenu Icecat traité ; $imageErrors image(s) non téléchargée(s). Relancez l’enrichissement pour réessayer.", 422); }
        return 'enriched';
    }
}
