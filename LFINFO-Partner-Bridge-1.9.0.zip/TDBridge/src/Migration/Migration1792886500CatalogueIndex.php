<?php declare(strict_types=1);

namespace TDBridge\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

final class Migration1792886500CatalogueIndex extends MigrationStep
{
    public function getCreationTimestamp(): int { return 1792886500; }

    public function update(Connection $connection): void
    {
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS td_bridge_catalogue (
    part_number VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    manufacturer VARCHAR(200) NOT NULL,
    product_class VARCHAR(200) NOT NULL,
    product_subclass VARCHAR(200) NOT NULL,
    product_status VARCHAR(30) NOT NULL,
    search_text LONGTEXT NOT NULL,
    stock INT NULL,
    cost DECIMAL(18,6) NULL,
    payload LONGTEXT NOT NULL,
    generation VARCHAR(32) NOT NULL,
    indexed_at DATETIME(3) NOT NULL,
    PRIMARY KEY (part_number),
    KEY `idx.td_bridge.catalogue.brand` (manufacturer),
    KEY `idx.td_bridge.catalogue.class` (product_class),
    KEY `idx.td_bridge.catalogue.generation` (generation),
    KEY `idx.td_bridge.catalogue.stock` (stock)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement(<<<'SQL'
CREATE TABLE IF NOT EXISTS td_bridge_catalogue_state (
    id TINYINT UNSIGNED NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'idle',
    generation VARCHAR(32) NOT NULL DEFAULT '',
    scopes LONGTEXT NOT NULL,
    scope_position INT NOT NULL DEFAULT 0,
    next_page INT NOT NULL DEFAULT 1,
    scanned INT NOT NULL DEFAULT 0,
    attempts INT NOT NULL DEFAULT 0,
    last_error VARCHAR(500) NULL,
    available_at DATETIME(3) NOT NULL,
    started_at DATETIME(3) NULL,
    completed_at DATETIME(3) NULL,
    updated_at DATETIME(3) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);
        $connection->executeStatement("INSERT IGNORE INTO td_bridge_catalogue_state (id, scopes, available_at, updated_at) VALUES (1, '[]', UTC_TIMESTAMP(3), UTC_TIMESTAMP(3))");
    }

    public function updateDestructive(Connection $connection): void {}
}
