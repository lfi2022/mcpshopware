<?php declare(strict_types=1);

namespace TDBridge\ScheduledTask;

use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Psr\Log\LoggerInterface;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;
use TDBridge\Service\WorkerPool;

#[AsMessageHandler(handles: BridgeTask::class)]
final class BridgeTaskHandler extends ScheduledTaskHandler
{
    public function __construct(EntityRepository $scheduledTaskRepository, LoggerInterface $logger, private readonly WorkerPool $pool)
    {
        parent::__construct($scheduledTaskRepository, $logger);
    }

    public function run(): void { $this->pool->run(20); }
}
