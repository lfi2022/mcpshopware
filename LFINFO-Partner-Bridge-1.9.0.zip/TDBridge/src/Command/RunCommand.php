<?php declare(strict_types=1);

namespace TDBridge\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Command\SignalableCommandInterface;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use TDBridge\Service\JobManager;
use TDBridge\Domain\CatalogueCriteria;

#[AsCommand(name: 'tdbridge:process', description: 'Traite la file LFINFO Partner Bridge : jusqu’à 50 références par appel TD et reprise par produit.')]
final class RunCommand extends Command implements SignalableCommandInterface
{
    private bool $stopping = false;
    public function __construct(private readonly JobManager $jobs) { parent::__construct(); }
    public function getSubscribedSignals(): array { return defined('SIGTERM') ? [SIGTERM, SIGINT] : []; }
    public function handleSignal(int $signal, int|false $previousExitCode = 0): int|false { $this->stopping = true; return false; }
    protected function configure(): void {
        $this->addOption('batches', null, InputOption::VALUE_REQUIRED, 'Nombre maximal de lots à traiter', '1');
        $this->addOption('seconds', null, InputOption::VALUE_REQUIRED, 'Budget temps entre les lots', '20');
    }
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->stopping = false;
        $io = new SymfonyStyle($input, $output);
        try {
            $limit = CatalogueCriteria::integer($input->getOption('batches'), 1, 1000);
            $deadline = microtime(true) + CatalogueCriteria::integer($input->getOption('seconds'), 1, 3600);
            for ($i = 0; $i < $limit && !$this->stopping && microtime(true) < $deadline; ++$i) {
                $result = $this->jobs->tick();
                $io->writeln(json_encode($result, JSON_THROW_ON_ERROR));
                if (in_array($result['state'], ['idle', 'busy', 'cooldown', 'retry'], true)) { break; }
            }
            // Business failures are persisted in the queue; the worker process itself succeeded.
            return Command::SUCCESS;
        } catch (\Throwable $e) { $io->error($e->getMessage()); return Command::FAILURE; }
    }
}
